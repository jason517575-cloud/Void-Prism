create table if not exists profiles (
  user_id text primary key,
  username text not null,
  created_at timestamptz not null default now()
);

create unique index if not exists profiles_username_lower_idx
  on profiles (lower(username));

create table if not exists custom_levels (
  id text primary key,
  user_id text not null,
  name text not null,
  summary text not null,
  def text not null,
  created_at timestamptz not null default now()
);

create unique index if not exists custom_levels_name_lower_idx
  on custom_levels (lower(name));

create index if not exists custom_levels_user_idx
  on custom_levels (user_id, created_at desc);

create table if not exists friendships (
  id text primary key,
  requester text not null,
  addressee text not null,
  status text not null,
  created_at timestamptz not null default now(),
  unique (requester, addressee)
);

create index if not exists friendships_addressee_idx
  on friendships (addressee, status);

create table if not exists messages (
  id text primary key,
  sender text not null,
  recipient text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create index if not exists messages_pair_idx
  on messages (sender, recipient, created_at);
