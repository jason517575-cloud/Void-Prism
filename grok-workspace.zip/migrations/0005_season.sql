create table if not exists season_state (
  id integer primary key,
  n integer not null default 1
);

insert into season_state (id, n) values (1, 1)
on conflict (id) do nothing;
