-- Per-user hangar progress + public boards (campaign times, infinite waves).

create table if not exists player_progress (
  user_id text primary key,
  campaign_reached integer not null default 1,
  campaign_best integer not null default 0,
  infinite_best_score integer not null default 0,
  infinite_best_wave integer not null default 0,
  fragments integer not null default 0,
  owned_skins text not null default '["prism"]',
  equipped_skin text not null default 'prism',
  updated_at timestamptz not null default now()
);

create table if not exists campaign_times (
  user_id text not null,
  level_id integer not null,
  best_ms integer not null,
  score integer not null default 0,
  updated_at timestamptz not null default now(),
  primary key (user_id, level_id)
);

create index if not exists campaign_times_level_ms_idx
  on campaign_times (level_id, best_ms);

create table if not exists infinite_scores (
  user_id text primary key,
  best_wave integer not null,
  best_score integer not null default 0,
  updated_at timestamptz not null default now()
);

create index if not exists infinite_scores_wave_idx
  on infinite_scores (best_wave desc, best_score desc);
