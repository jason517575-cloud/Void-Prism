-- Laser skins + rock packs equipped/owned on hangar progress.

alter table player_progress
  add column if not exists owned_lasers text not null default '["beam-stock"]';

alter table player_progress
  add column if not exists equipped_laser text not null default 'beam-stock';

alter table player_progress
  add column if not exists owned_packs text not null default '["pack-shale"]';

alter table player_progress
  add column if not exists equipped_pack text not null default 'pack-shale';
