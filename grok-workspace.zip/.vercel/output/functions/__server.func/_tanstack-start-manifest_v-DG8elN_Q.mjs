//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DG8elN_Q.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/api/auth/$"
		],
		preloads: ["/assets/index-DN2iSTRg.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DN2iSTRg.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BG9Nk0yR.js",
			"/assets/client-bLCk0icn.js",
			"/assets/button-DdV1OrD_.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DddnJig0.js",
			"/assets/client-bLCk0icn.js",
			"/assets/button-DdV1OrD_.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
