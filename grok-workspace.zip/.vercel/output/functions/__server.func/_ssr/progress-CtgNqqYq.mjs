import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-DNCleim5.mjs";
import { c as authMiddleware, i as LEVELS, n as DEFAULT_PACK_ID, o as ROCK_PACKS, r as LASER_SKINS, s as SKINS, t as DEFAULT_LASER_ID } from "./cosmetics-BKqjq9UB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/progress-CtgNqqYq.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function clampInt(n, min, max) {
	if (!Number.isFinite(n)) return min;
	return Math.max(min, Math.min(max, Math.floor(n)));
}
function parseIdList(raw, allowed, fallback) {
	try {
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [fallback];
		const ids = parsed.filter((id) => typeof id === "string" && allowed.has(id));
		if (!ids.includes(fallback)) ids.unshift(fallback);
		return ids;
	} catch {
		return [fallback];
	}
}
function parseSkins(raw) {
	return parseIdList(raw, new Set(SKINS.map((s) => s.id)), "prism");
}
function displayName(name, email) {
	const n = (name ?? "").trim();
	if (n) return n.slice(0, 32);
	const local = (email ?? "").split("@")[0] ?? "";
	if (local) return local.slice(0, 24);
	return "Pilot";
}
var emptyProgress = (campaignTimes) => ({
	campaignReached: 1,
	campaignBest: 0,
	infiniteBest: 0,
	infiniteBestWave: 0,
	fragments: 0,
	ownedSkins: ["prism"],
	equippedSkin: "prism",
	ownedLasers: [DEFAULT_LASER_ID],
	equippedLaser: DEFAULT_LASER_ID,
	ownedPacks: [DEFAULT_PACK_ID],
	equippedPack: DEFAULT_PACK_ID,
	campaignTimes
});
var getProgress_createServerFn_handler = createServerRpc({
	id: "06eacaaf5f9fea34f52ee5b39ba1b0e898ded429c1b4ce248de29b8b335eb78b",
	name: "getProgress",
	filename: "src/lib/progress.ts"
}, (opts) => getProgress.__executeServer(opts));
var getProgress = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getProgress_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	const rows = await sql`
      select campaign_reached, campaign_best, infinite_best_score, infinite_best_wave,
             fragments, owned_skins, equipped_skin,
             owned_lasers, equipped_laser, owned_packs, equipped_pack
      from player_progress
      where user_id = ${context.userId}
    `;
	const times = await sql`
      select level_id, best_ms from campaign_times where user_id = ${context.userId}
    `;
	const campaignTimes = {};
	for (const t of times) campaignTimes[t.level_id] = t.best_ms;
	const row = rows[0];
	if (!row) return emptyProgress(campaignTimes);
	const owned = parseSkins(row.owned_skins);
	const equipped = owned.includes(row.equipped_skin) ? row.equipped_skin : "prism";
	const lasers = parseIdList(row.owned_lasers, new Set(LASER_SKINS.map((s) => s.id)), DEFAULT_LASER_ID);
	const packs = parseIdList(row.owned_packs, new Set(ROCK_PACKS.map((s) => s.id)), DEFAULT_PACK_ID);
	return {
		campaignReached: row.campaign_reached,
		campaignBest: row.campaign_best,
		infiniteBest: row.infinite_best_score,
		infiniteBestWave: row.infinite_best_wave,
		fragments: row.fragments,
		ownedSkins: owned,
		equippedSkin: equipped,
		ownedLasers: lasers,
		equippedLaser: lasers.includes(row.equipped_laser) ? row.equipped_laser : DEFAULT_LASER_ID,
		ownedPacks: packs,
		equippedPack: packs.includes(row.equipped_pack) ? row.equipped_pack : DEFAULT_PACK_ID,
		campaignTimes
	};
});
var saveProgress_createServerFn_handler = createServerRpc({
	id: "54206244f918408c9f4415b91505cdfa4a6fffb5b632e3da88a6deba4362525a",
	name: "saveProgress",
	filename: "src/lib/progress.ts"
}, (opts) => saveProgress.__executeServer(opts));
var saveProgress = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const allowed = new Set(SKINS.map((s) => s.id));
	const owned = Array.isArray(input.ownedSkins) ? input.ownedSkins.filter((id) => allowed.has(id)) : ["prism"];
	if (!owned.includes("prism")) owned.unshift("prism");
	const equipped = allowed.has(input.equippedSkin) && owned.includes(input.equippedSkin) ? input.equippedSkin : "prism";
	const laserAllowed = new Set(LASER_SKINS.map((s) => s.id));
	const packAllowed = new Set(ROCK_PACKS.map((s) => s.id));
	const ownedLasers = Array.isArray(input.ownedLasers) ? input.ownedLasers.filter((id) => laserAllowed.has(id)) : [DEFAULT_LASER_ID];
	if (!ownedLasers.includes(DEFAULT_LASER_ID)) ownedLasers.unshift(DEFAULT_LASER_ID);
	const ownedPacks = Array.isArray(input.ownedPacks) ? input.ownedPacks.filter((id) => packAllowed.has(id)) : [DEFAULT_PACK_ID];
	if (!ownedPacks.includes(DEFAULT_PACK_ID)) ownedPacks.unshift(DEFAULT_PACK_ID);
	const equippedLaser = laserAllowed.has(input.equippedLaser) && ownedLasers.includes(input.equippedLaser) ? input.equippedLaser : DEFAULT_LASER_ID;
	const equippedPack = packAllowed.has(input.equippedPack) && ownedPacks.includes(input.equippedPack) ? input.equippedPack : DEFAULT_PACK_ID;
	return {
		campaignReached: clampInt(input.campaignReached, 1, LEVELS.length + 1),
		campaignBest: clampInt(input.campaignBest, 0, 9999999),
		infiniteBest: clampInt(input.infiniteBest, 0, 9999999),
		infiniteBestWave: clampInt(input.infiniteBestWave, 0, 9999),
		fragments: clampInt(input.fragments, 0, 9999999),
		ownedSkins: owned,
		equippedSkin: equipped,
		ownedLasers,
		equippedLaser,
		ownedPacks,
		equippedPack
	};
}).handler(saveProgress_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const skins = JSON.stringify(data.ownedSkins);
	const lasers = JSON.stringify(data.ownedLasers);
	const packs = JSON.stringify(data.ownedPacks);
	await sql`
      insert into player_progress (
        user_id, campaign_reached, campaign_best, infinite_best_score, infinite_best_wave,
        fragments, owned_skins, equipped_skin, owned_lasers, equipped_laser,
        owned_packs, equipped_pack, updated_at
      ) values (
        ${context.userId}, ${data.campaignReached}, ${data.campaignBest}, ${data.infiniteBest},
        ${data.infiniteBestWave}, ${data.fragments}, ${skins}, ${data.equippedSkin},
        ${lasers}, ${data.equippedLaser}, ${packs}, ${data.equippedPack}, now()
      )
      on conflict (user_id) do update set
        campaign_reached = greatest(player_progress.campaign_reached, excluded.campaign_reached),
        campaign_best = greatest(player_progress.campaign_best, excluded.campaign_best),
        infinite_best_score = greatest(player_progress.infinite_best_score, excluded.infinite_best_score),
        infinite_best_wave = greatest(player_progress.infinite_best_wave, excluded.infinite_best_wave),
        fragments = excluded.fragments,
        owned_skins = excluded.owned_skins,
        equipped_skin = excluded.equipped_skin,
        owned_lasers = excluded.owned_lasers,
        equipped_laser = excluded.equipped_laser,
        owned_packs = excluded.owned_packs,
        equipped_pack = excluded.equipped_pack,
        updated_at = now()
    `;
	return { ok: true };
});
var submitCampaignTime_createServerFn_handler = createServerRpc({
	id: "414b7932b218de776262613ae61cf9a61f5a5788672cb8ab40a54f10cd310247",
	name: "submitCampaignTime",
	filename: "src/lib/progress.ts"
}, (opts) => submitCampaignTime.__executeServer(opts));
var submitCampaignTime = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	levelId: clampInt(input.levelId, 1, LEVELS.length),
	timeMs: clampInt(input.timeMs, 400, 72e5),
	score: clampInt(input.score, 0, 9999999)
})).handler(submitCampaignTime_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into campaign_times (user_id, level_id, best_ms, score, updated_at)
      values (${context.userId}, ${data.levelId}, ${data.timeMs}, ${data.score}, now())
      on conflict (user_id, level_id) do update set
        best_ms = least(campaign_times.best_ms, excluded.best_ms),
        score = greatest(campaign_times.score, excluded.score),
        updated_at = now()
    `;
	return { ok: true };
});
var submitInfiniteWave_createServerFn_handler = createServerRpc({
	id: "8bc7fa67abc65f66c48eee09906b3a927415589617ffcd67bc256207dc91eaac",
	name: "submitInfiniteWave",
	filename: "src/lib/progress.ts"
}, (opts) => submitInfiniteWave.__executeServer(opts));
var submitInfiniteWave = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	wave: clampInt(input.wave, 1, 9999),
	score: clampInt(input.score, 0, 9999999)
})).handler(submitInfiniteWave_createServerFn_handler, async ({ context, data }) => {
	await (await getSql())`
      insert into infinite_scores (user_id, best_wave, best_score, updated_at)
      values (${context.userId}, ${data.wave}, ${data.score}, now())
      on conflict (user_id) do update set
        best_wave = greatest(infinite_scores.best_wave, excluded.best_wave),
        best_score = greatest(infinite_scores.best_score, excluded.best_score),
        updated_at = now()
    `;
	return { ok: true };
});
var listCampaignBoard_createServerFn_handler = createServerRpc({
	id: "28a8a4b7a3f42cc4d728624a5ee40abc3a830974586da34d3b194f8c70c9f788",
	name: "listCampaignBoard",
	filename: "src/lib/progress.ts"
}, (opts) => listCampaignBoard.__executeServer(opts));
var listCampaignBoard = createServerFn({ method: "GET" }).validator((input) => ({ levelId: clampInt(input.levelId, 1, LEVELS.length) })).handler(listCampaignBoard_createServerFn_handler, async ({ data }) => {
	return (await (await getSql())`
      select t.user_id, u.name, u.email, t.best_ms, t.score
      from campaign_times t
      left join "user" u on u.id = t.user_id
      where t.level_id = ${data.levelId}
      order by t.best_ms asc, t.score desc
      limit 25
    `).map((row, i) => ({
		rank: i + 1,
		userId: row.user_id,
		name: displayName(row.name, row.email),
		value: row.best_ms,
		score: row.score,
		mine: false
	}));
});
var listInfiniteBoard_createServerFn_handler = createServerRpc({
	id: "dd0175f3a617170467102bd5e81f12de997784adb4fd5151699ac279beb307c6",
	name: "listInfiniteBoard",
	filename: "src/lib/progress.ts"
}, (opts) => listInfiniteBoard.__executeServer(opts));
var listInfiniteBoard = createServerFn({ method: "GET" }).handler(listInfiniteBoard_createServerFn_handler, async () => {
	return (await (await getSql())`
      select s.user_id, u.name, u.email, s.best_wave, s.best_score
      from infinite_scores s
      left join "user" u on u.id = s.user_id
      order by s.best_wave desc, s.best_score desc
      limit 25
    `).map((row, i) => ({
		rank: i + 1,
		userId: row.user_id,
		name: displayName(row.name, row.email),
		value: row.best_wave,
		score: row.best_score,
		mine: false
	}));
});
//#endregion
export { getProgress_createServerFn_handler, listCampaignBoard_createServerFn_handler, listInfiniteBoard_createServerFn_handler, saveProgress_createServerFn_handler, submitCampaignTime_createServerFn_handler, submitInfiniteWave_createServerFn_handler };
