import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as signOut, t as authClient } from "./client-1vAx-gM_.mjs";
import { a as hasGateSessionMarker } from "./server-DMOkD9Nz.mjs";
import { n as cn, t as Button } from "./button-CrtAXrjG.mjs";
import { _ as rollGacha, a as MUSIC, c as authMiddleware, d as infiniteMusicId, f as isLaserId, g as packById, h as livePalette, i as LEVELS, l as formatTime, m as laserById, n as DEFAULT_PACK_ID, o as ROCK_PACKS, p as isPackId, r as LASER_SKINS, s as SKINS, t as DEFAULT_LASER_ID, u as infiniteBpm, v as skinById, y as unlockedWeapons } from "./cosmetics-BKqjq9UB.mjs";
import { _ as Dices, c as ShoppingBag, d as Pause, f as Mountain, g as Flame, h as Gem, i as Trophy, l as Shield, m as Hexagon, n as VolumeX, o as Sparkles, p as Lock, r as Volume2, s as Snowflake, t as Zap, u as Play, v as Crosshair, y as AudioLines } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B-dUzHYa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var FIXED = 1 / 60;
var FIRE_COOLDOWN = .1;
var CORE_INVULN = 1.15;
var REACH_FRAC = .52;
var MATCH = {
	basalt: "kinetic",
	rime: "cryo",
	quartz: "resonant",
	alloy: "thermal"
};
var KIND_LABEL = {
	basalt: "Basalt",
	rime: "Rime",
	quartz: "Quartz",
	alloy: "Alloy"
};
var WEAPON_LABEL = {
	kinetic: "Kinetic",
	cryo: "Cryo",
	resonant: "Resonant",
	thermal: "Thermal"
};
var WEAPON_ORDER = [
	"kinetic",
	"cryo",
	"resonant",
	"thermal"
];
var SIZE_R = {
	titan: 78,
	large: 42,
	medium: 24,
	small: 13
};
var SIZE_SCORE = {
	titan: 40,
	large: 20,
	medium: 50,
	small: 100
};
var SIZE_FRAG = {
	titan: 2,
	large: 1,
	medium: 1,
	small: 0
};
var LUCKY_COLOR = "#e6c35c";
var DROPS = [
	"aegis",
	"ward",
	"overcharge",
	"bomb",
	"frag2x"
];
var DROP_LABEL = {
	aegis: "Aegis 30s",
	ward: "Ward",
	overcharge: "Overcharge 5s",
	bomb: "Blast",
	frag2x: "2× Frag 10s"
};
var GAME_KEYS = /* @__PURE__ */ new Set([
	"KeyQ",
	"KeyE",
	"Digit1",
	"Digit2",
	"Digit3",
	"Digit4",
	"KeyP",
	"Escape"
]);
var bus = null;
var muted = false;
var musicVol = .72;
var sfxVol = .88;
var musicGen = 0;
var schedulerTimer = null;
var noiseBuf = null;
var currentProfile = null;
function freq(root, semis) {
	return root * Math.pow(2, semis / 12);
}
function ensureBus() {
	if (bus) return bus;
	const AC = window.AudioContext || window.webkitAudioContext;
	if (!AC) return null;
	const ctx = new AC({ latencyHint: "interactive" });
	const master = ctx.createGain();
	const music = ctx.createGain();
	const pad = ctx.createGain();
	const sfx = ctx.createGain();
	const filter = ctx.createBiquadFilter();
	const delay = ctx.createDelay(1.4);
	const delayGain = ctx.createGain();
	const feedback = ctx.createGain();
	filter.type = "lowpass";
	filter.Q.value = .7;
	filter.frequency.value = 1400;
	delay.delayTime.value = .28;
	delayGain.gain.value = .16;
	feedback.gain.value = .32;
	music.gain.value = musicVol;
	pad.gain.value = musicVol;
	sfx.gain.value = sfxVol;
	master.gain.value = muted ? 0 : .88;
	music.connect(filter);
	pad.connect(filter);
	filter.connect(delay);
	delay.connect(delayGain);
	delay.connect(feedback);
	feedback.connect(delay);
	delayGain.connect(master);
	filter.connect(master);
	sfx.connect(master);
	master.connect(ctx.destination);
	const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
	const data = buf.getChannelData(0);
	for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
	noiseBuf = buf;
	bus = {
		ctx,
		master,
		music,
		pad,
		sfx,
		delay,
		delayGain,
		filter
	};
	return bus;
}
function unlockAudio() {
	const b = ensureBus();
	if (!b) return;
	if (b.ctx.state === "suspended") b.ctx.resume();
}
function setMuted(value) {
	muted = value;
	if (!bus) return;
	bus.master.gain.setTargetAtTime(value ? 0 : .88, bus.ctx.currentTime, .03);
}
function setMusicVolume(value) {
	musicVol = Math.max(0, Math.min(1, value));
	if (!bus) return;
	const t = bus.ctx.currentTime;
	bus.music.gain.setTargetAtTime(musicVol, t, .04);
	bus.pad.gain.setTargetAtTime(musicVol, t, .04);
}
function setSfxVolume(value) {
	sfxVol = Math.max(0, Math.min(1, value));
	if (!bus) return;
	bus.sfx.gain.setTargetAtTime(sfxVol, bus.ctx.currentTime, .04);
}
function applyMix(next) {
	if (typeof next.musicVol === "number") setMusicVolume(next.musicVol);
	if (typeof next.sfxVol === "number") setSfxVolume(next.sfxVol);
	if (typeof next.muted === "boolean") setMuted(next.muted);
}
function resumeAudio() {
	if (bus && bus.ctx.state === "suspended") bus.ctx.resume();
}
function envGain(ctx, start, peak, dur, attack = .01) {
	const g = ctx.createGain();
	g.gain.setValueAtTime(1e-4, start);
	g.gain.exponentialRampToValueAtTime(Math.max(2e-4, peak), start + attack);
	g.gain.exponentialRampToValueAtTime(1e-4, start + dur);
	return g;
}
function tone(dest, ctx, time, hz, dur, type, gain, attack = .012, detune = 0, pan = 0) {
	const o = ctx.createOscillator();
	const g = envGain(ctx, time, gain, dur, attack);
	o.type = type;
	o.frequency.setValueAtTime(hz, time);
	if (detune) o.detune.setValueAtTime(detune, time);
	o.connect(g);
	if (pan !== 0 && ctx.createStereoPanner) {
		const p = ctx.createStereoPanner();
		p.pan.setValueAtTime(Math.max(-1, Math.min(1, pan)), time);
		g.connect(p);
		p.connect(dest);
	} else g.connect(dest);
	o.start(time);
	o.stop(time + dur + .05);
}
function noiseBurst(dest, ctx, time, dur, gain, hp = 400) {
	if (!noiseBuf) return;
	const src = ctx.createBufferSource();
	src.buffer = noiseBuf;
	const f = ctx.createBiquadFilter();
	f.type = "highpass";
	f.frequency.value = hp;
	const g = envGain(ctx, time, gain, dur, .004);
	src.connect(f);
	f.connect(g);
	g.connect(dest);
	src.start(time);
	src.stop(time + dur + .02);
}
function kick(dest, ctx, time, gain) {
	const o = ctx.createOscillator();
	const g = ctx.createGain();
	o.type = "sine";
	o.frequency.setValueAtTime(150, time);
	o.frequency.exponentialRampToValueAtTime(42, time + .14);
	g.gain.setValueAtTime(1e-4, time);
	g.gain.exponentialRampToValueAtTime(gain, time + .006);
	g.gain.exponentialRampToValueAtTime(1e-4, time + .22);
	o.connect(g);
	g.connect(dest);
	o.start(time);
	o.stop(time + .24);
	noiseBurst(dest, ctx, time, .03, gain * .25, 800);
}
function snare(dest, ctx, time, gain) {
	noiseBurst(dest, ctx, time, .12, gain, 1200);
	tone(dest, ctx, time, 190, .08, "triangle", gain * .45, .003);
}
function stopScheduler() {
	musicGen += 1;
	if (schedulerTimer) {
		clearTimeout(schedulerTimer);
		schedulerTimer = null;
	}
}
var GROOVES = {
	title: {
		k: "----------------",
		s: "----------------",
		h: "--x---x---x---x-"
	},
	shale: {
		k: "x---x---x---x--x",
		s: "----x-------x---",
		h: "x-x-x-x-x-x-x-xx"
	},
	rime: {
		k: "x-------x-------",
		s: "--------x-------",
		h: "x-xxx-x-x-xxx-x-"
	},
	twin: {
		k: "x---x---x---x---",
		s: "----x-------x---",
		h: "--x---x---x---x-"
	},
	quartz: {
		k: "x-----x-x-------",
		s: "----x-------x---",
		h: "x-x-xxx-x-x-xxx-"
	},
	alloy: {
		k: "x-x-----x-x--x--",
		s: "----x-------x---",
		h: "xxxxxxxxxxxxxxxx"
	},
	fourfold: {
		k: "x---x--xx---x---",
		s: "----x-------x---",
		h: "x-x-x-x-x-x-x-x-"
	},
	splinter: {
		k: "x-x---x---x--x--",
		s: "--x---x---x---x-",
		h: "xx-xxx-xxx-xxx-x"
	},
	halo: {
		k: "x--------x------",
		s: "----x-----------",
		h: "x--x--x--x--x--x"
	},
	titan: {
		k: "x---------------",
		s: "--------x-------",
		h: "----------------"
	},
	gauntlet: {
		k: "x-x-x---x-x-x---",
		s: "----x-------x---",
		h: "x-xxx-x-x-xxx-x-"
	},
	drift0: {
		k: "x---x---x---x---",
		s: "----x-------x---",
		h: "x-x-x-x-x-x-x-x-"
	},
	drift1: {
		k: "x-------x---x---",
		s: "--------x-------",
		h: "--x---x---x---x-"
	},
	drift2: {
		k: "x--------x------",
		s: "------x---------",
		h: "x--x--x--x--x--x"
	}
};
function hits(src, steps) {
	return [...src.padEnd(steps, "-").slice(0, steps)].map((c) => c === "x" || c === "X");
}
function grooveFor(profile) {
	const g = GROOVES[profile.id];
	const n = profile.steps;
	const defK = profile.kick ? "x---x---x---x---" : "----------------";
	const defS = profile.snare ? "----x-------x---" : "----------------";
	const defH = profile.hats ? "x-x-x-x-x-x-x-x-" : "----------------";
	return {
		k: hits(profile.kickG ?? g?.k ?? defK, n),
		s: hits(profile.snareG ?? g?.s ?? defS, n),
		h: hits(profile.hatG ?? g?.h ?? defH, n)
	};
}
function scheduleProfile(profile, gen) {
	const b = bus;
	if (!b) return;
	const { ctx } = b;
	const groove = grooveFor(profile);
	b.filter.frequency.setTargetAtTime(profile.filterHz, ctx.currentTime, .08);
	b.delay.delayTime.setTargetAtTime(Math.max(.08, profile.delay), ctx.currentTime, .05);
	b.delayGain.gain.setTargetAtTime(profile.delay > .2 ? .26 : .12, ctx.currentTime, .05);
	b.music.gain.cancelScheduledValues(ctx.currentTime);
	b.pad.gain.cancelScheduledValues(ctx.currentTime);
	b.music.gain.setTargetAtTime(1, ctx.currentTime, .12);
	b.pad.gain.setTargetAtTime(1, ctx.currentTime, .12);
	let step = 0;
	const stepDur = 60 / profile.bpm / 2;
	let next = ctx.currentTime + .06;
	const tick = () => {
		if (gen !== musicGen) return;
		while (next < ctx.currentTime + .16) {
			const i = step % profile.steps;
			const swing = i % 2 === 1 ? stepDur * profile.swing : 0;
			const t = next + swing;
			const leadIdx = profile.lead[i] ?? -1;
			const bassIdx = profile.bass[i] ?? -1;
			const arpIdx = profile.arp[i] ?? -1;
			const dur = stepDur * profile.noteFrac;
			const cycle = Math.sin(step / profile.steps * Math.PI * 2);
			b.filter.frequency.setTargetAtTime(profile.filterHz * (.82 + .28 * cycle), t, .08);
			if (bassIdx >= 0) {
				const semis = profile.scale[bassIdx] ?? 0;
				const hz = freq(profile.rootHz, semis);
				tone(b.music, ctx, t, hz, dur * 1.35, profile.bassWave, profile.bassGain, .02);
				tone(b.music, ctx, t, hz * .5, dur * 1.4, "sine", profile.bassGain * .7, .03);
			}
			if (leadIdx >= 0) {
				const semis = profile.scale[leadIdx] ?? 0;
				const hz = freq(profile.rootHz * 2, semis);
				tone(b.music, ctx, t, hz, dur, profile.leadWave, profile.leadGain, .012, 0, .12);
				tone(b.music, ctx, t, hz, dur * 1.05, profile.leadWave, profile.leadGain * .4, .016, 8, -.18);
				const fifth = freq(profile.rootHz * 2, semis + 7);
				tone(b.music, ctx, t, fifth, dur * .85, "sine", profile.leadGain * .28, .02, 0, .22);
			}
			if (arpIdx >= 0 && profile.arpGain > 0) {
				const semis = profile.scale[arpIdx] ?? 0;
				const pan = i % 2 === 0 ? -.45 : .45;
				tone(b.music, ctx, t, freq(profile.rootHz * 2, semis + 12), stepDur * .48, "sine", profile.arpGain * 1.15, .006, 0, pan);
			}
			const chordEvery = Math.max(4, Math.floor(profile.steps / 4));
			const bar = Math.floor(step / chordEvery) % profile.chords.length;
			const chord = profile.chords[bar] ?? profile.chords[0];
			if (chord && i % chordEvery === 0) {
				const hold = stepDur * chordEvery * .94;
				for (const idx of chord) {
					const semis = profile.scale[idx] ?? 0;
					const hz = freq(profile.rootHz, semis + 12);
					tone(b.pad, ctx, t, hz, hold, "sine", profile.padGain, .1);
					tone(b.pad, ctx, t, hz, hold, "sine", profile.padGain * .55, .12, -8);
					tone(b.pad, ctx, t, hz, hold, "triangle", profile.padGain * .32, .14, 11);
				}
			}
			if (groove.k[i]) {
				kick(b.music, ctx, t, .2);
				b.pad.gain.setValueAtTime(.55, t);
				b.pad.gain.setTargetAtTime(1, t + .1, .08);
			}
			if (groove.s[i]) snare(b.music, ctx, t, .11);
			if (groove.h[i]) {
				const open = i % 4 === 3;
				noiseBurst(b.music, ctx, t, open ? .08 : .03, open ? .028 : .018, 6500);
			}
			next += stepDur;
			step += 1;
		}
		schedulerTimer = setTimeout(tick, 20);
	};
	tick();
}
function playMusic(id, bpmOverride) {
	const base = MUSIC[id];
	if (!base) return;
	const profile = bpmOverride && bpmOverride !== base.bpm ? {
		...base,
		bpm: bpmOverride
	} : base;
	if (currentProfile?.id === profile.id && currentProfile.bpm === profile.bpm) return;
	unlockAudio();
	stopScheduler();
	currentProfile = profile;
	scheduleProfile(profile, musicGen);
}
function playLevelMusic(levelMusicId) {
	playMusic(levelMusicId);
}
function playInfiniteMusic(wave) {
	const id = infiniteMusicId(wave);
	const base = MUSIC[id];
	playMusic(id, infiniteBpm(wave, base?.bpm ?? 104));
}
function playTitleMusic() {
	playMusic("title");
}
function sfxShoot(weapon) {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	const map = {
		kinetic: 920,
		cryo: 640,
		resonant: 780,
		thermal: 430
	};
	tone(b.sfx, b.ctx, t, map[weapon], .1, "square", .055, .003);
	tone(b.sfx, b.ctx, t, map[weapon] * .5, .08, "sine", .04, .004);
}
function sfxHit() {
	const b = ensureBus();
	if (!b) return;
	noiseBurst(b.sfx, b.ctx, b.ctx.currentTime, .12, .08, 800);
	tone(b.sfx, b.ctx, b.ctx.currentTime, 180, .1, "sine", .06, .003);
}
function sfxResist() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	tone(b.sfx, b.ctx, t, 240, .08, "square", .045, .002);
	tone(b.sfx, b.ctx, t + .04, 180, .1, "square", .03, .002);
}
function sfxExplode(big) {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	noiseBurst(b.sfx, b.ctx, t, big ? .32 : .18, big ? .14 : .08, 200);
	tone(b.sfx, b.ctx, t, big ? 70 : 110, big ? .28 : .16, "sine", .1, .004);
}
function sfxDead() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	tone(b.sfx, b.ctx, t, 220, .4, "sawtooth", .07, .01);
	tone(b.sfx, b.ctx, t + .05, 110, .5, "sine", .08, .01);
	noiseBurst(b.sfx, b.ctx, t, .4, .1, 300);
}
function sfxSwitch() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	tone(b.sfx, b.ctx, t, 520, .06, "sine", .04, .004);
	tone(b.sfx, b.ctx, t + .05, 780, .07, "sine", .035, .004);
}
function sfxUi() {
	const b = ensureBus();
	if (!b) return;
	tone(b.sfx, b.ctx, b.ctx.currentTime, 660, .05, "sine", .03, .004);
}
function sfxClear() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	[
		0,
		4,
		7,
		12
	].forEach((s, i) => {
		tone(b.sfx, b.ctx, t + i * .08, freq(220, s), .2, "sine", .055, .01);
	});
}
function sfxLucky() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	[
		0,
		4,
		7,
		11
	].forEach((s, i) => {
		tone(b.sfx, b.ctx, t + i * .05, freq(392, s), .14, "triangle", .055, .006);
	});
}
function sfxPower() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	tone(b.sfx, b.ctx, t, 520, .12, "sine", .06, .006);
	tone(b.sfx, b.ctx, t + .06, 780, .16, "triangle", .05, .008);
}
function sfxBomb() {
	const b = ensureBus();
	if (!b) return;
	const t = b.ctx.currentTime;
	noiseBurst(b.sfx, b.ctx, t, .28, .16, 180);
	tone(b.sfx, b.ctx, t, 90, .26, "sine", .12, .004);
}
function wrapDraw(ctx, w, h, x, y, r, fn) {
	const pads = [[0, 0]];
	if (x < r) pads.push([w, 0]);
	if (x > w - r) pads.push([-w, 0]);
	if (y < r) pads.push([0, h]);
	if (y > h - r) pads.push([0, -h]);
	if (x < r && y < r) pads.push([w, h]);
	if (x > w - r && y < r) pads.push([-w, h]);
	if (x < r && y > h - r) pads.push([w, -h]);
	if (x > w - r && y > h - r) pads.push([-w, -h]);
	for (const [ox, oy] of pads) fn(x + ox, y + oy);
}
function asteroidPath(ctx, a, x, y) {
	const n = a.verts.length;
	ctx.beginPath();
	for (let i = 0; i < n; i++) {
		const ang = a.angle + i / n * Math.PI * 2;
		const rr = a.r * (a.verts[i] ?? 1);
		const px = x + Math.cos(ang) * rr;
		const py = y + Math.sin(ang) * rr;
		if (i === 0) ctx.moveTo(px, py);
		else ctx.lineTo(px, py);
	}
	ctx.closePath();
}
function drawAsteroid(ctx, a, x, y, col, fill, cut) {
	const flash = a.hitFlash > 0 ? Math.min(1, a.hitFlash * 8) : 0;
	ctx.save();
	ctx.shadowColor = col;
	ctx.shadowBlur = 10 + flash * 14;
	ctx.strokeStyle = flash ? "#f4f4f0" : col;
	ctx.lineWidth = a.size === "titan" ? 2.4 : cut === "plate" ? 2.2 : 1.6;
	ctx.globalAlpha = .95;
	asteroidPath(ctx, a, x, y);
	ctx.stroke();
	ctx.globalAlpha = fill + flash * .2;
	ctx.fillStyle = col;
	ctx.fill();
	if (a.lucky) {
		ctx.globalAlpha = .8;
		ctx.beginPath();
		for (let i = 0; i < 5; i++) {
			const ang = a.angle + i / 5 * Math.PI * 2 - Math.PI / 2;
			const rr = i % 2 === 0 ? a.r * .42 : a.r * .18;
			const px = x + Math.cos(ang) * rr;
			const py = y + Math.sin(ang) * rr;
			if (i === 0) ctx.moveTo(px, py);
			else ctx.lineTo(px, py);
		}
		ctx.closePath();
		ctx.stroke();
		ctx.restore();
		return;
	}
	if (cut === "ice" || a.kind === "rime") {
		ctx.globalAlpha = .55;
		ctx.beginPath();
		ctx.arc(x, y, a.r * .38, 0, Math.PI * 2);
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(x - a.r * .45, y);
		ctx.lineTo(x + a.r * .45, y);
		ctx.moveTo(x, y - a.r * .45);
		ctx.lineTo(x, y + a.r * .45);
		ctx.stroke();
	} else if (cut === "crystal" || a.kind === "quartz") {
		ctx.globalAlpha = .6;
		ctx.beginPath();
		const inner = a.r * .42;
		for (let i = 0; i < 3; i++) {
			const ang = a.angle + i / 3 * Math.PI * 2;
			const px = x + Math.cos(ang) * inner;
			const py = y + Math.sin(ang) * inner;
			if (i === 0) ctx.moveTo(px, py);
			else ctx.lineTo(px, py);
		}
		ctx.closePath();
		ctx.stroke();
	} else if (cut === "plate" || a.kind === "alloy") {
		ctx.globalAlpha = .5;
		ctx.strokeRect(x - a.r * .28, y - a.r * .28, a.r * .56, a.r * .56);
	} else if (cut === "ember") {
		ctx.globalAlpha = .28;
		ctx.beginPath();
		ctx.arc(x, y, a.r * .32, 0, Math.PI * 2);
		ctx.fill();
	} else {
		ctx.globalAlpha = .35;
		ctx.beginPath();
		ctx.arc(x + a.r * .15, y - a.r * .1, a.r * .22, 0, Math.PI * 2);
		ctx.stroke();
	}
	ctx.restore();
}
function drawCore(ctx, x, y, r, tint, invuln, aegisT, ward) {
	const col = tint;
	if (invuln > 0 && Math.floor(invuln * 16) % 2 === 0 && aegisT <= 0) return;
	if (aegisT > 0) {
		ctx.save();
		ctx.strokeStyle = LUCKY_COLOR;
		ctx.globalAlpha = .35 + .25 * Math.sin(aegisT * 8);
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.arc(x, y, r + 16, 0, Math.PI * 2);
		ctx.stroke();
		ctx.globalAlpha = .12;
		ctx.fillStyle = LUCKY_COLOR;
		ctx.fill();
		ctx.restore();
	} else if (ward > 0) {
		ctx.save();
		ctx.strokeStyle = "#c5cdd8";
		ctx.globalAlpha = .55;
		ctx.lineWidth = 1.6;
		ctx.setLineDash([5, 4]);
		ctx.beginPath();
		ctx.arc(x, y, r + 14, 0, Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	ctx.save();
	ctx.shadowColor = col;
	ctx.shadowBlur = 18;
	ctx.strokeStyle = "#ecece8";
	ctx.fillStyle = col;
	ctx.lineWidth = 1.8;
	ctx.beginPath();
	ctx.moveTo(x, y - r);
	ctx.lineTo(x + r * .78, y);
	ctx.lineTo(x, y + r * .72);
	ctx.lineTo(x - r * .78, y);
	ctx.closePath();
	ctx.globalAlpha = .18;
	ctx.fill();
	ctx.globalAlpha = 1;
	ctx.stroke();
	ctx.beginPath();
	ctx.moveTo(x, y - r * .42);
	ctx.lineTo(x + r * .32, y);
	ctx.lineTo(x, y + r * .28);
	ctx.lineTo(x - r * .32, y);
	ctx.closePath();
	ctx.strokeStyle = col;
	ctx.stroke();
	ctx.beginPath();
	ctx.arc(x, y, 2.4, 0, Math.PI * 2);
	ctx.fillStyle = col;
	ctx.fill();
	ctx.restore();
}
function drawBeam(ctx, beam, col, style, width, glow) {
	const a = beam.life / beam.max;
	const w = (beam.matched ? width : width * .55) * (.7 + a * .3);
	ctx.save();
	ctx.strokeStyle = col;
	ctx.shadowColor = col;
	ctx.shadowBlur = glow;
	ctx.lineCap = "round";
	if (style === "dash") ctx.setLineDash([8, 7]);
	ctx.globalAlpha = .28 + a * .72;
	ctx.lineWidth = w;
	ctx.beginPath();
	ctx.moveTo(beam.x0, beam.y0);
	ctx.lineTo(beam.x1, beam.y1);
	ctx.stroke();
	if (style === "double") {
		ctx.globalAlpha = a * .45;
		ctx.lineWidth = w * 2.4;
		ctx.stroke();
		ctx.globalAlpha = .9;
		ctx.lineWidth = Math.max(1, w * .45);
		ctx.stroke();
	} else if (style === "ribbon") {
		ctx.globalAlpha = a * .35;
		ctx.lineWidth = w * 3.2;
		ctx.stroke();
	} else if (style === "pulse") {
		ctx.globalAlpha = a * (.35 + .25 * Math.sin(a * 18));
		ctx.lineWidth = w * 2.8;
		ctx.stroke();
	} else if (style === "spark") {
		ctx.globalAlpha = a * .9;
		const mx = (beam.x0 + beam.x1) / 2;
		const my = (beam.y0 + beam.y1) / 2;
		const dx = beam.x1 - beam.x0;
		const dy = beam.y1 - beam.y0;
		const len = Math.hypot(dx, dy) || 1;
		const nx = -dy / len;
		const ny = dx / len;
		ctx.beginPath();
		ctx.moveTo(mx + nx * 7, my + ny * 7);
		ctx.lineTo(mx - nx * 7, my - ny * 7);
		ctx.lineWidth = 1.4;
		ctx.stroke();
	}
	ctx.globalAlpha = a * .45;
	ctx.lineWidth = beam.matched ? w * 2.6 : w * 1.8;
	ctx.stroke();
	ctx.restore();
}
function renderWorld(ctx, world) {
	const { w, h } = world;
	ctx.save();
	ctx.translate(world.shakeX, world.shakeY);
	ctx.rotate(world.shakeRot);
	ctx.fillStyle = "#08080a";
	ctx.fillRect(-20, -20, w + 40, h + 40);
	const g = ctx.createRadialGradient(w * .5, h * .42, 20, w * .5, h * .5, h * .78);
	g.addColorStop(0, "rgba(18, 22, 28, 0.55)");
	g.addColorStop(1, "rgba(8, 8, 10, 0)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, w, h);
	for (const s of world.stars) {
		ctx.globalAlpha = .25 + s.z * .7;
		ctx.fillStyle = s.z > .7 ? "#ecece8" : "#8a8a92";
		ctx.fillRect(s.x, s.y, s.s, s.s);
	}
	ctx.globalAlpha = 1;
	for (const p of world.particles) {
		if (!p.alive) continue;
		const a = p.life / p.max;
		ctx.globalAlpha = a;
		ctx.fillStyle = p.color;
		if (p.glow) {
			ctx.shadowColor = p.color;
			ctx.shadowBlur = 8;
		}
		ctx.beginPath();
		ctx.arc(p.x, p.y, p.size * (.4 + a), 0, Math.PI * 2);
		ctx.fill();
		ctx.shadowBlur = 0;
	}
	ctx.globalAlpha = 1;
	for (const beam of world.beams) {
		if (!beam.alive) continue;
		drawBeam(ctx, beam, world.overchargeT > 0 ? LUCKY_COLOR : beam.tint || world.weaponColors[beam.weapon], world.beamStyle, world.beamWidth, world.beamGlow);
	}
	if (world.showCore && world.reach > 0) {
		ctx.save();
		ctx.strokeStyle = world.skinCore;
		ctx.globalAlpha = .18;
		ctx.lineWidth = 1.2;
		ctx.setLineDash([6, 10]);
		ctx.beginPath();
		ctx.arc(world.coreX, world.coreY, world.reach, 0, Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	for (const a of world.asteroids) wrapDraw(ctx, w, h, a.x, a.y, a.r + 8, (x, y) => drawAsteroid(ctx, a, x, y, a.lucky ? LUCKY_COLOR : world.kindColors[a.kind], world.rockFill, world.rockCut));
	if (world.hover) {
		const a = world.hover;
		const dx = a.x - world.coreX;
		const dy = a.y - world.coreY;
		const inR = Math.hypot(dx, dy) <= world.reach + 6;
		const col = a.lucky || world.overchargeT > 0 ? LUCKY_COLOR : world.kindColors[a.kind];
		ctx.save();
		ctx.strokeStyle = inR ? col : "#c45c4a";
		ctx.globalAlpha = .7;
		ctx.lineWidth = 1.4;
		ctx.setLineDash([4, 4]);
		ctx.beginPath();
		ctx.arc(a.x, a.y, a.r + 8, 0, Math.PI * 2);
		ctx.stroke();
		ctx.restore();
	}
	if (world.showCore) drawCore(ctx, world.coreX, world.coreY, world.coreR, world.skinCore, world.coreInvuln, world.aegisT, world.ward);
	if (world.pointer && world.showCore) {
		const col = world.overchargeT > 0 ? LUCKY_COLOR : world.weaponColors[world.weapon];
		ctx.save();
		ctx.strokeStyle = col;
		ctx.globalAlpha = .7;
		ctx.lineWidth = 1.2;
		ctx.beginPath();
		ctx.arc(world.pointer.x, world.pointer.y, 9, 0, Math.PI * 2);
		ctx.stroke();
		ctx.beginPath();
		ctx.moveTo(world.pointer.x - 13, world.pointer.y);
		ctx.lineTo(world.pointer.x - 4, world.pointer.y);
		ctx.moveTo(world.pointer.x + 4, world.pointer.y);
		ctx.lineTo(world.pointer.x + 13, world.pointer.y);
		ctx.moveTo(world.pointer.x, world.pointer.y - 13);
		ctx.lineTo(world.pointer.x, world.pointer.y - 4);
		ctx.moveTo(world.pointer.x, world.pointer.y + 4);
		ctx.lineTo(world.pointer.x, world.pointer.y + 13);
		ctx.stroke();
		ctx.restore();
	}
	ctx.font = "600 13px 'IBM Plex Sans', sans-serif";
	ctx.textAlign = "center";
	for (const f of world.floaters) {
		if (!f.alive) continue;
		ctx.globalAlpha = Math.min(1, f.life / (f.max * .4));
		ctx.fillStyle = f.color;
		ctx.fillText(f.text, f.x, f.y);
	}
	ctx.globalAlpha = 1;
	if (world.flash > 0) {
		ctx.fillStyle = `rgba(236, 236, 232, ${world.flash * .18})`;
		ctx.fillRect(0, 0, w, h);
	}
	ctx.restore();
}
function rand(a, b) {
	return a + Math.random() * (b - a);
}
function wrap(v, max) {
	if (v < 0) return v + max;
	if (v >= max) return v - max;
	return v;
}
function wrapDelta(a, b, size) {
	let d = a - b;
	if (d > size * .5) d -= size;
	if (d < -size * .5) d += size;
	return d;
}
function makeVerts(kind, n, cut) {
	const verts = [];
	for (let i = 0; i < n; i++) {
		let jag;
		if (cut === "plate") jag = rand(.9, 1.04);
		else if (cut === "cut") jag = rand(.82, 1.08);
		else if (cut === "crystal") jag = i % 2 === 0 ? rand(1.02, 1.2) : rand(.62, .82);
		else if (cut === "ice") jag = rand(.86, 1.06);
		else if (cut === "ember") jag = rand(.74, 1.16);
		else jag = kind === "alloy" ? rand(.88, 1.05) : kind === "quartz" ? rand(.72, 1.18) : kind === "rime" ? rand(.84, 1.08) : rand(.7, 1.2);
		verts.push(jag);
	}
	return verts;
}
function nextSize(s) {
	if (s === "titan" || s === "large") return "medium";
	if (s === "medium") return "small";
	return null;
}
function createGame(canvas, opts) {
	const maybeCtx = canvas.getContext("2d");
	if (!maybeCtx) throw new Error("Canvas 2D is not available");
	const ctx = maybeCtx;
	let w = 800;
	let h = 600;
	let coreX = 400;
	let coreY = 540;
	let running = false;
	let paused = false;
	let raf = 0;
	let acc = 0;
	let last = 0;
	let fireCd = 0;
	let score = 0;
	let lives = 3;
	let combo = 0;
	let remaining = 0;
	let wave = 1;
	let trauma = 0;
	let flash = 0;
	let freeze = 0;
	let briefingT = 2.6;
	let ended = false;
	let coreInvuln = 0;
	let sessionFrags = 0;
	let luckySpawned = 0;
	let aegisT = 0;
	let ward = 0;
	let overchargeT = 0;
	let fragMulT = 0;
	let waveClearT = 0;
	let pendingNextWave = false;
	let playTime = 0;
	const skin = skinById(opts.skinId);
	const pal = livePalette(opts.laserId, opts.packId);
	let timeScale = opts.timeScale === 2 ? 2 : 1;
	let weapon = "kinetic";
	const unlocked = opts.mode === "infinite" ? [...WEAPON_ORDER] : unlockedWeapons(opts.campaignReached);
	if (!unlocked.includes(weapon)) weapon = unlocked[0] ?? "kinetic";
	const keys = /* @__PURE__ */ new Set();
	let listenersOn = false;
	let padPrev = {
		bumpL: false,
		bumpR: false,
		start: false
	};
	let pointer = null;
	let hover = null;
	const asteroids = [];
	const beams = Array.from({ length: 24 }, () => ({
		alive: false,
		x0: 0,
		y0: 0,
		x1: 0,
		y1: 0,
		life: 0,
		max: .12,
		weapon: "kinetic",
		matched: false,
		tint: "#ecece8"
	}));
	const particles = Array.from({ length: 420 }, () => ({
		alive: false,
		x: 0,
		y: 0,
		vx: 0,
		vy: 0,
		life: 0,
		max: 1,
		size: 1,
		color: "#ecece8",
		glow: false
	}));
	const floaters = Array.from({ length: 40 }, () => ({
		alive: false,
		x: 0,
		y: 0,
		vy: 0,
		life: 0,
		max: 1,
		text: "",
		color: "#ecece8"
	}));
	let stars = [];
	const level = LEVELS[Math.max(0, opts.levelIndex)] ?? LEVELS[0];
	const hudListeners = /* @__PURE__ */ new Set();
	function emitHud() {
		opts.onHud(getHud());
		hudListeners.forEach((fn) => fn());
	}
	function getHud() {
		return {
			score,
			lives,
			combo,
			multiplier: 1 + Math.min(4, Math.floor(combo / 4)),
			weapon,
			unlocked,
			levelName: opts.mode === "infinite" ? `Wave ${wave}` : opts.mode === "attract" ? "VOID PRISM" : level?.name ?? "",
			levelId: level?.id ?? 0,
			remaining,
			wave,
			mode: opts.mode,
			briefing: opts.mode === "campaign" ? level?.briefing ?? "" : "Click in range. Lucky rocks drop gear.",
			briefingT,
			shake: opts.shakeEnabled,
			muted: opts.muted,
			sessionFrags,
			aegisT,
			ward,
			overchargeT,
			fragMulT,
			waveClearT,
			reach: reachR(),
			playTime
		};
	}
	function reachR() {
		return Math.min(w, h) * REACH_FRAC;
	}
	function resize() {
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const rect = canvas.getBoundingClientRect();
		w = Math.max(1, Math.floor(rect.width));
		h = Math.max(1, Math.floor(rect.height));
		canvas.width = Math.floor(w * dpr);
		canvas.height = Math.floor(h * dpr);
		ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		coreX = w * .5;
		coreY = h * .48;
		stars = Array.from({ length: 90 }, () => ({
			x: Math.random() * w,
			y: Math.random() * h,
			z: Math.random(),
			s: Math.random() < .2 ? 2 : 1
		}));
	}
	function spawnParticle(x, y, color, n, speed, glow) {
		let left = n;
		for (const p of particles) {
			if (left <= 0) break;
			if (p.alive) continue;
			const ang = Math.random() * Math.PI * 2;
			const sp = rand(speed * .2, speed);
			p.alive = true;
			p.x = x;
			p.y = y;
			p.vx = Math.cos(ang) * sp;
			p.vy = Math.sin(ang) * sp;
			p.max = rand(.25, .7);
			p.life = p.max;
			p.size = rand(.8, 2.4);
			p.color = color;
			p.glow = glow;
			left -= 1;
		}
	}
	function spawnFloater(x, y, text, color) {
		const f = floaters.find((it) => !it.alive);
		if (!f) return;
		f.alive = true;
		f.x = x;
		f.y = y;
		f.vy = -28;
		f.max = .85;
		f.life = f.max;
		f.text = text;
		f.color = color;
	}
	function spawnBeam(x1, y1, matched, tint) {
		const slot = beams.find((b) => !b.alive);
		if (!slot) return;
		slot.alive = true;
		slot.x0 = coreX;
		slot.y0 = coreY;
		slot.x1 = x1;
		slot.y1 = y1;
		slot.max = matched ? .14 : .1;
		slot.life = slot.max;
		slot.weapon = weapon;
		slot.matched = matched;
		slot.tint = tint ?? pal.weapon[weapon];
	}
	function edgePoint() {
		const e = Math.floor(Math.random() * 3);
		if (e === 0) return {
			x: rand(40, w - 40),
			y: -16
		};
		if (e === 1) return {
			x: -16,
			y: rand(20, h * .55)
		};
		return {
			x: w + 16,
			y: rand(20, h * .55)
		};
	}
	function spawnAsteroid(kind, size, x, y, vx, vy) {
		const pos = x === void 0 || y === void 0 ? edgePoint() : {
			x,
			y
		};
		if (opts.mode !== "attract") {
			const dx = pos.x - coreX;
			const dy = pos.y - coreY;
			if (Math.hypot(dx, dy) < 160) {
				const p2 = edgePoint();
				pos.x = p2.x;
				pos.y = p2.y;
			}
		}
		const speedMul = size === "small" ? 1.4 : size === "medium" ? 1.12 : 1;
		const spec = opts.mode === "infinite" ? infiniteSpec() : null;
		const spd = (opts.mode === "infinite" ? spec?.speed ?? 22 : opts.mode === "attract" ? 28 : level?.speed ?? 48) * speedMul * rand(.75, 1.15);
		const ang = Math.random() * Math.PI * 2;
		asteroids.push({
			x: pos.x,
			y: pos.y,
			vx: vx ?? Math.cos(ang) * spd,
			vy: vy ?? Math.sin(ang) * spd * .65 + spd * .25,
			spin: rand(-1.2, 1.2),
			angle: Math.random() * Math.PI * 2,
			r: SIZE_R[size],
			kind,
			size,
			verts: makeVerts(kind, size === "titan" ? 12 : kind === "alloy" ? 8 : kind === "quartz" ? 6 : 9, pal.pack.cut),
			seed: Math.random(),
			hitFlash: 0,
			lucky: false
		});
	}
	function spawnLucky() {
		if (luckySpawned >= 5) return;
		luckySpawned += 1;
		const pos = edgePoint();
		const spd = 26 + wave * 2;
		const ang = Math.random() * Math.PI * 2;
		asteroids.push({
			x: pos.x,
			y: pos.y,
			vx: Math.cos(ang) * spd,
			vy: Math.sin(ang) * spd * .5 + 18,
			spin: rand(-1.6, 1.6),
			angle: Math.random() * Math.PI * 2,
			r: 20,
			kind: "basalt",
			size: "medium",
			verts: makeVerts("quartz", 7, pal.pack.cut),
			seed: Math.random(),
			hitFlash: 0,
			lucky: true
		});
	}
	function maybeLucky() {
		if (opts.mode === "attract") return;
		if (luckySpawned >= 5) return;
		if (Math.random() > .05) return;
		spawnLucky();
	}
	function infiniteSpec() {
		return {
			kinds: wave <= 1 ? ["basalt"] : wave === 2 ? ["basalt", "rime"] : wave <= 4 ? [
				"basalt",
				"rime",
				"quartz"
			] : [
				"basalt",
				"rime",
				"quartz",
				"alloy"
			],
			count: Math.min(16, 2 + wave),
			speed: 18 + wave * 3.2,
			pull: 3.2 + wave * 1.05,
			titan: wave >= 6 && wave % 3 === 0
		};
	}
	function seedField() {
		asteroids.length = 0;
		luckySpawned = 0;
		pendingNextWave = false;
		waveClearT = 0;
		if (opts.mode === "attract") {
			const kinds = [
				"basalt",
				"rime",
				"quartz",
				"alloy"
			];
			for (let i = 0; i < 8; i++) spawnAsteroid(kinds[i % 4], i % 3 === 0 ? "large" : "medium");
			remaining = asteroids.length;
			return;
		}
		if (opts.mode === "infinite") {
			const spec = infiniteSpec();
			for (let i = 0; i < spec.count; i++) {
				const size = spec.titan && i < 2 ? "titan" : wave <= 2 ? "medium" : "large";
				spawnAsteroid(spec.kinds[i % spec.kinds.length], size);
				maybeLucky();
			}
			remaining = asteroids.length;
			opts.onWave(wave);
			playInfiniteMusic(wave);
			briefingT = 1.8;
			return;
		}
		const kinds = level?.kinds ?? ["basalt"];
		const n = level?.large ?? 4;
		for (let i = 0; i < n; i++) {
			const kind = kinds[i % kinds.length];
			spawnAsteroid(kind, level?.titan ? "titan" : "large");
			maybeLucky();
		}
		remaining = asteroids.length;
		playLevelMusic(level?.music ?? "shale");
	}
	function addScore(n, x, y) {
		const mul = 1 + Math.min(4, Math.floor(combo / 4));
		const got = n * mul;
		score += got;
		spawnFloater(x, y - 8, mul > 1 ? `${got} ×${mul}` : `${got}`, "#ecece8");
	}
	function addFrags(n, x, y) {
		const got = Math.max(0, Math.round(n * (fragMulT > 0 ? 2 : 1)));
		if (got <= 0) return;
		sessionFrags += got;
		opts.onFragments(got);
		spawnFloater(x, y + 10, `+${got} FRAG`, LUCKY_COLOR);
	}
	function splitAsteroid(a) {
		const next = nextSize(a.size);
		const idx = asteroids.indexOf(a);
		if (idx >= 0) asteroids.splice(idx, 1);
		remaining = asteroids.length;
		if (!next) return;
		const kick = 70;
		const ang = Math.atan2(a.vy, a.vx);
		spawnAsteroid(a.kind, next, a.x, a.y, a.vx + Math.cos(ang + .9) * kick, a.vy + Math.sin(ang + .9) * kick);
		spawnAsteroid(a.kind, next, a.x, a.y, a.vx + Math.cos(ang - .9) * kick, a.vy + Math.sin(ang - .9) * kick);
		remaining = asteroids.length;
	}
	function grantDrop(id, x, y) {
		if (id === "aegis") {
			aegisT = 30;
			spawnFloater(x, y - 18, DROP_LABEL[id], LUCKY_COLOR);
		} else if (id === "ward") {
			ward = 1;
			spawnFloater(x, y - 18, DROP_LABEL[id], "#c5cdd8");
		} else if (id === "overcharge") {
			overchargeT = 5;
			spawnFloater(x, y - 18, DROP_LABEL[id], "#e8a070");
		} else if (id === "frag2x") {
			fragMulT = 10;
			spawnFloater(x, y - 18, DROP_LABEL[id], LUCKY_COLOR);
		} else if (id === "bomb") {
			spawnFloater(x, y - 18, DROP_LABEL[id], "#c45c4a");
			detonate(x, y);
		}
		if (id !== "bomb") sfxPower();
		emitHud();
	}
	function detonate(x, y) {
		sfxBomb();
		spawnParticle(x, y, "#c45c4a", 36, 220, true);
		trauma = Math.min(1, trauma + .55);
		flash = .5;
		const hit = asteroids.filter((a) => {
			const dx = wrapDelta(x, a.x, w);
			const dy = wrapDelta(y, a.y, h);
			return Math.hypot(dx, dy) <= 150;
		});
		for (const a of hit) smash(a, true);
	}
	function smash(a, fromBomb) {
		if (!asteroids.includes(a)) return;
		if (a.lucky) {
			const idx = asteroids.indexOf(a);
			if (idx >= 0) asteroids.splice(idx, 1);
			remaining = asteroids.length;
			combo += 1;
			addScore(80, a.x, a.y);
			addFrags(2, a.x, a.y);
			spawnParticle(a.x, a.y, LUCKY_COLOR, 22, 160, true);
			sfxLucky();
			if (!fromBomb) grantDrop(DROPS[Math.floor(Math.random() * DROPS.length)] ?? "ward", a.x, a.y);
			return;
		}
		destroyAsteroid(a);
	}
	function destroyAsteroid(a) {
		combo += 1;
		addScore(SIZE_SCORE[a.size], a.x, a.y);
		addFrags(SIZE_FRAG[a.size], a.x, a.y);
		spawnParticle(a.x, a.y, pal.kind[a.kind], a.size === "titan" ? 28 : 16, 140, true);
		sfxExplode(a.size === "titan" || a.size === "large");
		trauma = Math.min(1, trauma + (a.size === "titan" ? .5 : a.size === "large" ? .28 : .16));
		freeze = a.size === "titan" ? .06 : .03;
		flash = .28;
		splitAsteroid(a);
	}
	function pickAsteroid(x, y) {
		let best = null;
		let bestD = 1e9;
		for (const a of asteroids) {
			const dx = wrapDelta(x, a.x, w);
			const dy = wrapDelta(y, a.y, h);
			const d = Math.hypot(dx, dy);
			if (d < a.r + 34 && d < bestD) {
				best = a;
				bestD = d;
			}
		}
		return best;
	}
	function inReach(x, y) {
		const dx = wrapDelta(x, coreX, w);
		const dy = wrapDelta(y, coreY, h);
		return Math.hypot(dx, dy) <= reachR() + 6;
	}
	function fireAt(x, y) {
		if (opts.mode === "attract" || ended || paused || pendingNextWave) return;
		if (fireCd > 0) return;
		fireCd = FIRE_COOLDOWN;
		const a = pickAsteroid(x, y);
		if (!a) {
			spawnBeam(x, y, false, pal.weapon[weapon]);
			sfxShoot(weapon);
			return;
		}
		if (!inReach(a.x, a.y)) {
			spawnBeam(a.x, a.y, false, pal.kind[a.kind]);
			spawnFloater(a.x, a.y - a.r, "OUT OF RANGE", "#c45c4a");
			sfxResist();
			emitHud();
			return;
		}
		const matched = a.lucky || overchargeT > 0 || MATCH[a.kind] === weapon;
		const tint = a.lucky ? LUCKY_COLOR : pal.kind[a.kind];
		spawnBeam(a.x, a.y, matched, tint);
		sfxShoot(weapon);
		if (matched) {
			sfxHit();
			smash(a, false);
		} else {
			combo = 0;
			a.hitFlash = .18;
			spawnParticle(a.x, a.y, pal.kind[a.kind], 6, 70, true);
			spawnFloater(a.x, a.y - a.r, "RESIST", pal.kind[a.kind]);
			sfxResist();
			trauma = Math.min(1, trauma + .08);
		}
		emitHud();
	}
	function coreHit(a) {
		if (ended || opts.mode === "attract") return;
		const idx = asteroids.indexOf(a);
		if (idx >= 0) asteroids.splice(idx, 1);
		remaining = asteroids.length;
		spawnParticle(a.x, a.y, a.lucky ? LUCKY_COLOR : pal.kind[a.kind], 18, 160, true);
		if (aegisT > 0) {
			spawnFloater(coreX, coreY - 40, "AEGIS", LUCKY_COLOR);
			trauma = .25;
			emitHud();
			return;
		}
		if (ward > 0) {
			ward = 0;
			coreInvuln = CORE_INVULN;
			spawnFloater(coreX, coreY - 40, "WARD", "#c5cdd8");
			sfxPower();
			trauma = .4;
			emitHud();
			return;
		}
		if (coreInvuln > 0) return;
		lives -= 1;
		combo = 0;
		coreInvuln = CORE_INVULN;
		sfxDead();
		spawnParticle(coreX, coreY, skin.core, 22, 150, true);
		trauma = .85;
		flash = .65;
		freeze = .1;
		if (lives <= 0) {
			ended = true;
			opts.onGameOver(score, wave);
			emitHud();
			return;
		}
		emitHud();
	}
	function cycleWeapon(dir) {
		if (unlocked.length === 0) return;
		const i = unlocked.indexOf(weapon);
		const next = unlocked[(i + dir + unlocked.length) % unlocked.length];
		if (next && next !== weapon) {
			weapon = next;
			sfxSwitch();
			emitHud();
		}
	}
	function setWeapon(w) {
		if (!unlocked.includes(w) || w === weapon) return;
		weapon = w;
		sfxSwitch();
		emitHud();
	}
	function eventToWorld(e) {
		const rect = canvas.getBoundingClientRect();
		return {
			x: e.clientX - rect.left,
			y: e.clientY - rect.top
		};
	}
	function gravity() {
		if (opts.mode === "infinite") return infiniteSpec().pull;
		if (opts.mode === "campaign") return 8 + (level?.id ?? 1) * .8;
		return 0;
	}
	function step(dt) {
		if (ended) return;
		if (freeze > 0) {
			freeze -= dt;
			return;
		}
		resumeAudio();
		briefingT = Math.max(0, briefingT - dt);
		if (briefingT === 0 && !pendingNextWave) playTime += dt;
		fireCd = Math.max(0, fireCd - dt);
		coreInvuln = Math.max(0, coreInvuln - dt);
		aegisT = Math.max(0, aegisT - dt);
		overchargeT = Math.max(0, overchargeT - dt);
		fragMulT = Math.max(0, fragMulT - dt);
		trauma = Math.max(0, trauma - dt * 1.8);
		flash = Math.max(0, flash - dt * 2.2);
		if (pendingNextWave) {
			waveClearT = Math.max(0, waveClearT - dt);
			for (const p of particles) {
				if (!p.alive) continue;
				p.life -= dt;
				if (p.life <= 0) p.alive = false;
				else {
					p.x += p.vx * dt;
					p.y += p.vy * dt;
				}
			}
			for (const f of floaters) {
				if (!f.alive) continue;
				f.life -= dt;
				if (f.life <= 0) f.alive = false;
				else f.y += f.vy * dt;
			}
			for (const b of beams) {
				if (!b.alive) continue;
				b.life -= dt;
				if (b.life <= 0) b.alive = false;
			}
			if (waveClearT <= 0) {
				pendingNextWave = false;
				wave += 1;
				seedField();
				emitHud();
			} else emitHud();
			return;
		}
		const pads = navigator.getGamepads?.() ?? [];
		for (const pad of pads) {
			if (!pad) continue;
			const bumpL = pad.buttons[4]?.pressed ?? false;
			const bumpR = pad.buttons[5]?.pressed ?? false;
			const start = pad.buttons[9]?.pressed ?? false;
			if (bumpL && !padPrev.bumpL) cycleWeapon(-1);
			if (bumpR && !padPrev.bumpR) cycleWeapon(1);
			if (start && !padPrev.start) opts.onPause?.();
			padPrev = {
				bumpL,
				bumpR,
				start
			};
		}
		const pull = gravity();
		for (const a of asteroids) {
			if (pull > 0) {
				const dx = wrapDelta(coreX, a.x, w);
				const dy = wrapDelta(coreY, a.y, h);
				const d = Math.hypot(dx, dy) || 1;
				a.vx += dx / d * pull * dt;
				a.vy += dy / d * pull * dt;
			}
			a.x = wrap(a.x + a.vx * dt, w);
			a.y = wrap(a.y + a.vy * dt, h);
			a.angle += a.spin * dt;
			a.hitFlash = Math.max(0, a.hitFlash - dt);
		}
		for (const b of beams) {
			if (!b.alive) continue;
			b.life -= dt;
			if (b.life <= 0) b.alive = false;
		}
		for (const p of particles) {
			if (!p.alive) continue;
			p.life -= dt;
			if (p.life <= 0) {
				p.alive = false;
				continue;
			}
			p.x += p.vx * dt;
			p.y += p.vy * dt;
		}
		for (const f of floaters) {
			if (!f.alive) continue;
			f.life -= dt;
			if (f.life <= 0) {
				f.alive = false;
				continue;
			}
			f.y += f.vy * dt;
		}
		hover = pointer ? pickAsteroid(pointer.x, pointer.y) : null;
		if (opts.mode === "attract") return;
		if (aegisT > 0 || coreInvuln <= 0) for (const a of asteroids) {
			const dx = wrapDelta(coreX, a.x, w);
			const dy = wrapDelta(coreY, a.y, h);
			if (dx * dx + dy * dy < (a.r + 22) * (a.r + 22)) {
				coreHit(a);
				break;
			}
		}
		remaining = asteroids.length;
		if (remaining === 0 && !ended) {
			if (opts.mode === "campaign") {
				ended = true;
				sfxClear();
				addFrags(4 * (level?.id ?? 1), coreX, coreY);
				const timeMs = Math.max(400, Math.round(playTime * 1e3));
				if ((level?.id ?? 1) >= LEVELS.length) opts.onVictory(score, timeMs);
				else opts.onLevelClear(score, timeMs);
			} else if (opts.mode === "infinite") {
				pendingNextWave = true;
				waveClearT = 2.4;
				sfxClear();
				addFrags(2 + wave, coreX, coreY);
				spawnFloater(coreX, coreY - 48, `WAVE ${wave} CLEARED`, LUCKY_COLOR);
				emitHud();
			}
		}
		if (aegisT > 0 || overchargeT > 0 || fragMulT > 0) emitHud();
	}
	function noise(t) {
		return Math.sin(t * 17.2) * .5 + Math.sin(t * 9.1 + 1.7) * .5;
	}
	function draw(now) {
		const shake = opts.shakeEnabled ? trauma * trauma : 0;
		renderWorld(ctx, {
			w,
			h,
			coreX,
			coreY,
			coreR: 22,
			coreInvuln,
			asteroids,
			beams,
			particles,
			floaters,
			weapon,
			hover: opts.mode === "attract" ? null : hover,
			pointer: opts.mode === "attract" ? null : pointer,
			shakeX: shake * 10 * noise(now * .01),
			shakeY: shake * 10 * noise(now * .013 + 20),
			shakeRot: shake * .02 * noise(now * .008 + 4),
			flash,
			stars,
			showCore: opts.mode !== "attract",
			reach: opts.mode === "attract" ? 0 : reachR(),
			aegisT,
			ward,
			overchargeT,
			skinCore: skin.core,
			skinBeam: skin.beam,
			kindColors: pal.kind,
			weaponColors: pal.weapon,
			beamStyle: pal.laser.style,
			beamWidth: pal.laser.width,
			beamGlow: pal.laser.glow,
			rockFill: pal.pack.fill,
			rockCut: pal.pack.cut
		});
	}
	function frame(now) {
		if (!running) return;
		const dt = Math.min(.1, (now - last) / 1e3);
		last = now;
		if (!paused && !ended) {
			acc += dt * timeScale;
			while (acc >= FIXED) {
				step(FIXED);
				acc -= FIXED;
			}
		} else if (paused) {
			const pads = navigator.getGamepads?.() ?? [];
			for (const pad of pads) {
				if (!pad) continue;
				const start = pad.buttons[9]?.pressed ?? false;
				if (start && !padPrev.start) opts.onPause?.();
				padPrev = {
					...padPrev,
					start
				};
			}
		}
		draw(now);
		raf = requestAnimationFrame(frame);
	}
	function onKeyDown(e) {
		if (GAME_KEYS.has(e.code)) e.preventDefault();
		keys.add(e.code);
		if (e.repeat) return;
		if (e.code === "KeyQ") cycleWeapon(-1);
		if (e.code === "KeyE") cycleWeapon(1);
		if (e.code === "Digit1") setWeapon("kinetic");
		if (e.code === "Digit2") setWeapon("cryo");
		if (e.code === "Digit3") setWeapon("resonant");
		if (e.code === "Digit4") setWeapon("thermal");
		if (e.code === "KeyP" || e.code === "Escape") {
			if (opts.mode === "attract" || ended) return;
			opts.onPause?.();
		}
	}
	function onKeyUp(e) {
		keys.delete(e.code);
	}
	function onBlur() {
		keys.clear();
	}
	function onWheel(e) {
		if (opts.mode === "attract") return;
		e.preventDefault();
		cycleWeapon(e.deltaY > 0 ? 1 : -1);
	}
	function onPointerMove(e) {
		pointer = eventToWorld(e);
	}
	function onPointerDown(e) {
		if (e.button !== void 0 && e.button !== 0) return;
		const p = eventToWorld(e);
		pointer = p;
		fireAt(p.x, p.y);
	}
	function onPointerLeave() {
		pointer = null;
		hover = null;
	}
	function bind() {
		if (listenersOn) return;
		listenersOn = true;
		window.addEventListener("keydown", onKeyDown);
		window.addEventListener("keyup", onKeyUp);
		window.addEventListener("blur", onBlur);
		document.addEventListener("visibilitychange", onBlur);
		canvas.addEventListener("wheel", onWheel, { passive: false });
		canvas.addEventListener("pointermove", onPointerMove);
		canvas.addEventListener("pointerdown", onPointerDown);
		canvas.addEventListener("pointerleave", onPointerLeave);
		window.addEventListener("resize", resize);
		canvas.style.cursor = opts.mode === "attract" || window.matchMedia("(pointer: coarse)").matches ? "crosshair" : "none";
	}
	function unbind() {
		if (!listenersOn) return;
		listenersOn = false;
		window.removeEventListener("keydown", onKeyDown);
		window.removeEventListener("keyup", onKeyUp);
		window.removeEventListener("blur", onBlur);
		document.removeEventListener("visibilitychange", onBlur);
		canvas.removeEventListener("wheel", onWheel);
		canvas.removeEventListener("pointermove", onPointerMove);
		canvas.removeEventListener("pointerdown", onPointerDown);
		canvas.removeEventListener("pointerleave", onPointerLeave);
		window.removeEventListener("resize", resize);
		canvas.style.cursor = "default";
	}
	function pause() {
		paused = true;
		emitHud();
	}
	function resume() {
		paused = false;
		last = performance.now();
		emitHud();
	}
	function setTimeScale(n) {
		timeScale = n === 2 ? 2 : 1;
	}
	function start() {
		running = true;
		paused = false;
		ended = false;
		resize();
		seedField();
		bind();
		last = performance.now();
		emitHud();
		if (opts.mode === "attract") playTitleMusic();
		raf = requestAnimationFrame(frame);
	}
	function destroy() {
		running = false;
		cancelAnimationFrame(raf);
		unbind();
	}
	return {
		start,
		destroy,
		pause,
		resume,
		setWeapon,
		cycleWeapon,
		setTimeScale,
		getHud,
		subscribe: (fn) => {
			hudListeners.add(fn);
			return () => hudListeners.delete(fn);
		}
	};
}
var KEY = "void-prism-save-v4";
var SAVE_VERSION = 4;
function clamp01(n, fallback) {
	const v = Number(n);
	if (!Number.isFinite(v)) return fallback;
	return Math.max(0, Math.min(1, v));
}
var DEFAULTS = {
	version: SAVE_VERSION,
	campaignReached: 1,
	campaignBest: 0,
	infiniteBest: 0,
	infiniteBestWave: 0,
	muted: false,
	shake: true,
	musicVol: .72,
	sfxVol: .88,
	timeScale: 1,
	fragments: 0,
	ownedSkins: ["prism"],
	equippedSkin: "prism",
	ownedLasers: [DEFAULT_LASER_ID],
	equippedLaser: DEFAULT_LASER_ID,
	ownedPacks: [DEFAULT_PACK_ID],
	equippedPack: DEFAULT_PACK_ID,
	campaignTimes: {}
};
function isSkin(id) {
	return SKINS.some((s) => s.id === id);
}
function parseTimes(raw) {
	if (!raw || typeof raw !== "object") return {};
	const out = {};
	for (const [k, v] of Object.entries(raw)) {
		const id = Number(k);
		const ms = Number(v);
		if (id >= 1 && id <= LEVELS.length && Number.isFinite(ms) && ms > 0) out[id] = Math.floor(ms);
	}
	return out;
}
function uniqKeep(ids, fallback) {
	const out = [];
	for (const id of ids) if (!out.includes(id)) out.push(id);
	if (!out.includes(fallback)) out.unshift(fallback);
	return out;
}
function migrate(raw) {
	const owned = (Array.isArray(raw.ownedSkins) ? raw.ownedSkins : ["prism"]).filter(isSkin);
	if (!owned.includes("prism")) owned.unshift("prism");
	const equipped = raw.equippedSkin && owned.includes(raw.equippedSkin) ? raw.equippedSkin : "prism";
	const lasers = uniqKeep((Array.isArray(raw.ownedLasers) ? raw.ownedLasers : [DEFAULT_LASER_ID]).filter(isLaserId), DEFAULT_LASER_ID);
	const packs = uniqKeep((Array.isArray(raw.ownedPacks) ? raw.ownedPacks : [DEFAULT_PACK_ID]).filter(isPackId), DEFAULT_PACK_ID);
	const equippedLaser = raw.equippedLaser && lasers.includes(raw.equippedLaser) ? raw.equippedLaser : DEFAULT_LASER_ID;
	const equippedPack = raw.equippedPack && packs.includes(raw.equippedPack) ? raw.equippedPack : DEFAULT_PACK_ID;
	return {
		...DEFAULTS,
		...raw,
		ownedSkins: owned,
		equippedSkin: equipped,
		ownedLasers: lasers,
		equippedLaser,
		ownedPacks: packs,
		equippedPack,
		musicVol: clamp01(raw.musicVol, DEFAULTS.musicVol),
		sfxVol: clamp01(raw.sfxVol, DEFAULTS.sfxVol),
		timeScale: raw.timeScale === 2 ? 2 : 1,
		fragments: Math.max(0, Math.floor(raw.fragments ?? 0)),
		campaignReached: Math.max(1, Math.floor(raw.campaignReached ?? 1)),
		infiniteBestWave: Math.max(0, Math.floor(raw.infiniteBestWave ?? 0)),
		campaignTimes: parseTimes(raw.campaignTimes),
		version: SAVE_VERSION
	};
}
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY) ?? localStorage.getItem("void-prism-save-v3") ?? localStorage.getItem("void-prism-save-v2") ?? localStorage.getItem("void-prism-save-v1");
		if (!raw) return {
			...DEFAULTS,
			ownedSkins: ["prism"]
		};
		return migrate(JSON.parse(raw));
	} catch {
		return {
			...DEFAULTS,
			ownedSkins: ["prism"]
		};
	}
}
function writeSave(patch) {
	const next = migrate({
		...loadSave(),
		...patch
	});
	try {
		localStorage.setItem(KEY, JSON.stringify(next));
	} catch {}
	return next;
}
function mergeSaves(local, remote) {
	const owned = Array.from(/* @__PURE__ */ new Set([...local.ownedSkins, ...remote.ownedSkins]));
	if (!owned.includes("prism")) owned.unshift("prism");
	const lasers = uniqKeep([...local.ownedLasers, ...remote.ownedLasers].filter(isLaserId), DEFAULT_LASER_ID);
	const packs = uniqKeep([...local.ownedPacks, ...remote.ownedPacks].filter(isPackId), DEFAULT_PACK_ID);
	const times = { ...remote.campaignTimes };
	for (const [k, v] of Object.entries(local.campaignTimes)) {
		const id = Number(k);
		const prev = times[id];
		times[id] = prev ? Math.min(prev, v) : v;
	}
	const equipped = owned.includes(local.equippedSkin) ? local.equippedSkin : remote.equippedSkin;
	const equippedLaser = lasers.includes(local.equippedLaser) ? local.equippedLaser : remote.equippedLaser;
	const equippedPack = packs.includes(local.equippedPack) ? local.equippedPack : remote.equippedPack;
	return migrate({
		...local,
		campaignReached: Math.max(local.campaignReached, remote.campaignReached),
		campaignBest: Math.max(local.campaignBest, remote.campaignBest),
		infiniteBest: Math.max(local.infiniteBest, remote.infiniteBest),
		infiniteBestWave: Math.max(local.infiniteBestWave, remote.infiniteBestWave),
		fragments: Math.max(local.fragments, remote.fragments),
		ownedSkins: owned,
		equippedSkin: equipped,
		ownedLasers: lasers,
		equippedLaser,
		ownedPacks: packs,
		equippedPack,
		campaignTimes: times
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function clampInt(n, min, max) {
	if (!Number.isFinite(n)) return min;
	return Math.max(min, Math.min(max, Math.floor(n)));
}
var getProgress = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("06eacaaf5f9fea34f52ee5b39ba1b0e898ded429c1b4ce248de29b8b335eb78b"));
var saveProgress = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	const allowed = new Set(SKINS.map((s) => s.id));
	const owned = Array.isArray(input.ownedSkins) ? input.ownedSkins.filter((id) => allowed.has(id)) : ["prism"];
	if (!owned.includes("prism")) owned.unshift("prism");
	const equipped = allowed.has(input.equippedSkin) && owned.includes(input.equippedSkin) ? input.equippedSkin : "prism";
	const laserAllowed = new Set(LASER_SKINS.map((s) => s.id));
	const packAllowed = new Set(ROCK_PACKS.map((s) => s.id));
	const ownedLasers = Array.isArray(input.ownedLasers) ? input.ownedLasers.filter((id) => laserAllowed.has(id)) : [DEFAULT_LASER_ID];
	if (!ownedLasers.includes(DEFAULT_LASER_ID)) ownedLasers.unshift(DEFAULT_LASER_ID);
	const ownedPacks = Array.isArray(input.ownedPacks) ? input.ownedPacks.filter((id) => packAllowed.has(id)) : [DEFAULT_PACK_ID];
	if (!ownedPacks.includes(DEFAULT_PACK_ID)) ownedPacks.unshift(DEFAULT_PACK_ID);
	const equippedLaser = laserAllowed.has(input.equippedLaser) && ownedLasers.includes(input.equippedLaser) ? input.equippedLaser : DEFAULT_LASER_ID;
	const equippedPack = packAllowed.has(input.equippedPack) && ownedPacks.includes(input.equippedPack) ? input.equippedPack : DEFAULT_PACK_ID;
	return {
		campaignReached: clampInt(input.campaignReached, 1, LEVELS.length + 1),
		campaignBest: clampInt(input.campaignBest, 0, 9999999),
		infiniteBest: clampInt(input.infiniteBest, 0, 9999999),
		infiniteBestWave: clampInt(input.infiniteBestWave, 0, 9999),
		fragments: clampInt(input.fragments, 0, 9999999),
		ownedSkins: owned,
		equippedSkin: equipped,
		ownedLasers,
		equippedLaser,
		ownedPacks,
		equippedPack
	};
}).handler(createSsrRpc("54206244f918408c9f4415b91505cdfa4a6fffb5b632e3da88a6deba4362525a"));
var submitCampaignTime = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	levelId: clampInt(input.levelId, 1, LEVELS.length),
	timeMs: clampInt(input.timeMs, 400, 72e5),
	score: clampInt(input.score, 0, 9999999)
})).handler(createSsrRpc("414b7932b218de776262613ae61cf9a61f5a5788672cb8ab40a54f10cd310247"));
var submitInfiniteWave = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	wave: clampInt(input.wave, 1, 9999),
	score: clampInt(input.score, 0, 9999999)
})).handler(createSsrRpc("8bc7fa67abc65f66c48eee09906b3a927415589617ffcd67bc256207dc91eaac"));
var listCampaignBoard = createServerFn({ method: "GET" }).validator((input) => ({ levelId: clampInt(input.levelId, 1, LEVELS.length) })).handler(createSsrRpc("28a8a4b7a3f42cc4d728624a5ee40abc3a830974586da34d3b194f8c70c9f788"));
var listInfiniteBoard = createServerFn({ method: "GET" }).handler(createSsrRpc("dd0175f3a617170467102bd5e81f12de997784adb4fd5151699ac279beb307c6"));
var WEAPON_ICON = {
	kinetic: Crosshair,
	cryo: Snowflake,
	resonant: AudioLines,
	thermal: Flame
};
var KIND_ICON = {
	basalt: Mountain,
	rime: Snowflake,
	quartz: Gem,
	alloy: Hexagon
};
function boot() {
	unlockAudio();
	sfxUi();
}
function persistCloud(save, signedIn) {
	if (!signedIn) return;
	saveProgress({ data: {
		campaignReached: save.campaignReached,
		campaignBest: save.campaignBest,
		infiniteBest: save.infiniteBest,
		infiniteBestWave: save.infiniteBestWave,
		fragments: save.fragments,
		ownedSkins: save.ownedSkins,
		equippedSkin: save.equippedSkin,
		ownedLasers: save.ownedLasers,
		equippedLaser: save.equippedLaser,
		ownedPacks: save.ownedPacks,
		equippedPack: save.equippedPack
	} }).catch(() => {});
}
function GameApp() {
	const canvasRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const signedInRef = (0, import_react.useRef)(false);
	const { user, isPending } = useCurrentUserState();
	const signedIn = Boolean(user);
	signedInRef.current = signedIn;
	const [view, setView] = (0, import_react.useState)("boot");
	const [overlay, setOverlay] = (0, import_react.useState)("none");
	const [playMode, setPlayMode] = (0, import_react.useState)("campaign");
	const [levelIndex, setLevelIndex] = (0, import_react.useState)(0);
	const [session, setSession] = (0, import_react.useState)(0);
	const [hud, setHud] = (0, import_react.useState)(null);
	const [save, setSave] = (0, import_react.useState)(() => loadSave());
	const [lastScore, setLastScore] = (0, import_react.useState)(0);
	const [lastTimeMs, setLastTimeMs] = (0, import_react.useState)(0);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		document.getElementById("cold-boot")?.remove();
		const next = loadSave();
		setSave(next);
		applyMix({
			muted: next.muted,
			musicVol: next.musicVol,
			sfxVol: next.sfxVol
		});
		const onVis = () => {
			if (document.visibilityState === "visible") unlockAudio();
		};
		document.addEventListener("visibilitychange", onVis);
		return () => {
			document.removeEventListener("visibilitychange", onVis);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let cancelled = false;
		(async () => {
			try {
				const remote = await getProgress();
				if (cancelled) return;
				const local = loadSave();
				const merged = mergeSaves(local, {
					...local,
					campaignReached: remote.campaignReached,
					campaignBest: remote.campaignBest,
					infiniteBest: remote.infiniteBest,
					infiniteBestWave: remote.infiniteBestWave,
					fragments: remote.fragments,
					ownedSkins: remote.ownedSkins,
					equippedSkin: remote.equippedSkin,
					ownedLasers: remote.ownedLasers,
					equippedLaser: remote.equippedLaser,
					ownedPacks: remote.ownedPacks,
					equippedPack: remote.equippedPack,
					campaignTimes: remote.campaignTimes
				});
				writeSave(merged);
				setSave(merged);
				persistCloud(merged, true);
				for (const [id, ms] of Object.entries(merged.campaignTimes)) submitCampaignTime({ data: {
					levelId: Number(id),
					timeMs: ms,
					score: merged.campaignBest
				} }).catch(() => {});
				if (merged.infiniteBestWave > 0) submitInfiniteWave({ data: {
					wave: merged.infiniteBestWave,
					score: merged.infiniteBest
				} }).catch(() => {});
			} catch {}
		})();
		return () => {
			cancelled = true;
		};
	}, [user?.id]);
	const canvasKey = view === "boot" ? "boot" : view === "play" ? `play-${playMode}-${levelIndex}-${session}` : `attract-${save.equippedSkin}-${save.equippedLaser}-${save.equippedPack}`;
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas || !mounted || view === "boot") return;
		const game = createGame(canvas, {
			mode: view === "play" ? playMode : "attract",
			levelIndex,
			campaignReached: Math.max(save.campaignReached, playMode === "infinite" ? 5 : 1),
			shakeEnabled: save.shake,
			muted: save.muted,
			skinId: save.equippedSkin,
			laserId: save.equippedLaser,
			packId: save.equippedPack,
			timeScale: save.timeScale,
			onHud: setHud,
			onLevelClear: (score, timeMs) => {
				setLastScore(score);
				setLastTimeMs(timeMs);
				setOverlay("clear");
				const cur = loadSave();
				const levelId = LEVELS[levelIndex]?.id ?? 1;
				const prevTime = cur.campaignTimes[levelId];
				const times = {
					...cur.campaignTimes,
					[levelId]: prevTime ? Math.min(prevTime, timeMs) : timeMs
				};
				const next = writeSave({
					campaignReached: Math.min(LEVELS.length + 1, Math.max(cur.campaignReached, levelId + 1)),
					campaignBest: Math.max(cur.campaignBest, score),
					campaignTimes: times
				});
				setSave(next);
				persistCloud(next, signedInRef.current);
				if (signedInRef.current) submitCampaignTime({ data: {
					levelId,
					timeMs,
					score
				} }).catch(() => {});
			},
			onGameOver: (score, wave) => {
				setLastScore(score);
				setOverlay("over");
				const cur = loadSave();
				if (playMode === "infinite") {
					const next = writeSave({
						infiniteBest: Math.max(cur.infiniteBest, score),
						infiniteBestWave: Math.max(cur.infiniteBestWave, wave)
					});
					setSave(next);
					persistCloud(next, signedInRef.current);
					if (signedInRef.current) submitInfiniteWave({ data: {
						wave,
						score
					} }).catch(() => {});
				} else {
					const next = writeSave({ campaignBest: Math.max(cur.campaignBest, score) });
					setSave(next);
					persistCloud(next, signedInRef.current);
				}
			},
			onVictory: (score, timeMs) => {
				setLastScore(score);
				setLastTimeMs(timeMs);
				setOverlay("victory");
				const cur = loadSave();
				const levelId = LEVELS[levelIndex]?.id ?? LEVELS.length;
				const prevTime = cur.campaignTimes[levelId];
				const times = {
					...cur.campaignTimes,
					[levelId]: prevTime ? Math.min(prevTime, timeMs) : timeMs
				};
				const next = writeSave({
					campaignReached: LEVELS.length + 1,
					campaignBest: Math.max(cur.campaignBest, score),
					campaignTimes: times
				});
				setSave(next);
				persistCloud(next, signedInRef.current);
				if (signedInRef.current) submitCampaignTime({ data: {
					levelId,
					timeMs,
					score
				} }).catch(() => {});
			},
			onWave: () => {},
			onFragments: (delta) => {
				const next = writeSave({ fragments: loadSave().fragments + delta });
				setSave(next);
				persistCloud(next, signedInRef.current);
			},
			onPause: () => {
				if (view !== "play") return;
				setOverlay((cur) => {
					if (cur === "none") {
						game.pause();
						return "paused";
					}
					if (cur === "paused") {
						game.resume();
						return "none";
					}
					return cur;
				});
			}
		});
		gameRef.current = game;
		game.start();
		return () => {
			game.destroy();
			gameRef.current = null;
		};
	}, [canvasKey, mounted]);
	(0, import_react.useEffect)(() => {
		if (view === "title" && mounted) playTitleMusic();
	}, [view, mounted]);
	const enterHangar = () => {
		boot();
		setView("title");
	};
	const goTitle = () => {
		boot();
		setOverlay("none");
		setView("title");
		playTitleMusic();
	};
	const startCampaign = (index) => {
		boot();
		setPlayMode("campaign");
		setLevelIndex(index);
		setSession((s) => s + 1);
		setOverlay("none");
		setView("play");
	};
	const startInfinite = () => {
		boot();
		setPlayMode("infinite");
		setLevelIndex(0);
		setSession((s) => s + 1);
		setOverlay("none");
		setView("play");
	};
	const retry = () => {
		boot();
		setOverlay("none");
		setSession((s) => s + 1);
	};
	const continueCampaign = () => {
		boot();
		const next = levelIndex + 1;
		if (next >= LEVELS.length) {
			setOverlay("victory");
			return;
		}
		setLevelIndex(next);
		setOverlay("none");
		setSession((s) => s + 1);
	};
	const toggleMute = () => {
		const next = !save.muted;
		applyMix({ muted: next });
		setSave(writeSave({ muted: next }));
	};
	const setMusic = (musicVol) => {
		const muted = save.muted && musicVol === 0 && save.sfxVol === 0;
		applyMix({
			musicVol,
			muted
		});
		setSave(writeSave({
			musicVol,
			muted
		}));
	};
	const setSfx = (sfxVol) => {
		const muted = save.muted && sfxVol === 0 && save.musicVol === 0;
		applyMix({
			sfxVol,
			muted
		});
		setSave(writeSave({
			sfxVol,
			muted
		}));
	};
	const toggleShake = () => {
		setSave(writeSave({ shake: !save.shake }));
	};
	const setSpeed = (timeScale) => {
		gameRef.current?.setTimeScale(timeScale);
		setSave(writeSave({ timeScale }));
	};
	const pullGacha = () => {
		boot();
		const cur = loadSave();
		if (cur.fragments < 500) return null;
		const prize = rollGacha({
			wells: cur.ownedSkins,
			lasers: cur.ownedLasers,
			packs: cur.ownedPacks
		});
		let fragments = cur.fragments - 500;
		const patch = {};
		if (prize.duplicate) fragments += 100;
		else if (prize.kind === "well") {
			patch.ownedSkins = [...cur.ownedSkins, prize.id];
			patch.equippedSkin = prize.id;
		} else if (prize.kind === "laser") {
			patch.ownedLasers = [...cur.ownedLasers, prize.id];
			patch.equippedLaser = prize.id;
		} else {
			patch.ownedPacks = [...cur.ownedPacks, prize.id];
			patch.equippedPack = prize.id;
		}
		patch.fragments = fragments;
		const next = writeSave(patch);
		setSave(next);
		persistCloud(next, signedIn);
		return prize;
	};
	const pauseGame = () => {
		if (overlay !== "none") return;
		gameRef.current?.pause();
		setOverlay("paused");
	};
	const resumeGame = () => {
		gameRef.current?.resume();
		setOverlay("none");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh max-h-dvh w-full overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full touch-none",
				"aria-label": "VOID PRISM playfield"
			}),
			view !== "play" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("absolute inset-0", view === "boot" ? "bg-bg" : "bg-bg/55") }),
			view === "boot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, { onEnter: enterHangar }),
			view === "title" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleScreen, {
				save,
				isPending,
				signedIn,
				onCampaign: () => {
					boot();
					setView("campaign");
				},
				onInfinite: startInfinite,
				onHowTo: () => {
					boot();
					setView("howto");
				},
				onShop: () => {
					boot();
					setView("shop");
				},
				onBoards: () => {
					boot();
					setView("boards");
				},
				muted: save.muted,
				musicVol: save.musicVol,
				sfxVol: save.sfxVol,
				onMute: toggleMute,
				onMusic: setMusic,
				onSfx: setSfx
			}),
			view === "howto" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HowToScreen, {
				onBack: goTitle,
				palette: livePalette(save.equippedLaser, save.equippedPack)
			}),
			view === "campaign" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CampaignScreen, {
				reached: save.campaignReached,
				times: save.campaignTimes,
				palette: livePalette(save.equippedLaser, save.equippedPack),
				onBack: goTitle,
				onPick: startCampaign
			}),
			view === "shop" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopScreen, {
				save,
				onBack: goTitle,
				onBuyWell: (id) => {
					boot();
					const cur = loadSave();
					const def = skinById(id);
					if (cur.ownedSkins.includes(id)) {
						const next = writeSave({ equippedSkin: id });
						setSave(next);
						persistCloud(next, signedIn);
						return;
					}
					if (cur.fragments < def.cost) return;
					const next = writeSave({
						fragments: cur.fragments - def.cost,
						ownedSkins: [...cur.ownedSkins, id],
						equippedSkin: id
					});
					setSave(next);
					persistCloud(next, signedIn);
				},
				onBuyLaser: (id) => {
					boot();
					const cur = loadSave();
					const def = laserById(id);
					if (cur.ownedLasers.includes(id)) {
						const next = writeSave({ equippedLaser: id });
						setSave(next);
						persistCloud(next, signedIn);
						return;
					}
					if (cur.fragments < def.cost) return;
					const next = writeSave({
						fragments: cur.fragments - def.cost,
						ownedLasers: [...cur.ownedLasers, id],
						equippedLaser: id
					});
					setSave(next);
					persistCloud(next, signedIn);
				},
				onBuyPack: (id) => {
					boot();
					const cur = loadSave();
					const def = packById(id);
					if (cur.ownedPacks.includes(id)) {
						const next = writeSave({ equippedPack: id });
						setSave(next);
						persistCloud(next, signedIn);
						return;
					}
					if (cur.fragments < def.cost) return;
					const next = writeSave({
						fragments: cur.fragments - def.cost,
						ownedPacks: [...cur.ownedPacks, id],
						equippedPack: id
					});
					setSave(next);
					persistCloud(next, signedIn);
				},
				onGacha: pullGacha
			}),
			view === "boards" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardsScreen, {
				userId: user?.id ?? null,
				onBack: goTitle
			}),
			view === "play" && hud && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayHud, {
				hud,
				overlay,
				muted: save.muted,
				fragments: save.fragments,
				palette: livePalette(save.equippedLaser, save.equippedPack),
				onPause: pauseGame,
				onMute: toggleMute,
				onWeapon: (w) => gameRef.current?.setWeapon(w)
			}),
			view === "play" && overlay === "paused" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CenterPanel, {
				kicker: "Paused",
				title: hud?.levelName ?? "VOID PRISM",
				body: "Resume, restart, or return to the hangar.",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeMixer, {
						music: save.musicVol,
						sfx: save.sfxVol,
						onMusic: setMusic,
						onSfx: setSfx
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: save.timeScale === 1 ? "primary" : "outline",
							onClick: () => setSpeed(1),
							children: "1× speed"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: save.timeScale === 2 ? "primary" : "outline",
							onClick: () => setSpeed(2),
							children: "2× speed"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: resumeGame,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Resume"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						onClick: retry,
						children: "Restart"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: toggleShake,
						children: ["Shake ", save.shake ? "on" : "off"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: goTitle,
						children: "Hangar"
					})
				]
			}),
			view === "play" && overlay === "clear" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CenterPanel, {
				kicker: `Sector ${levelIndex + 1} clear`,
				title: LEVELS[levelIndex]?.name ?? "Clear",
				body: `Score ${lastScore.toLocaleString()} · ${formatTime(lastTimeMs)}. Fragments banked.`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: continueCampaign,
					children: "Continue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: goTitle,
					children: "Hangar"
				})]
			}),
			view === "play" && overlay === "over" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CenterPanel, {
				kicker: "Well breached",
				title: "Game over",
				body: playMode === "infinite" ? `Wave ${hud?.wave ?? 1} · Score ${lastScore.toLocaleString()}` : `Score ${lastScore.toLocaleString()}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: retry,
					children: "Retry"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: goTitle,
					children: "Hangar"
				})]
			}),
			view === "play" && overlay === "victory" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CenterPanel, {
				kicker: "Campaign",
				title: "The belt is clear",
				body: `Final score ${lastScore.toLocaleString()} · ${formatTime(lastTimeMs)}. Infinite Drift is waiting.`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: startInfinite,
					children: "Infinite Drift"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: goTitle,
					children: "Hangar"
				})]
			})
		]
	});
}
function BootScreen({ onEnter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onEnter,
		className: "relative z-10 flex h-full w-full flex-col items-center justify-center px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs uppercase tracking-[0.32em] text-subtle",
				children: "Spectral intercept"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 font-display text-4xl font-semibold tracking-[-0.04em] sm:text-5xl",
				children: "VOID PRISM"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 font-mono text-xs uppercase tracking-[0.22em] text-muted",
				children: "Tap to enter"
			})
		]
	});
}
function AuthSlot({ isPending, signedIn }) {
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-28 animate-pulse rounded-full bg-bg-subtle" });
	if (signedIn) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		className: "font-mono text-xs uppercase tracking-[0.18em] text-muted hover:text-fg",
		children: "Sign in"
	});
}
function TitleScreen({ save, isPending, signedIn, onCampaign, onInfinite, onHowTo, onShop, onBoards, muted, musicVol, sfxVol, onMute, onMusic, onSfx }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative z-10 flex h-full flex-col overflow-y-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs uppercase tracking-[0.28em] text-muted",
					children: "Hangar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSlot, {
						isPending,
						signedIn
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onMute,
						className: "flex size-10 items-center justify-center rounded-[var(--radius-sm)] text-muted hover:text-fg",
						"aria-label": muted ? "Unmute" : "Mute",
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto mt-6 w-full max-w-md flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl font-semibold leading-tight tracking-[-0.04em] sm:text-4xl",
						children: "VOID PRISM"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted",
						children: "Match the laser to the rock. Three charges. Spend fragments in the shop."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								className: "w-full",
								onClick: onCampaign,
								children: "Campaign"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "outline",
								className: "w-full",
								onClick: onInfinite,
								children: "Infinite"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "md",
								variant: "outline",
								className: "w-full",
								onClick: onShop,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "size-4" }), "Shop"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "md",
								variant: "outline",
								className: "w-full",
								onClick: onBoards,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trophy, { className: "size-4" }), "Boards"]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "md",
						variant: "ghost",
						className: "mt-2 w-full",
						onClick: onHowTo,
						children: "How to play"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeMixer, {
							music: musicVol,
							sfx: sfxVol,
							onMusic,
							onSfx
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mx-auto mt-4 flex w-full max-w-md flex-wrap gap-x-6 gap-y-1 font-mono text-xs uppercase tracking-[0.16em] text-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Frag ", save.fragments.toLocaleString()] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Best ", save.campaignBest.toLocaleString()] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Wave ", save.infiniteBestWave.toLocaleString()] })
				]
			})
		]
	});
}
function HowToScreen({ onBack, palette }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg",
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 font-display text-2xl font-semibold tracking-[-0.03em]",
				children: "How to play"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-lg text-muted leading-relaxed",
				children: "Click matching asteroids inside the dashed range. Three well charges — a hit without a shield costs one, and the last ends the run. Gold lucky meteors yield to any laser (5% spawn, max five per wave) and drop gear. Sign in to post sector times and infinite waves."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 max-w-lg divide-y divide-border border-y border-border",
				children: [
					"basalt",
					"rime",
					"quartz",
					"alloy"
				].map((kind) => {
					const weapon = MATCH[kind];
					const KindIcon = KIND_ICON[kind];
					const WepIcon = WEAPON_ICON[weapon];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3",
								style: { color: palette.kind[kind] },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KindIcon, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-fg",
									children: KIND_LABEL[kind]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs uppercase tracking-[0.18em] text-subtle",
								children: "yields to"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3",
								style: { color: palette.weapon[weapon] },
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium text-fg",
									children: WEAPON_LABEL[weapon]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WepIcon, { className: "size-5" })]
							})
						]
					}, kind);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-8 grid max-w-lg gap-3 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle",
							children: "Destroy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-mono text-fg",
							children: "Click / tap the rock"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle",
							children: "Lucky drop"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-mono text-fg",
							children: "Aegis / ward / overcharge / blast / 2× frag"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle",
							children: "Switch laser"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-mono text-fg",
							children: "1–4 / Q E / dock"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-subtle",
							children: "Pause"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-mono text-fg",
							children: "Esc / P"
						})]
					})
				]
			})
		]
	});
}
function ShopScreen({ save, onBack, onBuyWell, onBuyLaser, onBuyPack, onGacha }) {
	const [tab, setTab] = (0, import_react.useState)("rocks");
	const [roll, setRoll] = (0, import_react.useState)(null);
	const canPull = save.fragments >= 500;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg",
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 font-display text-2xl font-semibold tracking-[-0.03em]",
				children: "Shop"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-lg text-sm text-muted",
				children: [
					"Fragments ",
					save.fragments.toLocaleString(),
					". Rock packs recolor the belt and matching lasers. Vault is 500 a pull — cheap skins common, rare ones scarce."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 w-full max-w-3xl rounded-[var(--radius-lg)] border border-border bg-bg-elevated p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-2 font-display text-base font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dices, { className: "size-4" }), "Vault"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: roll ? roll.duplicate ? `Duplicate ${roll.name}. +100 frag back.` : `Pulled ${roll.name} (${roll.kind}). Equipped.` : "One random well, laser, or rock pack."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						disabled: !canPull,
						onClick: () => {
							const prize = onGacha();
							if (prize) setRoll(prize);
						},
						children: ["Pull · ", 500]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex flex-wrap gap-2",
				children: [
					["rocks", "Rock packs"],
					["laser", "Lasers"],
					["well", "Well"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: tab === id ? "primary" : "outline",
					onClick: () => setTab(id),
					children: label
				}, id))
			}),
			tab === "well" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: SKINS.map((skin) => {
					const owned = save.ownedSkins.includes(skin.id);
					const equipped = save.equippedSkin === skin.id;
					const locked = !owned && save.fragments < skin.cost;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						onClick: () => onBuyWell(skin.id),
						className: cn("flex w-full items-center gap-4 rounded-[var(--radius-lg)] border bg-bg-elevated px-4 py-4 text-left", equipped ? "border-accent" : "border-border hover:border-border-strong", locked && "opacity-40"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-8 shrink-0 rounded-full border border-border",
								style: { background: skin.core }
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-base font-medium tracking-tight",
									children: skin.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs text-muted",
									children: skin.blurb
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs uppercase tracking-[0.14em] text-subtle",
								children: equipped ? "On" : owned ? "Equip" : `${skin.cost} frag`
							})
						]
					}) }, skin.id);
				})
			}),
			tab === "laser" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: LASER_SKINS.map((skin) => {
					const owned = save.ownedLasers.includes(skin.id);
					const equipped = save.equippedLaser === skin.id;
					const locked = !owned && save.fragments < skin.cost;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						onClick: () => onBuyLaser(skin.id),
						className: cn("flex w-full items-center gap-4 rounded-[var(--radius-lg)] border bg-bg-elevated px-4 py-4 text-left", equipped ? "border-accent" : "border-border hover:border-border-strong", locked && "opacity-40"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex gap-1",
								children: WEAPON_ORDER.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2.5 rounded-full border border-border",
									style: { background: livePalette(skin.id, save.equippedPack).weapon[w] }
								}, w))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-base font-medium tracking-tight",
									children: skin.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 block text-xs text-muted",
									children: [
										skin.blurb,
										" · ",
										skin.style
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs uppercase tracking-[0.14em] text-subtle",
								children: equipped ? "On" : owned ? "Equip" : `${skin.cost} frag`
							})
						]
					}) }, skin.id);
				})
			}),
			tab === "rocks" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: ROCK_PACKS.map((pack) => {
					const owned = save.ownedPacks.includes(pack.id);
					const equipped = save.equippedPack === pack.id;
					const locked = !owned && save.fragments < pack.cost;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						onClick: () => onBuyPack(pack.id),
						className: cn("flex w-full items-center gap-4 rounded-[var(--radius-lg)] border bg-bg-elevated px-4 py-4 text-left", equipped ? "border-accent" : "border-border hover:border-border-strong", locked && "opacity-40"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex gap-1",
								children: [
									"basalt",
									"rime",
									"quartz",
									"alloy"
								].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "size-2.5 rounded-full border border-border",
									style: { background: pack.colors[k] }
								}, k))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-base font-medium tracking-tight",
									children: pack.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-1 block text-xs text-muted",
									children: pack.blurb
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs uppercase tracking-[0.14em] text-subtle",
								children: equipped ? "On" : owned ? "Equip" : `${pack.cost} frag`
							})
						]
					}) }, pack.id);
				})
			})
		]
	});
}
function CampaignScreen({ reached, times, palette, onBack, onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg",
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 font-display text-2xl font-semibold tracking-[-0.03em]",
				children: "Campaign"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-lg text-muted",
				children: "Fifty sectors. Each one changes the belt and the music. Clear times post to the board when you are signed in."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: LEVELS.map((lvl, i) => {
					const locked = lvl.id > reached;
					const best = times[lvl.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: locked,
						onClick: () => onPick(i),
						className: cn("flex w-full items-center gap-4 rounded-[var(--radius-lg)] border border-border bg-bg-elevated px-4 py-3 text-left", "hover:border-border-strong disabled:opacity-40"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-subtle tabular",
								children: String(lvl.id).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-display text-base font-medium tracking-tight",
									children: lvl.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-1 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex gap-1.5",
										children: lvl.kinds.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "size-1.5 rounded-full",
											style: { background: palette.kind[k] }
										}, k))
									}), best ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-[0.65rem] uppercase tracking-[0.12em] text-subtle",
										children: formatTime(best)
									}) : null]
								})]
							}),
							locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4 text-subtle" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 text-muted" })
						]
					}) }, lvl.id);
				})
			})
		]
	});
}
function BoardsScreen({ userId, onBack }) {
	const [tab, setTab] = (0, import_react.useState)("campaign");
	const [levelId, setLevelId] = (0, import_react.useState)(1);
	const [rows, setRows] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		setLoading(true);
		(tab === "campaign" ? listCampaignBoard({ data: { levelId } }) : listInfiniteBoard()).then((list) => {
			if (cancelled) return;
			setRows(list.map((row) => ({
				...row,
				mine: Boolean(userId && row.userId === userId)
			})));
		}).catch(() => {
			if (!cancelled) setRows([]);
		}).finally(() => {
			if (!cancelled) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [
		tab,
		levelId,
		userId
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onBack,
				className: "self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg",
				children: "Back"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 font-display text-2xl font-semibold tracking-[-0.03em]",
				children: "Boards"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-lg text-muted",
				children: "Campaign ranks how fast a sector was cleared. Infinite ranks highest wave. Sign in to post."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: tab === "campaign" ? "primary" : "outline",
					onClick: () => setTab("campaign"),
					children: "Campaign"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: tab === "infinite" ? "primary" : "outline",
					onClick: () => setTab("infinite"),
					children: "Infinite"
				})]
			}),
			tab === "campaign" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex max-w-3xl flex-wrap gap-1.5",
				children: LEVELS.map((lvl) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setLevelId(lvl.id),
					className: cn("min-h-9 min-w-9 rounded-[var(--radius-sm)] border px-2 font-mono text-xs tabular", levelId === lvl.id ? "border-accent bg-bg-elevated text-fg" : "border-border text-muted hover:text-fg"),
					children: lvl.id
				}, lvl.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-6 w-full max-w-xl divide-y divide-border border-y border-border",
				children: [
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-6 font-mono text-xs uppercase tracking-[0.18em] text-subtle",
						children: "Loading"
					}),
					!loading && rows.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "py-6 text-sm text-muted",
						children: "No entries yet. Clear a sector or ride a wave, then sign in."
					}),
					!loading && rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("flex items-center gap-4 py-3", row.mine && "text-accent"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 font-mono text-xs text-subtle tabular",
								children: String(row.rank).padStart(2, "0")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 truncate font-medium",
								children: row.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs tabular text-muted",
								children: tab === "campaign" ? formatTime(row.value) : `Wave ${row.value}`
							})
						]
					}, `${row.userId}-${row.rank}`))
				]
			})
		]
	});
}
function PlayHud({ hud, overlay, muted, fragments, palette, onPause, onMute, onWeapon }) {
	const playing = overlay === "none";
	const pills = [];
	if (hud.aegisT > 0) pills.push({
		key: "aegis",
		label: `Aegis ${Math.ceil(hud.aegisT)}s`,
		icon: Shield
	});
	if (hud.ward > 0) pills.push({
		key: "ward",
		label: "Ward",
		icon: Shield
	});
	if (hud.overchargeT > 0) pills.push({
		key: "oc",
		label: `Over ${Math.ceil(hud.overchargeT)}s`,
		icon: Zap
	});
	if (hud.fragMulT > 0) pills.push({
		key: "x2",
		label: `2× ${Math.ceil(hud.fragMulT)}s`,
		icon: Sparkles
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-3 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs uppercase tracking-[0.22em] text-subtle",
							children: hud.mode === "infinite" ? hud.levelName : `Sector ${hud.levelId}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-xl font-medium tabular tracking-tight",
							children: hud.score.toLocaleString()
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-subtle",
							children: [
								fragments.toLocaleString(),
								" frag",
								hud.sessionFrags > 0 ? ` · +${hud.sessionFrags}` : ""
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 flex gap-1",
							children: Array.from({ length: Math.max(hud.lives, 0) }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-2 w-3 bg-accent" }, i))
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm font-medium tracking-tight",
								children: hud.mode === "campaign" ? hud.levelName : "Infinite Drift"
							}),
							hud.briefingT > 0 && playing && hud.waveClearT <= 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-[16rem] text-xs text-muted",
								children: hud.briefing
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 font-mono text-xs uppercase tracking-[0.18em] text-subtle tabular",
								children: [
									hud.remaining,
									" left",
									hud.combo > 1 ? ` · ×${hud.multiplier}` : "",
									hud.mode === "campaign" ? ` · ${formatTime(hud.playTime * 1e3)}` : ""
								]
							}),
							pills.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-wrap justify-center gap-1.5",
								children: pills.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-1 rounded-[var(--radius-sm)] border border-border bg-bg/70 px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-[0.12em]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(p.icon, { className: "size-3" }), p.label]
								}, p.key))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-auto flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onMute,
							className: "flex size-11 items-center justify-center rounded-[var(--radius-sm)] text-muted hover:text-fg",
							"aria-label": muted ? "Unmute" : "Mute",
							children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" })
						}), playing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onPause,
							className: "flex size-11 items-center justify-center rounded-[var(--radius-sm)] text-muted hover:text-fg",
							"aria-label": "Pause",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
						})]
					})
				]
			}),
			hud.waveClearT > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-2xl font-semibold tracking-[-0.03em] sm:text-3xl",
					children: [
						"Wave ",
						hud.wave,
						" cleared"
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-auto mx-auto flex w-full max-w-md gap-2",
				children: WEAPON_ORDER.map((id) => {
					const Icon = WEAPON_ICON[id];
					const open = hud.unlocked.includes(id);
					const active = hud.weapon === id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: !open,
						onClick: () => onWeapon(id),
						className: cn("flex min-h-11 flex-1 flex-col items-center justify-center gap-1 rounded-[var(--radius-md)] border px-1 py-1.5", active ? "border-accent bg-bg-elevated text-fg" : "border-border bg-bg/50 text-muted", !open && "opacity-30", hud.overchargeT > 0 && open && "border-accent"),
						style: open ? { color: palette.weapon[id] } : void 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-[0.6rem] uppercase tracking-[0.14em]",
							children: WEAPON_LABEL[id]
						})]
					}, id);
				})
			})
		]
	});
}
function VolumeMixer({ music, sfx, onMusic, onSfx }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2 rounded-[var(--radius-md)] border border-border bg-bg/70 px-3 py-2",
		onPointerDown: (e) => e.stopPropagation(),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-14 shrink-0 font-mono text-xs uppercase tracking-[0.16em] text-subtle",
					children: "Music"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min: 0,
					max: 100,
					value: Math.round(music * 100),
					"aria-label": "Music volume",
					onChange: (e) => onMusic(Number(e.target.value) / 100),
					className: "vol"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-8 text-right font-mono text-xs tabular text-muted",
					children: Math.round(music * 100)
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "flex items-center gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-14 shrink-0 font-mono text-xs uppercase tracking-[0.16em] text-subtle",
					children: "SFX"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "range",
					min: 0,
					max: 100,
					value: Math.round(sfx * 100),
					"aria-label": "SFX volume",
					onChange: (e) => onSfx(Number(e.target.value) / 100),
					className: "vol"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "w-8 text-right font-mono text-xs tabular text-muted",
					children: Math.round(sfx * 100)
				})
			]
		})]
	});
}
function CenterPanel({ kicker, title, body, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-20 flex items-center justify-center bg-bg/70 px-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-labelledby": "panel-title",
			className: "w-full max-w-md max-h-[min(40rem,90dvh)] overflow-auto rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-6 sm:p-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs uppercase tracking-[0.22em] text-subtle",
					children: kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "panel-title",
					className: "mt-3 font-display text-2xl font-semibold tracking-[-0.03em]",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex flex-col gap-2",
					children
				})
			]
		})
	});
}
var SplitComponent = GameApp;
//#endregion
export { SplitComponent as component };
