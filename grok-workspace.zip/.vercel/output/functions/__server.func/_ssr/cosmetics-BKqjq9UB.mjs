import { n as createMiddleware } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cosmetics-BKqjq9UB.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-1vAx-gM_.mjs").then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-CJKNDZbb.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var R = -1;
function hslHex$1(h, s, l) {
	const sat = s / 100;
	const lig = l / 100;
	const a = sat * Math.min(lig, 1 - lig);
	const f = (n) => {
		const k = (n + h / 30) % 12;
		const c = lig - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
		return Math.round(255 * c).toString(16).padStart(2, "0");
	};
	return `#${f(0)}${f(8)}${f(4)}`;
}
var HAND_SKINS = [
	{
		id: "prism",
		name: "Prism",
		cost: 0,
		blurb: "Stock well.",
		core: "#c5cdd8",
		beam: "#ecece8"
	},
	{
		id: "aurora",
		name: "Aurora",
		cost: 50,
		blurb: "Cold drift.",
		core: "#7ec8d4",
		beam: "#9ee8f0"
	},
	{
		id: "ember",
		name: "Ember",
		cost: 50,
		blurb: "Thermal husk.",
		core: "#c4845a",
		beam: "#e8a070"
	},
	{
		id: "ion",
		name: "Ion",
		cost: 80,
		blurb: "Resonant veil.",
		core: "#8fbfa5",
		beam: "#b6e0c8"
	},
	{
		id: "gold",
		name: "Gilded",
		cost: 140,
		blurb: "Lucky belt.",
		core: "#e6c35c",
		beam: "#f3de8a"
	},
	{
		id: "obsidian",
		name: "Obsidian",
		cost: 110,
		blurb: "Dark glass.",
		core: "#6a6a74",
		beam: "#ecece8"
	}
];
var EXTRA_SKINS = [
	{
		id: "violet",
		name: "Violet",
		blurb: "Ion dusk."
	},
	{
		id: "rust",
		name: "Rust",
		blurb: "Old hull."
	},
	{
		id: "frost",
		name: "Frost",
		blurb: "Thin ice."
	},
	{
		id: "jade",
		name: "Jade",
		blurb: "Quiet vein."
	},
	{
		id: "copper",
		name: "Copper",
		blurb: "Warm ore."
	},
	{
		id: "cobalt",
		name: "Cobalt",
		blurb: "Deep pulse."
	},
	{
		id: "pearl",
		name: "Pearl",
		blurb: "Soft core."
	},
	{
		id: "magma",
		name: "Magma",
		blurb: "Open kiln."
	},
	{
		id: "moss",
		name: "Moss",
		blurb: "Belt growth."
	},
	{
		id: "noir",
		name: "Noir",
		blurb: "Low light."
	},
	{
		id: "rose",
		name: "Rose",
		blurb: "Dust bloom."
	},
	{
		id: "citrus",
		name: "Citrus",
		blurb: "Sharp rind."
	},
	{
		id: "dusk",
		name: "Dusk",
		blurb: "Late orbit."
	},
	{
		id: "lime",
		name: "Lime",
		blurb: "Acid wash."
	},
	{
		id: "wine",
		name: "Wine",
		blurb: "Dark fruit."
	},
	{
		id: "steel",
		name: "Steel",
		blurb: "Cold plate."
	},
	{
		id: "sand",
		name: "Sand",
		blurb: "Dry halo."
	},
	{
		id: "bloom",
		name: "Bloom",
		blurb: "Open petal."
	},
	{
		id: "ice",
		name: "Ice",
		blurb: "Hard rime."
	},
	{
		id: "nectar",
		name: "Nectar",
		blurb: "Sweet burn."
	},
	{
		id: "slate",
		name: "Slate",
		blurb: "Cut stone."
	},
	{
		id: "flare",
		name: "Flare",
		blurb: "Signal fire."
	},
	{
		id: "mint",
		name: "Mint",
		blurb: "Cool leaf."
	},
	{
		id: "emberglass",
		name: "Emberglass",
		blurb: "Fired silica."
	},
	{
		id: "tidal",
		name: "Tidal",
		blurb: "Pull and push."
	},
	{
		id: "umber",
		name: "Umber",
		blurb: "Earth crust."
	},
	{
		id: "quartzite",
		name: "Quartzite",
		blurb: "Pressed crystal."
	},
	{
		id: "plasma",
		name: "Plasma",
		blurb: "Hot field."
	},
	{
		id: "fog",
		name: "Fog",
		blurb: "Soft veil."
	},
	{
		id: "coral",
		name: "Coral",
		blurb: "Reef light."
	},
	{
		id: "onyx",
		name: "Onyx",
		blurb: "Black cut."
	},
	{
		id: "chartreuse",
		name: "Chartreuse",
		blurb: "Acid silk."
	},
	{
		id: "indigo",
		name: "Indigo",
		blurb: "Night dye."
	},
	{
		id: "brass",
		name: "Brass",
		blurb: "Horn metal."
	},
	{
		id: "glacier",
		name: "Glacier",
		blurb: "Slow blue."
	},
	{
		id: "pyro",
		name: "Pyro",
		blurb: "Short fuse."
	},
	{
		id: "kelp",
		name: "Kelp",
		blurb: "Deep green."
	},
	{
		id: "ivory",
		name: "Ivory",
		blurb: "Bone well."
	},
	{
		id: "mercury",
		name: "Mercury",
		blurb: "Live metal."
	},
	{
		id: "amethyst",
		name: "Amethyst",
		blurb: "Royal shard."
	},
	{
		id: "cinder",
		name: "Cinder",
		blurb: "After burn."
	},
	{
		id: "opal",
		name: "Opal",
		blurb: "Shift fire."
	},
	{
		id: "saturn",
		name: "Saturn",
		blurb: "Ring light."
	},
	{
		id: "voidlight",
		name: "Voidlight",
		blurb: "Last gleam."
	}
];
function extraCost$1(i) {
	if (i < 8) return 60 + i * 12;
	if (i < 20) return 180 + (i - 8) * 18;
	if (i < 32) return 420 + (i - 20) * 28;
	return 820 + (i - 32) * 70;
}
var SKINS = [...HAND_SKINS, ...EXTRA_SKINS.map((s, i) => {
	const h = (i * 137.508 + 18) % 360;
	const core = hslHex$1(h, 42 + i % 5 * 6, 52 + i % 3 * 4);
	const beam = hslHex$1(h, 38, 78);
	return {
		id: s.id,
		name: s.name,
		blurb: s.blurb,
		cost: extraCost$1(i),
		core,
		beam
	};
})];
function skinById(id) {
	return SKINS.find((s) => s.id === id) ?? SKINS[0];
}
var LEVEL_META = [
	{
		name: "Shale Drift",
		briefing: "Click basalt with kinetic."
	},
	{
		name: "Rime Wake",
		briefing: "Ice yields only to cryo. Switch, then click."
	},
	{
		name: "Twin Belt",
		briefing: "Two materials. Switch between beams."
	},
	{
		name: "Quartz Vein",
		briefing: "Resonant pulse for crystal. Click each shard."
	},
	{
		name: "Alloy Rain",
		briefing: "Thermal lance for metal. Guard the well."
	},
	{
		name: "Fourfold",
		briefing: "Every spectrum at once."
	},
	{
		name: "Splinter Field",
		briefing: "They come apart fast. Stay on the match."
	},
	{
		name: "Dense Halo",
		briefing: "No room to miss."
	},
	{
		name: "Titan Core",
		briefing: "Giants of every kind. Click the hulls."
	},
	{
		name: "Prism Gauntlet",
		briefing: "Hold the spectrum. Protect the well."
	},
	{
		name: "Veil Rift",
		briefing: "The belt thins. Keep the match clean."
	},
	{
		name: "Ash Orbit",
		briefing: "Hot stone, faster pull."
	},
	{
		name: "Cyan Wreck",
		briefing: "Cryo wreckage. Do not freeze up."
	},
	{
		name: "Glass Tide",
		briefing: "Quartz floods the well."
	},
	{
		name: "Ember Stack",
		briefing: "Alloy stacks. Thermal only."
	},
	{
		name: "Polar Fold",
		briefing: "Cold and stone together."
	},
	{
		name: "Rust Choir",
		briefing: "Metal sings. Switch or die."
	},
	{
		name: "Night Quarry",
		briefing: "Four kinds in the dark."
	},
	{
		name: "Ion Shelf",
		briefing: "Resonant shelf. Stay precise."
	},
	{
		name: "Hollow Sun",
		briefing: "Bright, fast, unforgiving."
	},
	{
		name: "Pale Current",
		briefing: "A slow pull, then a snap."
	},
	{
		name: "Red Caldera",
		briefing: "Thermal country. Watch the well."
	},
	{
		name: "Soft Static",
		briefing: "Quartz chatter. Match the pulse."
	},
	{
		name: "Brine Crown",
		briefing: "Rime royalty. Cryo ready."
	},
	{
		name: "Silent Kiln",
		briefing: "Heat without warning."
	},
	{
		name: "Volt Garden",
		briefing: "Every laser, every second."
	},
	{
		name: "Dust Cathedral",
		briefing: "High count. Keep switching."
	},
	{
		name: "Cold Forge",
		briefing: "Ice and metal. Two docks."
	},
	{
		name: "Prism Fault",
		briefing: "The spectrum splits again."
	},
	{
		name: "Black Harvest",
		briefing: "Titans in the dark."
	},
	{
		name: "Silver Wake",
		briefing: "Faster belt. No late clicks."
	},
	{
		name: "Thorn Belt",
		briefing: "Sharp count, sharp pull."
	},
	{
		name: "Mirage Dock",
		briefing: "Kinds rotate. Trust the color."
	},
	{
		name: "Deep Assay",
		briefing: "Dense field. Stay in range."
	},
	{
		name: "White Noise",
		briefing: "All four, all at once."
	},
	{
		name: "Copper Hymn",
		briefing: "Alloy hymn. Thermal choir."
	},
	{
		name: "Void Orchard",
		briefing: "They split like fruit."
	},
	{
		name: "Shatter Line",
		briefing: "One miss feeds the well."
	},
	{
		name: "Last Meridian",
		briefing: "Titans plus swarm."
	},
	{
		name: "Iron Bloom",
		briefing: "Heavy metal rain."
	},
	{
		name: "Ghost Lattice",
		briefing: "Pale rocks, hard match."
	},
	{
		name: "Solar Ruin",
		briefing: "Heat and speed."
	},
	{
		name: "Frozen Choir",
		briefing: "Cryo wall. Do not stall."
	},
	{
		name: "Apex Drift",
		briefing: "The belt peaks."
	},
	{
		name: "Null Harbor",
		briefing: "Quiet, then too many."
	},
	{
		name: "Burning Vale",
		briefing: "Thermal storm."
	},
	{
		name: "Quiet Titan",
		briefing: "One giant, then the swarm."
	},
	{
		name: "Far Spectrum",
		briefing: "All colors, no mercy."
	},
	{
		name: "Broken Halo",
		briefing: "Range is tight. Count is not."
	},
	{
		name: "Absolute Belt",
		briefing: "Last sector. Clear it fast."
	}
];
var ALL_KINDS = [
	"basalt",
	"rime",
	"quartz",
	"alloy"
];
function kindsFor(id) {
	if (id === 1) return ["basalt"];
	if (id === 2) return ["rime"];
	if (id === 3) return ["basalt", "rime"];
	if (id === 4) return ["quartz"];
	if (id === 5) return ["alloy"];
	if (id <= 8) return ALL_KINDS;
	if (id % 11 === 0) return ["quartz", "alloy"];
	if (id % 7 === 0) return ["basalt", "alloy"];
	if (id % 5 === 0) return ["rime", "quartz"];
	if (id % 4 === 0) return [
		"basalt",
		"rime",
		"quartz"
	];
	return ALL_KINDS;
}
function musicIdFor(id) {
	return [
		"shale",
		"rime",
		"twin",
		"quartz",
		"alloy",
		"fourfold",
		"splinter",
		"halo",
		"titan",
		"gauntlet"
	][id - 1] ?? `sec-${id}`;
}
var LEVELS = LEVEL_META.map((meta, i) => {
	const id = i + 1;
	const large = Math.min(14, 3 + Math.ceil(id / 4));
	const speed = Math.round(40 + id * 1.7 + Math.max(0, id - 28) * 1.4);
	return {
		id,
		name: meta.name,
		briefing: meta.briefing,
		kinds: kindsFor(id),
		large,
		speed,
		titan: id === 9 || id === 50 || id >= 18 && id % 9 === 0,
		music: musicIdFor(id)
	};
});
var SCALES = [
	[
		0,
		2,
		3,
		5,
		7,
		9,
		10,
		12
	],
	[
		0,
		1,
		3,
		5,
		7,
		8,
		10,
		12
	],
	[
		0,
		2,
		4,
		7,
		9,
		11,
		12,
		14
	],
	[
		0,
		3,
		5,
		7,
		10,
		12,
		15
	],
	[
		0,
		2,
		5,
		7,
		9,
		12,
		14
	],
	[
		0,
		1,
		3,
		6,
		7,
		9,
		12,
		13
	],
	[
		0,
		4,
		7,
		11,
		12,
		16,
		19
	],
	[
		0,
		3,
		7,
		10,
		12,
		15,
		19,
		22
	]
];
var ROOTS = [
	36.71,
	41.2,
	49,
	55,
	61.74,
	65.41,
	73.42,
	82.41,
	87.31,
	92.5,
	98,
	110
];
var WAVES = [
	"sine",
	"triangle",
	"square",
	"sawtooth"
];
function lcg(seed) {
	let s = seed >>> 0;
	return () => {
		s = Math.imul(s, 1664525) + 1013904223 >>> 0;
		return s / 4294967296;
	};
}
function drumPat(rand, steps, density) {
	let out = "";
	for (let i = 0; i < steps; i++) {
		const chance = i % 4 === 0 ? density + .35 : density;
		out += rand() < chance ? "x" : "-";
	}
	return out;
}
function seq(rand, steps, density, maxIdx) {
	const out = [];
	for (let i = 0; i < steps; i++) out.push(rand() < density ? Math.floor(rand() * maxIdx) : R);
	return out;
}
function makeMusic(id, seed, title, bpmBias = 0) {
	const rand = lcg(seed || 1);
	const steps = seed % 7 === 0 ? 12 : 16;
	const scale = SCALES[seed % SCALES.length];
	const bpm = Math.max(58, Math.min(164, 68 + seed * 11 % 92 + bpmBias));
	const leadWave = WAVES[seed % WAVES.length];
	const bassWave = WAVES[(seed + 2) % WAVES.length];
	const maxIdx = Math.min(7, scale.length);
	const kick = seed % 9 !== 2;
	const snare = seed % 5 !== 0;
	const hats = seed % 8 !== 3;
	return {
		id,
		title,
		bpm,
		steps,
		rootHz: ROOTS[seed % ROOTS.length],
		scale,
		chords: [
			[
				0,
				2,
				4
			],
			[
				1,
				3,
				5
			],
			[
				0,
				2,
				3
			],
			[
				2,
				4,
				6
			].map((n) => n % maxIdx)
		],
		bass: seq(rand, steps, .42, Math.min(5, maxIdx)),
		lead: seq(rand, steps, .5, maxIdx),
		arp: seq(rand, steps, .72, maxIdx),
		leadWave,
		bassWave,
		leadGain: .028 + seed % 5 * .006,
		bassGain: .05 + seed % 4 * .012,
		arpGain: .016 + seed % 3 * .004,
		padGain: .024 + seed % 4 * .006,
		noteFrac: .28 + seed % 6 * .12,
		filterHz: 700 + seed % 9 * 180,
		delay: .1 + seed % 8 * .05,
		swing: seed % 6 * .025,
		kick,
		snare,
		hats,
		kickG: drumPat(rand, steps, kick ? .22 : 0),
		snareG: drumPat(rand, steps, snare ? .14 : 0),
		hatG: drumPat(rand, steps, hats ? .45 : 0)
	};
}
function handMusic() {
	return {
		title: {
			id: "title",
			title: "Idle Field",
			bpm: 52,
			steps: 16,
			rootHz: 55,
			scale: [
				0,
				3,
				7,
				10,
				12,
				15,
				19
			],
			chords: [
				[
					0,
					2,
					4
				],
				[
					0,
					2,
					3
				],
				[
					1,
					2,
					4
				],
				[
					0,
					2,
					4
				]
			],
			bass: [
				0,
				R,
				R,
				R,
				R,
				R,
				R,
				R,
				3,
				R,
				R,
				R,
				R,
				R,
				R,
				R
			],
			lead: [
				4,
				R,
				R,
				R,
				6,
				R,
				R,
				R,
				5,
				R,
				R,
				R,
				4,
				R,
				2,
				R
			],
			arp: [
				0,
				2,
				4,
				2,
				0,
				2,
				4,
				6,
				0,
				2,
				4,
				2,
				3,
				2,
				0,
				2
			],
			leadWave: "sine",
			bassWave: "sine",
			leadGain: .04,
			bassGain: .07,
			arpGain: .018,
			padGain: .045,
			noteFrac: 2.2,
			filterHz: 900,
			delay: .46,
			swing: 0,
			kick: false,
			snare: false,
			hats: false
		},
		shale: {
			id: "shale",
			title: "Shale Drift",
			bpm: 86,
			steps: 16,
			rootHz: 73.42,
			scale: [
				0,
				2,
				3,
				5,
				7,
				9,
				10,
				12
			],
			chords: [
				[
					0,
					2,
					4
				],
				[
					3,
					5,
					7
				],
				[
					0,
					2,
					4
				],
				[
					2,
					4,
					6
				]
			],
			bass: [
				0,
				R,
				R,
				0,
				R,
				R,
				3,
				R,
				0,
				R,
				0,
				R,
				4,
				R,
				3,
				R
			],
			lead: [
				4,
				R,
				5,
				4,
				R,
				2,
				R,
				0,
				4,
				R,
				7,
				5,
				R,
				4,
				2,
				R
			],
			arp: [
				0,
				2,
				4,
				0,
				2,
				4,
				7,
				4,
				0,
				2,
				4,
				0,
				3,
				5,
				4,
				2
			],
			leadWave: "triangle",
			bassWave: "sine",
			leadGain: .055,
			bassGain: .08,
			arpGain: .022,
			padGain: .04,
			noteFrac: .72,
			filterHz: 1100,
			delay: .22,
			swing: .08,
			kick: true,
			snare: true,
			hats: true
		},
		rime: makeMusic("rime", 2, "Rime Wake", 10),
		twin: makeMusic("twin", 3, "Twin Belt", 16),
		quartz: makeMusic("quartz", 4, "Quartz Vein", 28),
		alloy: makeMusic("alloy", 5, "Alloy Rain", 8),
		fourfold: makeMusic("fourfold", 6, "Fourfold", 22),
		splinter: makeMusic("splinter", 7, "Splinter Field", 44),
		halo: makeMusic("halo", 8, "Dense Halo", -8),
		titan: makeMusic("titan", 9, "Titan Core", -28),
		gauntlet: makeMusic("gauntlet", 10, "Prism Gauntlet", 48),
		drift0: makeMusic("drift0", 101, "Open Drift", 12),
		drift1: makeMusic("drift1", 102, "Deep Drift", 26),
		drift2: makeMusic("drift2", 103, "Far Drift", -12)
	};
}
var MUSIC = { ...handMusic() };
for (const lvl of LEVELS) if (!MUSIC[lvl.music]) MUSIC[lvl.music] = makeMusic(lvl.music, lvl.id * 17 + 4, lvl.name, lvl.id % 9 * 3);
var INFINITE_MUSIC = [
	"drift0",
	"drift1",
	"drift2",
	"fourfold",
	"splinter",
	"gauntlet",
	"sec-22",
	"sec-36",
	"sec-44"
];
var WEAPON_INTRO = {
	kinetic: 1,
	cryo: 2,
	resonant: 4,
	thermal: 5
};
function unlockedWeapons(campaignReached) {
	return [
		"kinetic",
		"cryo",
		"resonant",
		"thermal"
	].filter((w) => campaignReached >= WEAPON_INTRO[w]);
}
function infiniteMusicId(wave) {
	return INFINITE_MUSIC[(wave - 1) % INFINITE_MUSIC.length] ?? "drift0";
}
function infiniteBpm(wave, base) {
	return Math.min(168, base + Math.max(0, wave - 1) * 3);
}
function formatTime(ms) {
	const clamped = Math.max(0, Math.floor(ms));
	const m = Math.floor(clamped / 6e4);
	const s = Math.floor(clamped % 6e4 / 1e3);
	const cs = Math.floor(clamped % 1e3 / 10);
	if (m > 0) return `${m}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
	return `${s}.${String(cs).padStart(2, "0")}s`;
}
var BEAM_STYLES = [
	"line",
	"double",
	"spark",
	"ribbon",
	"pulse",
	"dash"
];
var ROCK_CUTS = [
	"rough",
	"cut",
	"ice",
	"crystal",
	"plate",
	"ember"
];
function hslHex(h, s, l) {
	const sat = Math.max(0, Math.min(100, s)) / 100;
	const lig = Math.max(0, Math.min(100, l)) / 100;
	const a = sat * Math.min(lig, 1 - lig);
	const f = (n) => {
		const k = (n + h / 30) % 12;
		const c = lig - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
		return Math.round(255 * c).toString(16).padStart(2, "0");
	};
	return `#${f(0)}${f(8)}${f(4)}`;
}
function packColors(rot, sat, light) {
	return {
		basalt: hslHex((32 + rot) % 360, 28 + sat, 62 + light),
		rime: hslHex((188 + rot) % 360, 42 + sat, 68 + light),
		quartz: hslHex((148 + rot) % 360, 32 + sat, 64 + light),
		alloy: hslHex((22 + rot) % 360, 46 + sat, 56 + light)
	};
}
function extraCost(i) {
	if (i <= 0) return 0;
	if (i < 10) return 40 + i * 10;
	if (i < 24) return 160 + (i - 10) * 16;
	if (i < 38) return 420 + (i - 24) * 24;
	return 820 + (i - 38) * 55;
}
var LASER_META = [
	{
		name: "Stock",
		blurb: "Factory lance."
	},
	{
		name: "Needle",
		blurb: "Thin pierce."
	},
	{
		name: "Twinline",
		blurb: "Paired rails."
	},
	{
		name: "Ribbon",
		blurb: "Soft sheet."
	},
	{
		name: "Nova",
		blurb: "Wide bloom."
	},
	{
		name: "Comet",
		blurb: "Tailed spark."
	},
	{
		name: "Pulse",
		blurb: "Breathing edge."
	},
	{
		name: "Emberbeam",
		blurb: "Hot core."
	},
	{
		name: "Frostbit",
		blurb: "Ice stitch."
	},
	{
		name: "Quartzarc",
		blurb: "Crystal cut."
	},
	{
		name: "Alloyedge",
		blurb: "Hard line."
	},
	{
		name: "Veil",
		blurb: "Soft veil."
	},
	{
		name: "Thorn",
		blurb: "Barbed tip."
	},
	{
		name: "Halo",
		blurb: "Ringed glow."
	},
	{
		name: "Drift",
		blurb: "Slow wash."
	},
	{
		name: "Ionspike",
		blurb: "Sharp ion."
	},
	{
		name: "Glasscut",
		blurb: "Clear slice."
	},
	{
		name: "Magma",
		blurb: "Molten bead."
	},
	{
		name: "Tide",
		blurb: "Pull and flash."
	},
	{
		name: "Umber",
		blurb: "Earthy lance."
	},
	{
		name: "Opaline",
		blurb: "Shift fire."
	},
	{
		name: "Cinder",
		blurb: "After burn."
	},
	{
		name: "Saturn",
		blurb: "Ring light."
	},
	{
		name: "Voidgleam",
		blurb: "Last gleam."
	},
	{
		name: "Brassarc",
		blurb: "Horn metal."
	},
	{
		name: "Kelp",
		blurb: "Deep green."
	},
	{
		name: "Glacier",
		blurb: "Slow blue."
	},
	{
		name: "Pyre",
		blurb: "Short fuse."
	},
	{
		name: "Indigo",
		blurb: "Night dye."
	},
	{
		name: "Coral",
		blurb: "Reef light."
	},
	{
		name: "Fogline",
		blurb: "Soft veil."
	},
	{
		name: "Plasma",
		blurb: "Hot field."
	},
	{
		name: "Chartreuse",
		blurb: "Acid silk."
	},
	{
		name: "Mercury",
		blurb: "Live metal."
	},
	{
		name: "Amethyst",
		blurb: "Royal shard."
	},
	{
		name: "Flare",
		blurb: "Signal fire."
	},
	{
		name: "Mint",
		blurb: "Cool leaf."
	},
	{
		name: "Nectar",
		blurb: "Sweet burn."
	},
	{
		name: "Slate",
		blurb: "Cut stone."
	},
	{
		name: "Bloom",
		blurb: "Open petal."
	},
	{
		name: "Sand",
		blurb: "Dry halo."
	},
	{
		name: "Steel",
		blurb: "Cold plate."
	},
	{
		name: "Wine",
		blurb: "Dark fruit."
	},
	{
		name: "Lime",
		blurb: "Acid wash."
	},
	{
		name: "Dusk",
		blurb: "Late orbit."
	},
	{
		name: "Citrus",
		blurb: "Sharp rind."
	},
	{
		name: "Rose",
		blurb: "Dust bloom."
	},
	{
		name: "Noir",
		blurb: "Low light."
	},
	{
		name: "Moss",
		blurb: "Belt growth."
	},
	{
		name: "Pearl",
		blurb: "Soft core."
	}
];
var PACK_META = [
	{
		name: "Shale",
		blurb: "Belt default."
	},
	{
		name: "Rimefield",
		blurb: "Cold crust."
	},
	{
		name: "Quartzbed",
		blurb: "Crystal floor."
	},
	{
		name: "Alloyset",
		blurb: "Worked metal."
	},
	{
		name: "Aurora",
		blurb: "Polar wash."
	},
	{
		name: "Emberfall",
		blurb: "Hot rain."
	},
	{
		name: "Ionvein",
		blurb: "Charged seam."
	},
	{
		name: "Gilded",
		blurb: "Lucky ore."
	},
	{
		name: "Obsidian",
		blurb: "Dark glass."
	},
	{
		name: "Violetore",
		blurb: "Dusk mineral."
	},
	{
		name: "Rustbelt",
		blurb: "Old hull."
	},
	{
		name: "Frostpack",
		blurb: "Thin ice."
	},
	{
		name: "Jadevein",
		blurb: "Quiet green."
	},
	{
		name: "Copper",
		blurb: "Warm ore."
	},
	{
		name: "Cobalt",
		blurb: "Deep pulse."
	},
	{
		name: "Pearldust",
		blurb: "Soft grit."
	},
	{
		name: "Magmarock",
		blurb: "Open kiln."
	},
	{
		name: "Mosscrust",
		blurb: "Living stone."
	},
	{
		name: "Noirstone",
		blurb: "Low light."
	},
	{
		name: "Rosequartz",
		blurb: "Dust bloom."
	},
	{
		name: "Citrussplit",
		blurb: "Sharp rind."
	},
	{
		name: "Duskore",
		blurb: "Late orbit."
	},
	{
		name: "Limewash",
		blurb: "Acid coat."
	},
	{
		name: "Wineslate",
		blurb: "Dark fruit."
	},
	{
		name: "Steelcut",
		blurb: "Cold plate."
	},
	{
		name: "Sandstone",
		blurb: "Dry halo."
	},
	{
		name: "Bloomrock",
		blurb: "Open petal."
	},
	{
		name: "Icepack",
		blurb: "Hard rime."
	},
	{
		name: "Nectarbelt",
		blurb: "Sweet burn."
	},
	{
		name: "Slatebed",
		blurb: "Cut floor."
	},
	{
		name: "Flarestone",
		blurb: "Signal fire."
	},
	{
		name: "Mintcrust",
		blurb: "Cool leaf."
	},
	{
		name: "Emberglass",
		blurb: "Fired silica."
	},
	{
		name: "Tidalrock",
		blurb: "Pull and push."
	},
	{
		name: "Umberpack",
		blurb: "Earth crust."
	},
	{
		name: "Quartzite",
		blurb: "Pressed crystal."
	},
	{
		name: "Plasmarock",
		blurb: "Hot field."
	},
	{
		name: "Fogstone",
		blurb: "Soft veil."
	},
	{
		name: "Coralreef",
		blurb: "Reef light."
	},
	{
		name: "Onyxcut",
		blurb: "Black cut."
	},
	{
		name: "Chartpack",
		blurb: "Acid silk."
	},
	{
		name: "Indigovein",
		blurb: "Night dye."
	},
	{
		name: "Brassore",
		blurb: "Horn metal."
	},
	{
		name: "Glacierpack",
		blurb: "Slow blue."
	},
	{
		name: "Pyroclast",
		blurb: "Short fuse."
	},
	{
		name: "Kelpbed",
		blurb: "Deep green."
	},
	{
		name: "Ivory",
		blurb: "Bone well."
	},
	{
		name: "Mercurylith",
		blurb: "Live metal."
	},
	{
		name: "Amethystpack",
		blurb: "Royal shard."
	},
	{
		name: "Cinderbelt",
		blurb: "After burn."
	}
];
function slug(prefix, name) {
	return `${prefix}-${name.toLowerCase().replace(/[^a-z0-9]+/g, "")}`;
}
var LASER_SKINS = LASER_META.map((m, i) => ({
	id: slug("beam", m.name),
	name: m.name,
	blurb: m.blurb,
	cost: extraCost(i),
	style: i === 0 ? "line" : BEAM_STYLES[i % BEAM_STYLES.length],
	width: i === 0 ? 2.6 : 1.5 + i % 5 * .5,
	glow: i === 0 ? 16 : 8 + i % 7 * 3,
	sat: i === 0 ? 1 : .82 + i % 5 * .08,
	light: i === 0 ? 10 : 4 + i % 6 * 3
}));
var ROCK_PACKS = PACK_META.map((m, i) => ({
	id: slug("pack", m.name),
	name: m.name,
	blurb: m.blurb,
	cost: extraCost(i),
	colors: i === 0 ? {
		basalt: "#b8a48a",
		rime: "#8ed0da",
		quartz: "#9fc9b0",
		alloy: "#c98b62"
	} : packColors(i * 17 % 360, i % 5 * 4, i % 3 * 3 - 2),
	fill: .1 + i % 5 * .03,
	cut: i === 0 ? "rough" : ROCK_CUTS[i % ROCK_CUTS.length]
}));
var DEFAULT_LASER_ID = LASER_SKINS[0].id;
var DEFAULT_PACK_ID = ROCK_PACKS[0].id;
function laserById(id) {
	return LASER_SKINS.find((s) => s.id === id) ?? LASER_SKINS[0];
}
function packById(id) {
	return ROCK_PACKS.find((s) => s.id === id) ?? ROCK_PACKS[0];
}
function isLaserId(id) {
	return LASER_SKINS.some((s) => s.id === id);
}
function isPackId(id) {
	return ROCK_PACKS.some((s) => s.id === id);
}
function livePalette(laserId, packId) {
	const laser = laserById(laserId);
	const pack = packById(packId);
	const kind = pack.colors;
	return {
		kind,
		weapon: {
			kinetic: kind.basalt,
			cryo: kind.rime,
			resonant: kind.quartz,
			thermal: kind.alloy
		},
		laser,
		pack
	};
}
function gachaPool() {
	return [
		...SKINS.filter((s) => s.cost > 0).map((s) => ({
			kind: "well",
			id: s.id,
			name: s.name,
			cost: s.cost
		})),
		...LASER_SKINS.filter((s) => s.cost > 0).map((s) => ({
			kind: "laser",
			id: s.id,
			name: s.name,
			cost: s.cost
		})),
		...ROCK_PACKS.filter((s) => s.cost > 0).map((s) => ({
			kind: "pack",
			id: s.id,
			name: s.name,
			cost: s.cost
		}))
	];
}
function rollGacha(owned) {
	const pool = gachaPool();
	const weights = pool.map((p) => 1 / Math.pow(p.cost + 28, 1.55));
	const total = weights.reduce((a, b) => a + b, 0);
	let r = Math.random() * total;
	let pick = pool[0];
	for (let i = 0; i < pool.length; i++) {
		r -= weights[i];
		if (r <= 0) {
			pick = pool[i];
			break;
		}
	}
	const list = pick.kind === "well" ? owned.wells : pick.kind === "laser" ? owned.lasers : owned.packs;
	return {
		...pick,
		duplicate: list.includes(pick.id)
	};
}
//#endregion
export { rollGacha as _, MUSIC as a, authMiddleware as c, infiniteMusicId as d, isLaserId as f, packById as g, livePalette as h, LEVELS as i, formatTime as l, laserById as m, DEFAULT_PACK_ID as n, ROCK_PACKS as o, isPackId as p, LASER_SKINS as r, SKINS as s, DEFAULT_LASER_ID as t, infiniteBpm as u, skinById as v, unlockedWeapons as y };
