import { createFileRoute, Link } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  return (
    <main className="grid min-h-dvh place-items-center bg-bg px-5 py-10 text-fg">
      <div className="w-full max-w-sm">
        <p className="font-mono text-xs uppercase tracking-[0.28em] text-subtle">
          VOID PRISM
        </p>
        <h1 className="mt-3 font-display text-3xl font-semibold tracking-[-0.04em]">
          Sign in
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Save hangar progress, post sector times, and climb the Infinite Drift
          board.
        </p>
        <div className="mt-8 flex flex-col gap-3">
          {authEnabled ? (
            GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                size="lg"
                className="w-full"
                onClick={() => signIn(p.providerId, { callbackURL: "/" })}
              >
                Continue with {p.label}
              </Button>
            ))
          ) : (
            <p className="text-sm text-muted">Sign-in is disabled.</p>
          )}
        </div>
        <p className="mt-8">
          <Link
            to="/"
            className="font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg"
          >
            Back to hangar
          </Link>
        </p>
      </div>
    </main>
  );
}
