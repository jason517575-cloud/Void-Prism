import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { normalizeName, officialNameTaken, sanitizeLevel, type CustomLevelDef } from "@/game/custom-level";

export type LevelCard = {
  id: string;
  name: string;
  author: string;
  authorId: string;
  mine: boolean;
  summary: string;
};

export type FriendRow = {
  userId: string;
  username: string;
  incoming: boolean;
};

export type ChatLine = {
  id: string;
  mine: boolean;
  body: string;
  at: string;
};

function cleanUser(name: string) {
  return name.trim().slice(0, 16);
}

function validUser(name: string) {
  return /^[A-Za-z0-9_]{3,16}$/.test(name);
}

async function usernameOf(sql: Awaited<ReturnType<typeof getSql>>, userId: string) {
  const rows = await sql<{ username: string }>`
    select username from profiles where user_id = ${userId} limit 1
  `;
  return rows[0]?.username ?? "";
}

export const getSeason = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`select n from season_state where id = 1 limit 1`;
  return { n: rows[0]?.n ?? 1 };
});

export const resetSeason = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async () => {
    const sql = await getSql();
    await sql`update player_progress set fragments = 0`;
    await sql`delete from custom_levels`;
    const rows = await sql<{ n: number }>`
      update season_state set n = n + 1 where id = 1 returning n
    `;
    const n = rows[0]?.n ?? 1;
    return { ok: true as const, season: n };
  });

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    return { username: await usernameOf(sql, context.userId) };
  });

export const claimUsername = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { username: string }) => d)
  .handler(async ({ context, data }) => {
    const username = cleanUser(data.username);
    if (!validUser(username)) {
      return { ok: false as const, error: "3–16 letters, numbers, or underscore." };
    }
    const sql = await getSql();
    const taken = await sql<{ user_id: string }>`
      select user_id from profiles where lower(username) = lower(${username}) limit 1
    `;
    if (taken[0] && taken[0].user_id !== context.userId) {
      return { ok: false as const, error: "That username is taken." };
    }
    const mine = await usernameOf(sql, context.userId);
    if (mine) {
      try {
        await sql`
          update profiles set username = ${username} where user_id = ${context.userId}
        `;
      } catch {
        return { ok: false as const, error: "That username is taken." };
      }
    } else {
      try {
        await sql`
          insert into profiles (user_id, username) values (${context.userId}, ${username})
        `;
      } catch {
        return { ok: false as const, error: "That username is taken." };
      }
    }
    return { ok: true as const, username };
  });

export const listLibrary = createServerFn({ method: "GET" })
  .validator((d: { q?: string }) => d ?? {})
  .handler(async ({ data }): Promise<LevelCard[]> => {
    const sql = await getSql();
    const q = String(data?.q ?? "").trim().slice(0, 32).toLowerCase();
    const rows = q
      ? await sql<{ id: string; user_id: string; name: string; summary: string; username: string | null }>`
          select c.id, c.user_id, c.name, c.summary, p.username
          from custom_levels c
          left join profiles p on p.user_id = c.user_id
          where lower(c.name) like ${"%" + q + "%"}
          order by c.created_at desc
          limit 40
        `
      : await sql<{ id: string; user_id: string; name: string; summary: string; username: string | null }>`
          select c.id, c.user_id, c.name, c.summary, p.username
          from custom_levels c
          left join profiles p on p.user_id = c.user_id
          order by c.created_at desc
          limit 40
        `;
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      author: r.username || "Pilot",
      authorId: r.user_id,
      mine: false,
      summary: r.summary,
    }));
  });

export const listMyLevels = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<LevelCard[]> => {
    const sql = await getSql();
    const rows = await sql<{ id: string; name: string; summary: string }>`
      select id, name, summary from custom_levels
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
    const username = (await usernameOf(sql, context.userId)) || "You";
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      author: username,
      authorId: context.userId,
      mine: true,
      summary: r.summary,
    }));
  });

export const getCustomLevel = createServerFn({ method: "GET" })
  .validator((d: { id: string }) => d)
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql<{ def: string; name: string }>`
      select def, name from custom_levels where id = ${data.id} limit 1
    `;
    if (!rows[0]) return { ok: false as const, error: "Level is gone." };
    let parsed: unknown;
    try {
      parsed = JSON.parse(rows[0].def);
    } catch {
      return { ok: false as const, error: "Level is broken." };
    }
    const clean = sanitizeLevel(parsed);
    if (!clean.ok) return clean;
    return { ok: true as const, level: clean.level };
  });

export const publishLevel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { level: CustomLevelDef }) => d)
  .handler(async ({ context, data }) => {
    const clean = sanitizeLevel(data.level);
    if (!clean.ok) return clean;
    const name = normalizeName(clean.level.name);
    if (officialNameTaken(name)) return { ok: false as const, error: "That name is already a campaign sector." };
    const sql = await getSql();
    const username = await usernameOf(sql, context.userId);
    if (!username) return { ok: false as const, error: "Set a username before you publish." };
    const clash = await sql<{ user_id: string }>`
      select user_id from custom_levels where lower(name) = lower(${name}) limit 1
    `;
    if (clash[0]) return { ok: false as const, error: "A level already uses that name." };
    const id = crypto.randomUUID();
    const summary = `${clean.level.spawn === "placed" ? clean.level.rocks.length : clean.level.count} rocks · speed ${clean.level.speed}`;
    try {
      await sql`
        insert into custom_levels (id, user_id, name, summary, def)
        values (
          ${id},
          ${context.userId},
          ${name},
          ${summary},
          ${JSON.stringify(clean.level)}
        )
      `;
    } catch {
      return { ok: false as const, error: "A level already uses that name." };
    }
    return { ok: true as const, id };
  });

export const deleteMyLevel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { id: string }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from custom_levels
      where id = ${data.id} and user_id = ${context.userId}
      returning id
    `;
    if (!rows[0]) return { ok: false as const, error: "You can only delete your own levels." };
    return { ok: true as const };
  });

export const searchPilots = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((d: { q: string }) => d)
  .handler(async ({ context, data }) => {
    const q = cleanUser(data.q);
    if (q.length < 2) return [];
    const sql = await getSql();
    const rows = await sql<{ user_id: string; username: string }>`
      select user_id, username from profiles
      where lower(username) like ${q.toLowerCase() + "%"}
        and user_id <> ${context.userId}
      order by username
      limit 8
    `;
    return rows.map((r) => ({ userId: r.user_id, username: r.username }));
  });

export const requestFriend = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string }) => d)
  .handler(async ({ context, data }) => {
    if (!data.userId || data.userId === context.userId) {
      return { ok: false as const, error: "Pick someone else." };
    }
    const sql = await getSql();
    if (!(await usernameOf(sql, context.userId))) {
      return { ok: false as const, error: "Set a username first." };
    }
    const exists = await sql<{ user_id: string }>`
      select user_id from profiles where user_id = ${data.userId} limit 1
    `;
    if (!exists[0]) return { ok: false as const, error: "No pilot with that name." };
    const prior = await sql<{ id: string; status: string }>`
      select id, status from friendships
      where (requester = ${context.userId} and addressee = ${data.userId})
         or (requester = ${data.userId} and addressee = ${context.userId})
      limit 1
    `;
    if (prior[0]?.status === "accepted") return { ok: false as const, error: "Already friends." };
    if (prior[0]) return { ok: false as const, error: "A request is already waiting." };
    await sql`
      insert into friendships (id, requester, addressee, status)
      values (${crypto.randomUUID()}, ${context.userId}, ${data.userId}, ${"pending"})
    `;
    return { ok: true as const };
  });

export const respondFriend = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string; accept: boolean }) => d)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    if (!data.accept) {
      await sql`
        delete from friendships
        where addressee = ${context.userId} and requester = ${data.userId} and status = ${"pending"}
      `;
      return { ok: true as const };
    }
    const rows = await sql<{ id: string }>`
      update friendships set status = ${"accepted"}
      where addressee = ${context.userId} and requester = ${data.userId} and status = ${"pending"}
      returning id
    `;
    if (!rows[0]) return { ok: false as const, error: "No request from that pilot." };
    return { ok: true as const };
  });

export const listFriends = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const asRequester = await sql<{ addressee: string; username: string }>`
      select f.addressee, p.username
      from friendships f
      join profiles p on p.user_id = f.addressee
      where f.requester = ${context.userId} and f.status = ${"accepted"}
    `;
    const asAddressee = await sql<{ requester: string; username: string }>`
      select f.requester, p.username
      from friendships f
      join profiles p on p.user_id = f.requester
      where f.addressee = ${context.userId} and f.status = ${"accepted"}
    `;
    const incoming = await sql<{ requester: string; username: string }>`
      select f.requester, p.username
      from friendships f
      join profiles p on p.user_id = f.requester
      where f.addressee = ${context.userId} and f.status = ${"pending"}
    `;
    const friends: FriendRow[] = [
      ...asRequester.map((r) => ({
        userId: r.addressee,
        username: r.username,
        incoming: false,
      })),
      ...asAddressee.map((r) => ({
        userId: r.requester,
        username: r.username,
        incoming: false,
      })),
    ];
    const requests: FriendRow[] = incoming.map((r) => ({
      userId: r.requester,
      username: r.username,
      incoming: true,
    }));
    return { friends, requests };
  });

async function areFriends(sql: Awaited<ReturnType<typeof getSql>>, a: string, b: string) {
  const rows = await sql<{ id: string }>`
    select id from friendships
    where status = ${"accepted"}
      and (
        (requester = ${a} and addressee = ${b})
        or (requester = ${b} and addressee = ${a})
      )
    limit 1
  `;
  return Boolean(rows[0]);
}

export const listMessages = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((d: { userId: string }) => d)
  .handler(async ({ context, data }): Promise<ChatLine[]> => {
    const sql = await getSql();
    if (!(await areFriends(sql, context.userId, data.userId))) return [];
    const rows = await sql<{ id: string; sender: string; body: string; created_at: string }>`
      select id, sender, body, created_at
      from messages
      where (sender = ${context.userId} and recipient = ${data.userId})
         or (sender = ${data.userId} and recipient = ${context.userId})
      order by created_at asc
      limit 80
    `;
    return rows.map((r) => ({
      id: r.id,
      mine: r.sender === context.userId,
      body: r.body,
      at: String(r.created_at),
    }));
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((d: { userId: string; body: string }) => d)
  .handler(async ({ context, data }) => {
    const body = data.body.trim().slice(0, 400);
    if (!body) return { ok: false as const, error: "Empty message." };
    const sql = await getSql();
    if (!(await areFriends(sql, context.userId, data.userId))) {
      return { ok: false as const, error: "You can only chat with friends." };
    }
    await sql`
      insert into messages (id, sender, recipient, body)
      values (${crypto.randomUUID()}, ${context.userId}, ${data.userId}, ${body})
    `;
    return { ok: true as const };
  });
