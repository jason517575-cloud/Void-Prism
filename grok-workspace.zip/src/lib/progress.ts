import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { LEVELS, SKINS } from "@/game/catalog";
import {
  DEFAULT_LASER_ID,
  DEFAULT_PACK_ID,
  LASER_SKINS,
  ROCK_PACKS,
} from "@/game/cosmetics";

export type ProgressPayload = {
  campaignReached: number;
  campaignBest: number;
  infiniteBest: number;
  infiniteBestWave: number;
  fragments: number;
  ownedSkins: string[];
  equippedSkin: string;
  ownedLasers: string[];
  equippedLaser: string;
  ownedPacks: string[];
  equippedPack: string;
  campaignTimes: Record<number, number>;
};

export type BoardRow = {
  rank: number;
  userId: string;
  value: number;
  score: number;
  mine: boolean;
  name: string;
};

function clampInt(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, Math.floor(n)));
}

function parseIdList(raw: string, allowed: Set<string>, fallback: string): string[] {
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [fallback];
    const ids = parsed.filter((id): id is string => typeof id === "string" && allowed.has(id));
    if (!ids.includes(fallback)) ids.unshift(fallback);
    return ids;
  } catch {
    return [fallback];
  }
}

function parseSkins(raw: string): string[] {
  return parseIdList(raw, new Set(SKINS.map((s) => s.id)), "prism");
}

function displayName(name: string | null, email: string | null): string {
  const n = (name ?? "").trim();
  if (n) return n.slice(0, 32);
  const local = (email ?? "").split("@")[0] ?? "";
  if (local) return local.slice(0, 24);
  return "Pilot";
}

const emptyProgress = (campaignTimes: Record<number, number>): ProgressPayload => ({
  campaignReached: 1,
  campaignBest: 0,
  infiniteBest: 0,
  infiniteBestWave: 0,
  fragments: 0,
  ownedSkins: ["prism"],
  equippedSkin: "prism",
  ownedLasers: [DEFAULT_LASER_ID],
  equippedLaser: DEFAULT_LASER_ID,
  ownedPacks: [DEFAULT_PACK_ID],
  equippedPack: DEFAULT_PACK_ID,
  campaignTimes,
});

export const getProgress = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ProgressPayload> => {
    const sql = await getSql();
    const rows = await sql<{
      campaign_reached: number;
      campaign_best: number;
      infinite_best_score: number;
      infinite_best_wave: number;
      fragments: number;
      owned_skins: string;
      equipped_skin: string;
      owned_lasers: string;
      equipped_laser: string;
      owned_packs: string;
      equipped_pack: string;
    }>`
      select campaign_reached, campaign_best, infinite_best_score, infinite_best_wave,
             fragments, owned_skins, equipped_skin,
             owned_lasers, equipped_laser, owned_packs, equipped_pack
      from player_progress
      where user_id = ${context.userId}
    `;
    const times = await sql<{ level_id: number; best_ms: number }>`
      select level_id, best_ms from campaign_times where user_id = ${context.userId}
    `;
    const campaignTimes: Record<number, number> = {};
    for (const t of times) campaignTimes[t.level_id] = t.best_ms;
    const row = rows[0];
    if (!row) return emptyProgress(campaignTimes);
    const owned = parseSkins(row.owned_skins);
    const equipped = owned.includes(row.equipped_skin) ? row.equipped_skin : "prism";
    const lasers = parseIdList(
      row.owned_lasers,
      new Set(LASER_SKINS.map((s) => s.id)),
      DEFAULT_LASER_ID,
    );
    const packs = parseIdList(
      row.owned_packs,
      new Set(ROCK_PACKS.map((s) => s.id)),
      DEFAULT_PACK_ID,
    );
    return {
      campaignReached: row.campaign_reached,
      campaignBest: row.campaign_best,
      infiniteBest: row.infinite_best_score,
      infiniteBestWave: row.infinite_best_wave,
      fragments: row.fragments,
      ownedSkins: owned,
      equippedSkin: equipped,
      ownedLasers: lasers,
      equippedLaser: lasers.includes(row.equipped_laser) ? row.equipped_laser : DEFAULT_LASER_ID,
      ownedPacks: packs,
      equippedPack: packs.includes(row.equipped_pack) ? row.equipped_pack : DEFAULT_PACK_ID,
      campaignTimes,
    };
  });

export const saveProgress = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: Omit<ProgressPayload, "campaignTimes">) => {
    const allowed = new Set(SKINS.map((s) => s.id));
    const owned = Array.isArray(input.ownedSkins)
      ? input.ownedSkins.filter((id) => allowed.has(id))
      : ["prism"];
    if (!owned.includes("prism")) owned.unshift("prism");
    const equipped = allowed.has(input.equippedSkin) && owned.includes(input.equippedSkin)
      ? input.equippedSkin
      : "prism";
    const laserAllowed = new Set(LASER_SKINS.map((s) => s.id));
    const packAllowed = new Set(ROCK_PACKS.map((s) => s.id));
    const ownedLasers = Array.isArray(input.ownedLasers)
      ? input.ownedLasers.filter((id) => laserAllowed.has(id))
      : [DEFAULT_LASER_ID];
    if (!ownedLasers.includes(DEFAULT_LASER_ID)) ownedLasers.unshift(DEFAULT_LASER_ID);
    const ownedPacks = Array.isArray(input.ownedPacks)
      ? input.ownedPacks.filter((id) => packAllowed.has(id))
      : [DEFAULT_PACK_ID];
    if (!ownedPacks.includes(DEFAULT_PACK_ID)) ownedPacks.unshift(DEFAULT_PACK_ID);
    const equippedLaser =
      laserAllowed.has(input.equippedLaser) && ownedLasers.includes(input.equippedLaser)
        ? input.equippedLaser
        : DEFAULT_LASER_ID;
    const equippedPack =
      packAllowed.has(input.equippedPack) && ownedPacks.includes(input.equippedPack)
        ? input.equippedPack
        : DEFAULT_PACK_ID;
    return {
      campaignReached: clampInt(input.campaignReached, 1, LEVELS.length + 1),
      campaignBest: clampInt(input.campaignBest, 0, 9_999_999),
      infiniteBest: clampInt(input.infiniteBest, 0, 9_999_999),
      infiniteBestWave: clampInt(input.infiniteBestWave, 0, 9_999),
      fragments: clampInt(input.fragments, 0, 9_999_999),
      ownedSkins: owned,
      equippedSkin: equipped,
      ownedLasers,
      equippedLaser,
      ownedPacks,
      equippedPack,
    };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const skins = JSON.stringify(data.ownedSkins);
    const lasers = JSON.stringify(data.ownedLasers);
    const packs = JSON.stringify(data.ownedPacks);
    await sql`
      insert into player_progress (
        user_id, campaign_reached, campaign_best, infinite_best_score, infinite_best_wave,
        fragments, owned_skins, equipped_skin, owned_lasers, equipped_laser,
        owned_packs, equipped_pack, updated_at
      ) values (
        ${context.userId}, ${data.campaignReached}, ${data.campaignBest}, ${data.infiniteBest},
        ${data.infiniteBestWave}, ${data.fragments}, ${skins}, ${data.equippedSkin},
        ${lasers}, ${data.equippedLaser}, ${packs}, ${data.equippedPack}, now()
      )
      on conflict (user_id) do update set
        campaign_reached = greatest(player_progress.campaign_reached, excluded.campaign_reached),
        campaign_best = greatest(player_progress.campaign_best, excluded.campaign_best),
        infinite_best_score = greatest(player_progress.infinite_best_score, excluded.infinite_best_score),
        infinite_best_wave = greatest(player_progress.infinite_best_wave, excluded.infinite_best_wave),
        fragments = excluded.fragments,
        owned_skins = excluded.owned_skins,
        equipped_skin = excluded.equipped_skin,
        owned_lasers = excluded.owned_lasers,
        equipped_laser = excluded.equipped_laser,
        owned_packs = excluded.owned_packs,
        equipped_pack = excluded.equipped_pack,
        updated_at = now()
    `;
    return { ok: true as const };
  });

export const submitCampaignTime = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { levelId: number; timeMs: number; score: number }) => ({
    levelId: clampInt(input.levelId, 1, LEVELS.length),
    timeMs: clampInt(input.timeMs, 400, 7_200_000),
    score: clampInt(input.score, 0, 9_999_999),
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into campaign_times (user_id, level_id, best_ms, score, updated_at)
      values (${context.userId}, ${data.levelId}, ${data.timeMs}, ${data.score}, now())
      on conflict (user_id, level_id) do update set
        best_ms = least(campaign_times.best_ms, excluded.best_ms),
        score = greatest(campaign_times.score, excluded.score),
        updated_at = now()
    `;
    return { ok: true as const };
  });

export const submitInfiniteWave = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { wave: number; score: number }) => ({
    wave: clampInt(input.wave, 1, 9_999),
    score: clampInt(input.score, 0, 9_999_999),
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`
      insert into infinite_scores (user_id, best_wave, best_score, updated_at)
      values (${context.userId}, ${data.wave}, ${data.score}, now())
      on conflict (user_id) do update set
        best_wave = greatest(infinite_scores.best_wave, excluded.best_wave),
        best_score = greatest(infinite_scores.best_score, excluded.best_score),
        updated_at = now()
    `;
    return { ok: true as const };
  });

export const listCampaignBoard = createServerFn({ method: "GET" })
  .validator((input: { levelId: number }) => ({
    levelId: clampInt(input.levelId, 1, LEVELS.length),
  }))
  .handler(async ({ data }): Promise<BoardRow[]> => {
    const sql = await getSql();
    const rows = await sql<{
      user_id: string;
      name: string | null;
      email: string | null;
      best_ms: number;
      score: number;
    }>`
      select t.user_id, u.name, u.email, t.best_ms, t.score
      from campaign_times t
      left join "user" u on u.id = t.user_id
      where t.level_id = ${data.levelId}
      order by t.best_ms asc, t.score desc
      limit 25
    `;
    return rows.map((row, i) => ({
      rank: i + 1,
      userId: row.user_id,
      name: displayName(row.name, row.email),
      value: row.best_ms,
      score: row.score,
      mine: false,
    }));
  });

export const listInfiniteBoard = createServerFn({ method: "GET" }).handler(
  async (): Promise<BoardRow[]> => {
    const sql = await getSql();
    const rows = await sql<{
      user_id: string;
      name: string | null;
      email: string | null;
      best_wave: number;
      best_score: number;
    }>`
      select s.user_id, u.name, u.email, s.best_wave, s.best_score
      from infinite_scores s
      left join "user" u on u.id = s.user_id
      order by s.best_wave desc, s.best_score desc
      limit 25
    `;
    return rows.map((row, i) => ({
      rank: i + 1,
      userId: row.user_id,
      name: displayName(row.name, row.email),
      value: row.best_wave,
      score: row.best_score,
      mine: false,
    }));
  },
);
