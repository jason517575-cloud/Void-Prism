import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import {
  AudioLines,
  Crosshair,
  Dices,
  Flame,
  Gem,
  Hexagon,
  Lock,
  Mountain,
  Pause,
  Play,
  Shield,
  ShoppingBag,
  Snowflake,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { FriendsScreen } from "@/components/friends";
import { LibraryScreen, WorkshopScreen } from "@/components/workshop";
import { cn } from "@/lib/cn";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  GACHA_COST,
  GACHA_DUP_REFUND,
  KIND_LABEL,
  LASER_SKINS,
  LEVELS,
  MATCH,
  ROCK_PACKS,
  SKINS,
  WEAPON_LABEL,
  WEAPON_ORDER,
  formatTime,
  laserById,
  livePalette,
  packById,
  rollGacha,
  skinById,
} from "@/game/config";
import { createGame, type GameHandle } from "@/game/game";
import { loadSave, mergeSaves, writeSave, type SaveData } from "@/game/save";
import { applyMix, playTitleMusic, sfxUi, unlockAudio } from "@/game/audio";
import {
  getProgress,
  listCampaignBoard,
  listInfiniteBoard,
  saveProgress,
  submitCampaignTime,
  submitInfiniteWave,
  type BoardRow,
} from "@/lib/progress";
import { getSeason, resetSeason } from "@/lib/community";
import type { CustomLevelDef } from "@/game/custom-level";
import type { GachaPrize, LivePalette } from "@/game/cosmetics";
import type { AsteroidKind, HudSnap, PlayMode, SkinId, WeaponId } from "@/game/types";

type View =
  | "boot"
  | "title"
  | "howto"
  | "campaign"
  | "shop"
  | "boards"
  | "maker"
  | "library"
  | "friends"
  | "secret"
  | "play";
type Overlay = "none" | "paused" | "clear" | "over" | "victory";

const WEAPON_ICON = {
  kinetic: Crosshair,
  cryo: Snowflake,
  resonant: AudioLines,
  thermal: Flame,
} as const;

const KIND_ICON = {
  basalt: Mountain,
  rime: Snowflake,
  quartz: Gem,
  alloy: Hexagon,
} as const;

function boot() {
  try {
    unlockAudio();
    sfxUi();
  } catch {
    /* audio is optional */
  }
}

function persistCloud(save: SaveData, signedIn: boolean) {
  if (!signedIn) return;
  void saveProgress({
    data: {
      campaignReached: save.campaignReached,
      campaignBest: save.campaignBest,
      infiniteBest: save.infiniteBest,
      infiniteBestWave: save.infiniteBestWave,
      fragments: save.fragments,
      ownedSkins: save.ownedSkins,
      equippedSkin: save.equippedSkin,
      ownedLasers: save.ownedLasers,
      equippedLaser: save.equippedLaser,
      ownedPacks: save.ownedPacks,
      equippedPack: save.equippedPack,
    },
  }).catch(() => {});
}

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<GameHandle | null>(null);
  const signedInRef = useRef(false);
  const titleTaps = useRef(0);
  const startTries = useRef(0);
  const { user, isPending } = useCurrentUserState();
  const signedIn = Boolean(user);
  signedInRef.current = signedIn;
  const [view, setView] = useState<View>("boot");
  const [overlay, setOverlay] = useState<Overlay>("none");
  const [playMode, setPlayMode] = useState<Exclude<PlayMode, "attract">>("campaign");
  const [levelIndex, setLevelIndex] = useState(0);
  const [session, setSession] = useState(0);
  const [customLevel, setCustomLevel] = useState<CustomLevelDef | null>(null);
  const [customEarn, setCustomEarn] = useState(true);
  const [hud, setHud] = useState<HudSnap | null>(null);
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const [lastScore, setLastScore] = useState(0);
  const [lastTimeMs, setLastTimeMs] = useState(0);
  const [mounted, setMounted] = useState(false);
  const [secretNote, setSecretNote] = useState("");
  const [confirmReset, setConfirmReset] = useState(false);

  useLayoutEffect(() => {
    try {
      if (sessionStorage.getItem("vp-entered") === "1") {
        setView((cur) => (cur === "boot" ? "title" : cur));
      }
    } catch {
      /* private mode */
    }
  }, []);

  useEffect(() => {
    setMounted(true);
    const next = loadSave();
    setSave(next);
    applyMix({ muted: next.muted, musicVol: next.musicVol, sfxVol: next.sfxVol });
    const onVis = () => {
      if (document.visibilityState === "visible") unlockAudio();
    };
    document.addEventListener("visibilitychange", onVis);
    let cancel = false;
    void getSeason()
      .then((season) => {
        if (cancel) return;
        const local = loadSave();
        if (season.n > local.season) {
          setSave(writeSave({ fragments: 0, season: season.n }));
        }
      })
      .catch(() => {});
    return () => {
      cancel = true;
      document.removeEventListener("visibilitychange", onVis);
    };
  }, []);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    void (async () => {
      try {
        const season = await getSeason();
        if (cancelled) return;
        let local = loadSave();
        const seasonBump = season.n > local.season;
        if (seasonBump) local = writeSave({ fragments: 0, season: season.n });
        const remote = await getProgress();
        if (cancelled) return;
        let merged = mergeSaves(local, {
          ...local,
          campaignReached: remote.campaignReached,
          campaignBest: remote.campaignBest,
          infiniteBest: remote.infiniteBest,
          infiniteBestWave: remote.infiniteBestWave,
          fragments: seasonBump ? 0 : remote.fragments,
          ownedSkins: remote.ownedSkins,
          equippedSkin: remote.equippedSkin,
          ownedLasers: remote.ownedLasers,
          equippedLaser: remote.equippedLaser,
          ownedPacks: remote.ownedPacks,
          equippedPack: remote.equippedPack,
          campaignTimes: remote.campaignTimes,
        });
        if (seasonBump) merged = writeSave({ ...merged, fragments: 0, season: season.n });
        else writeSave(merged);
        setSave(merged);
        persistCloud(merged, true);
        for (const [id, ms] of Object.entries(merged.campaignTimes)) {
          void submitCampaignTime({
            data: { levelId: Number(id), timeMs: ms, score: merged.campaignBest },
          }).catch(() => {});
        }
        if (merged.infiniteBestWave > 0) {
          void submitInfiniteWave({
            data: { wave: merged.infiniteBestWave, score: merged.infiniteBest },
          }).catch(() => {});
        }
      } catch {
        /* signed out / first visit */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  const canvasKey =
    view === "boot"
      ? "boot"
      : view === "play"
        ? `play-${playMode}-${levelIndex}-${customLevel?.name ?? ""}-${customEarn ? 1 : 0}-${save.godMode ? 1 : 0}-${session}`
        : `attract-${save.equippedSkin}-${save.equippedLaser}-${save.equippedPack}`;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !mounted || view === "boot") return;
    let dead = false;
    const mode: PlayMode = view === "play" ? playMode : "attract";
    let game: GameHandle | null = null;
    try {
      game = createGame(canvas, {
      mode,
      levelIndex,
      campaignReached: Math.max(save.campaignReached, playMode === "infinite" ? 5 : 1),
      shakeEnabled: save.shake,
      muted: save.muted,
      skinId: save.equippedSkin,
      laserId: save.equippedLaser,
      packId: save.equippedPack,
      timeScale: save.timeScale,
      custom: mode === "custom" ? customLevel : null,
      customEarn: mode !== "custom",
      godMode: save.godMode,
      onHud: (snap) => {
        if (!dead) setHud(snap);
      },
      onLevelClear: (score, timeMs) => {
        if (dead) return;
        setLastScore(score);
        setLastTimeMs(timeMs);
        setOverlay("clear");
        const cur = loadSave();
        const levelId = LEVELS[levelIndex]?.id ?? 1;
        const prevTime = cur.campaignTimes[levelId];
        const times = {
          ...cur.campaignTimes,
          [levelId]: prevTime ? Math.min(prevTime, timeMs) : timeMs,
        };
        const next = writeSave({
          campaignReached: Math.min(LEVELS.length + 1, Math.max(cur.campaignReached, levelId + 1)),
          campaignBest: Math.max(cur.campaignBest, score),
          campaignTimes: times,
        });
        setSave(next);
        persistCloud(next, signedInRef.current);
        if (signedInRef.current) {
          void submitCampaignTime({ data: { levelId, timeMs, score } }).catch(() => {});
        }
      },
      onCustomClear: (score, timeMs) => {
        if (dead) return;
        setLastScore(score);
        setLastTimeMs(timeMs);
        setOverlay("clear");
      },
      onGameOver: (score, wave) => {
        if (dead) return;
        setLastScore(score);
        setOverlay("over");
        const cur = loadSave();
        if (playMode === "infinite") {
          const next = writeSave({
            infiniteBest: Math.max(cur.infiniteBest, score),
            infiniteBestWave: Math.max(cur.infiniteBestWave, wave),
          });
          setSave(next);
          persistCloud(next, signedInRef.current);
          if (signedInRef.current) {
            void submitInfiniteWave({ data: { wave, score } }).catch(() => {});
          }
        } else if (playMode === "campaign") {
          const next = writeSave({ campaignBest: Math.max(cur.campaignBest, score) });
          setSave(next);
          persistCloud(next, signedInRef.current);
        }
      },
      onVictory: (score, timeMs) => {
        if (dead) return;
        setLastScore(score);
        setLastTimeMs(timeMs);
        setOverlay("victory");
        const cur = loadSave();
        const levelId = LEVELS[levelIndex]?.id ?? LEVELS.length;
        const prevTime = cur.campaignTimes[levelId];
        const times = {
          ...cur.campaignTimes,
          [levelId]: prevTime ? Math.min(prevTime, timeMs) : timeMs,
        };
        const next = writeSave({
          campaignReached: LEVELS.length + 1,
          campaignBest: Math.max(cur.campaignBest, score),
          campaignTimes: times,
        });
        setSave(next);
        persistCloud(next, signedInRef.current);
        if (signedInRef.current) {
          void submitCampaignTime({ data: { levelId, timeMs, score } }).catch(() => {});
        }
      },
      onWave: () => {},
      onFragments: (delta) => {
        if (dead || mode === "custom") return;
        const cur = loadSave();
        const next = writeSave({ fragments: cur.fragments + delta });
        setSave(next);
        persistCloud(next, signedInRef.current);
      },
      onPause: () => {
        if (dead || view !== "play") return;
        const handle = game;
        if (!handle) return;
        setOverlay((cur) => {
          if (cur === "none") {
            handle.pause();
            return "paused";
          }
          if (cur === "paused") {
            handle.resume();
            return "none";
          }
          return cur;
        });
      },
    });
    } catch {
      return;
    }
    if (!game) return;
    gameRef.current = game;
    try {
      game.start();
    } catch {
      game.destroy();
      gameRef.current = null;
      return;
    }
    return () => {
      dead = true;
      game.destroy();
      if (gameRef.current === game) gameRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvasKey, mounted]);

  useEffect(() => {
    if (view === "title" && mounted) playTitleMusic();
  }, [view, mounted]);

  useEffect(() => {
    if (view !== "play") {
      startTries.current = 0;
      return;
    }
    const timer = window.setTimeout(() => {
      if (gameRef.current) return;
      if (startTries.current >= 2) return;
      startTries.current += 1;
      setSession((s) => s + 1);
    }, 700);
    return () => window.clearTimeout(timer);
  }, [canvasKey, view]);

  const enterHangar = () => {
    try {
      sessionStorage.setItem("vp-entered", "1");
    } catch {
      /* private mode */
    }
    boot();
    setView("title");
  };

  const goTitle = () => {
    boot();
    setOverlay("none");
    setConfirmReset(false);
    setCustomLevel(null);
    setCustomEarn(false);
    setPlayMode("campaign");
    setView("title");
    playTitleMusic();
  };

  const startCampaign = (index: number) => {
    boot();
    setPlayMode("campaign");
    setLevelIndex(index);
    setCustomLevel(null);
    setHud(null);
    setSession((s) => s + 1);
    setOverlay("none");
    setView("play");
  };

  const startInfinite = () => {
    boot();
    setPlayMode("infinite");
    setLevelIndex(0);
    setCustomLevel(null);
    setHud(null);
    setSession((s) => s + 1);
    setOverlay("none");
    setView("play");
  };

  const startCustom = (def: CustomLevelDef) => {
    boot();
    setPlayMode("custom");
    setCustomLevel(def);
    setCustomEarn(false);
    setHud(null);
    setSession((s) => s + 1);
    setOverlay("none");
    setView("play");
  };

  const retry = () => {
    boot();
    setOverlay("none");
    setHud(null);
    setSession((s) => s + 1);
  };

  const continueCampaign = () => {
    boot();
    const next = levelIndex + 1;
    if (next >= LEVELS.length) {
      setOverlay("victory");
      return;
    }
    setLevelIndex(next);
    setOverlay("none");
    setSession((s) => s + 1);
  };

  const toggleMute = () => {
    const next = !save.muted;
    applyMix({ muted: next });
    setSave(writeSave({ muted: next }));
  };

  const setMusic = (musicVol: number) => {
    const muted = save.muted && musicVol === 0 && save.sfxVol === 0;
    applyMix({ musicVol, muted });
    setSave(writeSave({ musicVol, muted }));
  };

  const setSfx = (sfxVol: number) => {
    const muted = save.muted && sfxVol === 0 && save.musicVol === 0;
    applyMix({ sfxVol, muted });
    setSave(writeSave({ sfxVol, muted }));
  };

  const toggleShake = () => setSave(writeSave({ shake: !save.shake }));

  const setSpeed = (timeScale: 1 | 2) => {
    gameRef.current?.setTimeScale(timeScale);
    setSave(writeSave({ timeScale }));
  };

  const pullGacha = (): GachaPrize | null => {
    boot();
    const cur = loadSave();
    if (cur.fragments < GACHA_COST) return null;
    const prize = rollGacha({
      wells: cur.ownedSkins,
      lasers: cur.ownedLasers,
      packs: cur.ownedPacks,
    });
    let fragments = cur.fragments - GACHA_COST;
    const patch: Partial<SaveData> = {};
    if (prize.duplicate) fragments += GACHA_DUP_REFUND;
    else if (prize.kind === "well") {
      patch.ownedSkins = [...cur.ownedSkins, prize.id];
      patch.equippedSkin = prize.id;
    } else if (prize.kind === "laser") {
      patch.ownedLasers = [...cur.ownedLasers, prize.id];
      patch.equippedLaser = prize.id;
    } else {
      patch.ownedPacks = [...cur.ownedPacks, prize.id];
      patch.equippedPack = prize.id;
    }
    patch.fragments = fragments;
    const next = writeSave(patch);
    setSave(next);
    persistCloud(next, signedIn);
    return prize;
  };

  const pauseGame = () => {
    if (overlay !== "none") return;
    gameRef.current?.pause();
    setOverlay("paused");
  };

  const resumeGame = () => {
    gameRef.current?.resume();
    setOverlay("none");
  };

  const onTitleTap = () => {
    titleTaps.current += 1;
    if (titleTaps.current >= 75) {
      titleTaps.current = 0;
      setSecretNote("");
      setConfirmReset(false);
      setView("secret");
    }
  };

  const runSeasonReset = async () => {
    if (!confirmReset) {
      setConfirmReset(true);
      setSecretNote("Tap reset again. This clears every pilot's fragments and every public level.");
      return;
    }
    setConfirmReset(false);
    try {
      const res = await resetSeason();
      const next = writeSave({ fragments: 0, season: res.season });
      setSave(next);
      persistCloud(next, signedInRef.current);
      setSecretNote("Season reset. Fragments are zero and the public library is empty.");
    } catch {
      const next = writeSave({ fragments: 0 });
      setSave(next);
      setSecretNote("Your fragments were cleared. Sign in to reset everyone and delete public levels.");
    }
  };

  return (
    <main className="relative h-dvh max-h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full touch-none"
        aria-label="VOID PRISM playfield"
      />
      {view !== "play" && (
        <div className={cn("absolute inset-0", view === "boot" ? "bg-bg" : "bg-bg/55")} />
      )}
      {view === "boot" && <BootScreen onEnter={enterHangar} />}
      {view === "title" && (
        <TitleScreen
          save={save}
          isPending={isPending}
          signedIn={signedIn}
          onCampaign={() => {
            boot();
            setView("campaign");
          }}
          onInfinite={startInfinite}
          onHowTo={() => {
            boot();
            setView("howto");
          }}
          onShop={() => {
            boot();
            setView("shop");
          }}
          onBoards={() => {
            boot();
            setView("boards");
          }}
          onMaker={() => {
            boot();
            setView("maker");
          }}
          onLibrary={() => {
            boot();
            setView("library");
          }}
          onFriends={() => {
            boot();
            setView("friends");
          }}
          onTitle={onTitleTap}
          muted={save.muted}
          musicVol={save.musicVol}
          sfxVol={save.sfxVol}
          onMute={toggleMute}
          onMusic={setMusic}
          onSfx={setSfx}
        />
      )}
      {view === "howto" && (
        <HowToScreen onBack={goTitle} palette={livePalette(save.equippedLaser, save.equippedPack)} />
      )}
      {view === "campaign" && (
        <CampaignScreen
          reached={save.campaignReached}
          times={save.campaignTimes}
          palette={livePalette(save.equippedLaser, save.equippedPack)}
          onBack={goTitle}
          onPick={startCampaign}
        />
      )}
      {view === "shop" && (
        <ShopScreen
          save={save}
          onBack={goTitle}
          onGacha={pullGacha}
          onBuyWell={(id) => {
            boot();
            const cur = loadSave();
            const def = skinById(id);
            if (cur.ownedSkins.includes(id)) {
              const next = writeSave({ equippedSkin: id });
              setSave(next);
              persistCloud(next, signedIn);
              return;
            }
            if (cur.fragments < def.cost) return;
            const next = writeSave({
              fragments: cur.fragments - def.cost,
              ownedSkins: [...cur.ownedSkins, id],
              equippedSkin: id,
            });
            setSave(next);
            persistCloud(next, signedIn);
          }}
          onBuyLaser={(id) => {
            boot();
            const cur = loadSave();
            const def = laserById(id);
            if (cur.ownedLasers.includes(id)) {
              const next = writeSave({ equippedLaser: id });
              setSave(next);
              persistCloud(next, signedIn);
              return;
            }
            if (cur.fragments < def.cost) return;
            const next = writeSave({
              fragments: cur.fragments - def.cost,
              ownedLasers: [...cur.ownedLasers, id],
              equippedLaser: id,
            });
            setSave(next);
            persistCloud(next, signedIn);
          }}
          onBuyPack={(id) => {
            boot();
            const cur = loadSave();
            const def = packById(id);
            if (cur.ownedPacks.includes(id)) {
              const next = writeSave({ equippedPack: id });
              setSave(next);
              persistCloud(next, signedIn);
              return;
            }
            if (cur.fragments < def.cost) return;
            const next = writeSave({
              fragments: cur.fragments - def.cost,
              ownedPacks: [...cur.ownedPacks, id],
              equippedPack: id,
            });
            setSave(next);
            persistCloud(next, signedIn);
          }}
        />
      )}
      {view === "boards" && <BoardsScreen userId={user?.id ?? null} onBack={goTitle} />}
      {view === "maker" && (
        <WorkshopScreen signedIn={signedIn} onBack={goTitle} onPlay={(def) => startCustom(def)} />
      )}
      {view === "library" && <LibraryScreen onBack={goTitle} onPlay={(def) => startCustom(def)} />}
      {view === "friends" && <FriendsScreen signedIn={signedIn} onBack={goTitle} />}
      {view === "secret" && (
        <SecretScreen
          god={save.godMode}
          note={secretNote}
          confirm={confirmReset}
          onGod={() => setSave(writeSave({ godMode: !save.godMode }))}
          onReset={() => void runSeasonReset()}
          onExit={goTitle}
        />
      )}
      {view === "play" && !hud && overlay === "none" && (
        <p className="pointer-events-none absolute inset-0 z-10 grid place-items-center font-mono text-xs uppercase tracking-[0.22em] text-muted">
          Starting
        </p>
      )}
      {view === "play" && hud && (
        <PlayHud
          hud={hud}
          overlay={overlay}
          muted={save.muted}
          fragments={save.fragments}
          god={save.godMode}
          palette={livePalette(save.equippedLaser, save.equippedPack)}
          onPause={pauseGame}
          onMute={toggleMute}
          onWeapon={(w) => gameRef.current?.setWeapon(w)}
        />
      )}
      {view === "play" && overlay === "paused" && (
        <CenterPanel kicker="Paused" title={hud?.levelName ?? "VOID PRISM"} body="Resume, restart, or return to the hangar.">
          <VolumeMixer music={save.musicVol} sfx={save.sfxVol} onMusic={setMusic} onSfx={setSfx} />
          <div className="grid grid-cols-2 gap-2">
            <Button variant={save.timeScale === 1 ? "primary" : "outline"} onClick={() => setSpeed(1)}>
              1× speed
            </Button>
            <Button variant={save.timeScale === 2 ? "primary" : "outline"} onClick={() => setSpeed(2)}>
              2× speed
            </Button>
          </div>
          <Button onClick={resumeGame}>
            <Play className="size-4" />
            Resume
          </Button>
          <Button variant="outline" onClick={retry}>
            Restart
          </Button>
          <Button variant="outline" onClick={toggleShake}>
            Shake {save.shake ? "on" : "off"}
          </Button>
          <Button variant="ghost" onClick={goTitle}>
            Hangar
          </Button>
        </CenterPanel>
      )}
      {view === "play" && overlay === "clear" && (
        <CenterPanel
          kicker={playMode === "custom" ? "Belt clear" : `Sector ${levelIndex + 1} clear`}
          title={playMode === "custom" ? (customLevel?.name ?? "Clear") : (LEVELS[levelIndex]?.name ?? "Clear")}
          body={
            playMode === "custom"
              ? `Score ${lastScore.toLocaleString()} · ${formatTime(lastTimeMs)}. Player-made belts pay no fragments.`
              : `Score ${lastScore.toLocaleString()} · ${formatTime(lastTimeMs)}. Fragments banked.`
          }
        >
          {playMode === "custom" ? (
            <Button onClick={retry}>Replay</Button>
          ) : (
            <Button onClick={continueCampaign}>Continue</Button>
          )}
          <Button variant="ghost" onClick={goTitle}>
            Hangar
          </Button>
        </CenterPanel>
      )}
      {view === "play" && overlay === "over" && (
        <CenterPanel
          kicker="Well breached"
          title="Game over"
          body={
            playMode === "infinite"
              ? `Wave ${hud?.wave ?? 1} · Score ${lastScore.toLocaleString()}`
              : `Score ${lastScore.toLocaleString()}`
          }
        >
          <Button onClick={retry}>Retry</Button>
          <Button variant="ghost" onClick={goTitle}>
            Hangar
          </Button>
        </CenterPanel>
      )}
      {view === "play" && overlay === "victory" && (
        <CenterPanel
          kicker="Campaign"
          title="The belt is clear"
          body={`Final score ${lastScore.toLocaleString()} · ${formatTime(lastTimeMs)}. Infinite Drift is waiting.`}
        >
          <Button onClick={startInfinite}>Infinite Drift</Button>
          <Button variant="ghost" onClick={goTitle}>
            Hangar
          </Button>
        </CenterPanel>
      )}
    </main>
  );
}

function BootScreen({ onEnter }: { onEnter: () => void }) {
  return (
    <button
      type="button"
      onClick={onEnter}
      className="relative z-10 flex h-full w-full flex-col items-center justify-center px-6 text-center"
    >
      <p className="font-mono text-xs uppercase tracking-[0.32em] text-subtle">Spectral intercept</p>
      <h1 className="mt-4 font-display text-4xl font-semibold tracking-[-0.04em] sm:text-5xl">VOID PRISM</h1>
      <p className="mt-6 font-mono text-xs uppercase tracking-[0.22em] text-muted">Tap to enter</p>
    </button>
  );
}

function AuthSlot({ isPending, signedIn }: { isPending: boolean; signedIn: boolean }) {
  if (isPending) return <div className="h-8 w-28 animate-pulse rounded-full bg-bg-subtle" />;
  if (signedIn) return <UserButton />;
  return (
    <Link to="/login" className="font-mono text-xs uppercase tracking-[0.18em] text-muted hover:text-fg">
      Sign in
    </Link>
  );
}

function TitleScreen({
  save,
  isPending,
  signedIn,
  onCampaign,
  onInfinite,
  onHowTo,
  onShop,
  onBoards,
  onMaker,
  onLibrary,
  onFriends,
  onTitle,
  muted,
  musicVol,
  sfxVol,
  onMute,
  onMusic,
  onSfx,
}: {
  save: SaveData;
  isPending: boolean;
  signedIn: boolean;
  onCampaign: () => void;
  onInfinite: () => void;
  onHowTo: () => void;
  onShop: () => void;
  onBoards: () => void;
  onMaker: () => void;
  onLibrary: () => void;
  onFriends: () => void;
  onTitle: () => void;
  muted: boolean;
  musicVol: number;
  sfxVol: number;
  onMute: () => void;
  onMusic: (v: number) => void;
  onSfx: (v: number) => void;
}) {
  return (
    <section className="relative z-10 flex h-full flex-col overflow-y-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <header className="flex items-center justify-between gap-3">
        <p className="font-mono text-xs uppercase tracking-[0.28em] text-muted">Hangar</p>
        <div className="flex items-center gap-2">
          <AuthSlot isPending={isPending} signedIn={signedIn} />
          <button
            type="button"
            onClick={onMute}
            className="flex size-10 items-center justify-center rounded-[var(--radius-sm)] text-muted hover:text-fg"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
          </button>
        </div>
      </header>
      <div className="mx-auto mt-6 w-full max-w-md flex-1">
        <h1 className="font-display text-3xl font-semibold leading-tight tracking-[-0.04em] sm:text-4xl">
          <button type="button" onClick={onTitle} className="text-left">
            VOID PRISM
          </button>
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          Match the laser to the rock. Three charges. Spend fragments in the shop.
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <Button size="lg" className="w-full" onClick={onCampaign}>
            Campaign
          </Button>
          <Button size="lg" variant="outline" className="w-full" onClick={onInfinite}>
            Infinite
          </Button>
          <Button size="md" variant="outline" className="w-full" onClick={onShop}>
            <ShoppingBag className="size-4" />
            Shop
          </Button>
          <Button size="md" variant="outline" className="w-full" onClick={onBoards}>
            <Trophy className="size-4" />
            Boards
          </Button>
          <Button size="md" variant="outline" className="w-full" onClick={onMaker}>
            Workshop
          </Button>
          <Button size="md" variant="outline" className="w-full" onClick={onLibrary}>
            Library
          </Button>
          <Button size="md" variant="outline" className="w-full" onClick={onFriends}>
            Friends
          </Button>
        </div>
        <Button size="md" variant="ghost" className="mt-2 w-full" onClick={onHowTo}>
          How to play
        </Button>
        <div className="mt-4">
          <VolumeMixer music={musicVol} sfx={sfxVol} onMusic={onMusic} onSfx={onSfx} />
        </div>
      </div>
      <footer className="mx-auto mt-4 flex w-full max-w-md flex-wrap gap-x-6 gap-y-1 font-mono text-xs uppercase tracking-[0.16em] text-subtle">
        <span>Frag {save.fragments.toLocaleString()}</span>
        <span>Best {save.campaignBest.toLocaleString()}</span>
        <span>Wave {save.infiniteBestWave.toLocaleString()}</span>
      </footer>
    </section>
  );
}

function SecretScreen({
  god,
  note,
  confirm,
  onGod,
  onReset,
  onExit,
}: {
  god: boolean;
  note: string;
  confirm: boolean;
  onGod: () => void;
  onReset: () => void;
  onExit: () => void;
}) {
  return (
    <section className="relative z-10 flex h-full flex-col items-start overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <p className="font-mono text-xs uppercase tracking-[0.28em] text-subtle">Restricted</p>
      <h2 className="mt-4 font-display text-3xl font-semibold tracking-tight">Season bay</h2>
      <p className="mt-2 max-w-md text-sm text-muted">
        God mode ignores well hits. Reset season zeroes every pilot's fragments and deletes every public level.
      </p>
      <div className="mt-6 flex w-full max-w-sm flex-col gap-2">
        <Button variant={god ? "primary" : "outline"} onClick={onGod}>
          God mode {god ? "on" : "off"}
        </Button>
        <Button variant="danger" onClick={onReset}>
          {confirm ? "Confirm season reset" : "Reset season"}
        </Button>
        <Button variant="ghost" onClick={onExit}>
          Exit
        </Button>
      </div>
      {note && <p className="mt-4 max-w-md text-sm text-muted">{note}</p>}
    </section>
  );
}

function HowToScreen({ onBack, palette }: { onBack: () => void; palette: LivePalette }) {
  const rows: AsteroidKind[] = ["basalt", "rime", "quartz", "alloy"];
  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg">
        Back
      </button>
      <h2 className="mt-8 font-display text-2xl font-semibold tracking-[-0.03em]">How to play</h2>
      <p className="mt-3 max-w-lg leading-relaxed text-muted">
        Click matching asteroids inside the dashed range. Three well charges — a hit without a shield costs one, and the last ends the run. Gold lucky meteors yield to any laser and drop gear. Belts made by players, including public ones, pay no fragments.
      </p>
      <ul className="mt-8 max-w-lg divide-y divide-border border-y border-border">
        {rows.map((kind) => {
          const weapon = MATCH[kind];
          const KindIcon = KIND_ICON[kind];
          const WepIcon = WEAPON_ICON[weapon];
          return (
            <li key={kind} className="flex items-center justify-between gap-4 py-4">
              <span className="flex items-center gap-3" style={{ color: palette.kind[kind] }}>
                <KindIcon className="size-5" />
                <span className="font-medium text-fg">{KIND_LABEL[kind]}</span>
              </span>
              <span className="font-mono text-xs uppercase tracking-[0.18em] text-subtle">yields to</span>
              <span className="flex items-center gap-3" style={{ color: palette.weapon[weapon] }}>
                <span className="font-medium text-fg">{WEAPON_LABEL[weapon]}</span>
                <WepIcon className="size-5" />
              </span>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function ShopScreen({
  save,
  onBack,
  onBuyWell,
  onBuyLaser,
  onBuyPack,
  onGacha,
}: {
  save: SaveData;
  onBack: () => void;
  onBuyWell: (id: SkinId) => void;
  onBuyLaser: (id: string) => void;
  onBuyPack: (id: string) => void;
  onGacha: () => GachaPrize | null;
}) {
  const [tab, setTab] = useState<"well" | "laser" | "rocks">("rocks");
  const [roll, setRoll] = useState<GachaPrize | null>(null);
  const canPull = save.fragments >= GACHA_COST;
  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg">
        Back
      </button>
      <h2 className="mt-6 font-display text-2xl font-semibold tracking-[-0.03em]">Shop</h2>
      <p className="mt-2 max-w-lg text-sm text-muted">
        Fragments {save.fragments.toLocaleString()}. Rock packs recolor the belt and matching lasers. Vault is {GACHA_COST} a pull — cheap skins common, rare ones scarce.
      </p>
      <div className="mt-5 w-full max-w-3xl rounded-[var(--radius-lg)] border border-border bg-bg-elevated p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="flex items-center gap-2 font-display text-base font-medium">
              <Dices className="size-4" />
              Vault
            </p>
            <p className="mt-1 text-xs text-muted">
              {roll
                ? roll.duplicate
                  ? `Duplicate ${roll.name}. +${GACHA_DUP_REFUND} frag back.`
                  : `Pulled ${roll.name} (${roll.kind}). Equipped.`
                : "One random well, laser, or rock pack."}
            </p>
          </div>
          <Button
            size="sm"
            disabled={!canPull}
            onClick={() => {
              const prize = onGacha();
              if (prize) setRoll(prize);
            }}
          >
            Pull · {GACHA_COST}
          </Button>
        </div>
      </div>
      <div className="mt-5 flex flex-wrap gap-2">
        {(
          [
            ["rocks", "Rock packs"],
            ["laser", "Lasers"],
            ["well", "Well"],
          ] as const
        ).map(([id, label]) => (
          <Button key={id} size="sm" variant={tab === id ? "primary" : "outline"} onClick={() => setTab(id)}>
            {label}
          </Button>
        ))}
      </div>
      {tab === "well" && (
        <ul className="mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {SKINS.map((skin) => {
            const owned = save.ownedSkins.includes(skin.id);
            const equipped = save.equippedSkin === skin.id;
            const locked = !owned && save.fragments < skin.cost;
            return (
              <li key={skin.id}>
                <button
                  type="button"
                  disabled={locked}
                  onClick={() => onBuyWell(skin.id)}
                  className={cn(
                    "flex w-full items-center gap-4 rounded-[var(--radius-lg)] border bg-bg-elevated px-4 py-4 text-left",
                    equipped ? "border-accent" : "border-border hover:border-border-strong",
                    locked && "opacity-40",
                  )}
                >
                  <span className="size-8 shrink-0 rounded-full border border-border" style={{ background: skin.core }} />
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-base font-medium tracking-tight">{skin.name}</span>
                    <span className="mt-1 block text-xs text-muted">{skin.blurb}</span>
                  </span>
                  <span className="font-mono text-xs uppercase tracking-[0.14em] text-subtle">
                    {equipped ? "On" : owned ? "Equip" : `${skin.cost} frag`}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      {tab === "laser" && (
        <ul className="mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {LASER_SKINS.map((skin) => {
            const owned = save.ownedLasers.includes(skin.id);
            const equipped = save.equippedLaser === skin.id;
            const locked = !owned && save.fragments < skin.cost;
            const colors = livePalette(skin.id, save.equippedPack).weapon;
            return (
              <li key={skin.id}>
                <button
                  type="button"
                  disabled={locked}
                  onClick={() => onBuyLaser(skin.id)}
                  className={cn(
                    "flex w-full items-center gap-4 rounded-[var(--radius-lg)] border bg-bg-elevated px-4 py-4 text-left",
                    equipped ? "border-accent" : "border-border hover:border-border-strong",
                    locked && "opacity-40",
                  )}
                >
                  <span className="flex gap-1">
                    {WEAPON_ORDER.map((w) => (
                      <span key={w} className="size-2.5 rounded-full border border-border" style={{ background: colors[w] }} />
                    ))}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-base font-medium tracking-tight">{skin.name}</span>
                    <span className="mt-1 block text-xs text-muted">
                      {skin.blurb} · {skin.style}
                    </span>
                  </span>
                  <span className="font-mono text-xs uppercase tracking-[0.14em] text-subtle">
                    {equipped ? "On" : owned ? "Equip" : `${skin.cost} frag`}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      {tab === "rocks" && (
        <ul className="mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {ROCK_PACKS.map((pack) => {
            const owned = save.ownedPacks.includes(pack.id);
            const equipped = save.equippedPack === pack.id;
            const locked = !owned && save.fragments < pack.cost;
            return (
              <li key={pack.id}>
                <button
                  type="button"
                  disabled={locked}
                  onClick={() => onBuyPack(pack.id)}
                  className={cn(
                    "flex w-full items-center gap-4 rounded-[var(--radius-lg)] border bg-bg-elevated px-4 py-4 text-left",
                    equipped ? "border-accent" : "border-border hover:border-border-strong",
                    locked && "opacity-40",
                  )}
                >
                  <span className="flex gap-1">
                    {(["basalt", "rime", "quartz", "alloy"] as const).map((k) => (
                      <span key={k} className="size-2.5 rounded-full border border-border" style={{ background: pack.colors[k] }} />
                    ))}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-display text-base font-medium tracking-tight">{pack.name}</span>
                    <span className="mt-1 block text-xs text-muted">{pack.blurb}</span>
                  </span>
                  <span className="font-mono text-xs uppercase tracking-[0.14em] text-subtle">
                    {equipped ? "On" : owned ? "Equip" : `${pack.cost} frag`}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function CampaignScreen({
  reached,
  times,
  palette,
  onBack,
  onPick,
}: {
  reached: number;
  times: Record<number, number>;
  palette: LivePalette;
  onBack: () => void;
  onPick: (index: number) => void;
}) {
  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg">
        Back
      </button>
      <h2 className="mt-8 font-display text-2xl font-semibold tracking-[-0.03em]">Campaign</h2>
      <p className="mt-3 max-w-lg text-muted">
        Fifty sectors. Later belts drift faster and pay more. Clear times post when you are signed in.
      </p>
      <ol className="mt-8 grid w-full max-w-3xl gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {LEVELS.map((lvl, i) => {
          const locked = lvl.id > reached;
          const best = times[lvl.id];
          return (
            <li key={lvl.id}>
              <button
                type="button"
                disabled={locked}
                onClick={() => onPick(i)}
                className="flex w-full items-center gap-4 rounded-[var(--radius-lg)] border border-border bg-bg-elevated px-4 py-3 text-left hover:border-border-strong disabled:opacity-40"
              >
                <span className="font-mono text-xs tabular text-subtle">{String(lvl.id).padStart(2, "0")}</span>
                <span className="min-w-0 flex-1">
                  <span className="block font-display text-base font-medium tracking-tight">{lvl.name}</span>
                  <span className="mt-1 flex items-center gap-2">
                    <span className="flex gap-1.5">
                      {lvl.kinds.map((k) => (
                        <span key={k} className="size-1.5 rounded-full" style={{ background: palette.kind[k] }} />
                      ))}
                    </span>
                    {best ? (
                      <span className="font-mono text-[0.65rem] uppercase tracking-[0.12em] text-subtle">
                        {formatTime(best)}
                      </span>
                    ) : null}
                  </span>
                </span>
                {locked ? <Lock className="size-4 text-subtle" /> : <Play className="size-4 text-muted" />}
              </button>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

function BoardsScreen({ userId, onBack }: { userId: string | null; onBack: () => void }) {
  const [tab, setTab] = useState<"campaign" | "infinite">("campaign");
  const [levelId, setLevelId] = useState(1);
  const [rows, setRows] = useState<BoardRow[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    const job =
      tab === "campaign" ? listCampaignBoard({ data: { levelId } }) : listInfiniteBoard();
    void job
      .then((list) => {
        if (cancelled) return;
        setRows(list.map((row) => ({ ...row, mine: Boolean(userId && row.userId === userId) })));
      })
      .catch(() => {
        if (!cancelled) setRows([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [tab, levelId, userId]);
  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted hover:text-fg">
        Back
      </button>
      <h2 className="mt-8 font-display text-2xl font-semibold tracking-[-0.03em]">Boards</h2>
      <p className="mt-3 max-w-lg text-muted">
        Campaign ranks how fast a sector was cleared. Infinite ranks highest wave. Sign in to post.
      </p>
      <div className="mt-6 flex gap-2">
        <Button size="sm" variant={tab === "campaign" ? "primary" : "outline"} onClick={() => setTab("campaign")}>
          Campaign
        </Button>
        <Button size="sm" variant={tab === "infinite" ? "primary" : "outline"} onClick={() => setTab("infinite")}>
          Infinite
        </Button>
      </div>
      {tab === "campaign" && (
        <div className="mt-4 flex max-w-3xl flex-wrap gap-1.5">
          {LEVELS.map((lvl) => (
            <button
              key={lvl.id}
              type="button"
              onClick={() => setLevelId(lvl.id)}
              className={cn(
                "min-h-9 min-w-9 rounded-[var(--radius-sm)] border px-2 font-mono text-xs tabular",
                levelId === lvl.id ? "border-accent bg-bg-elevated text-fg" : "border-border text-muted hover:text-fg",
              )}
            >
              {lvl.id}
            </button>
          ))}
        </div>
      )}
      <ol className="mt-6 w-full max-w-xl divide-y divide-border border-y border-border">
        {loading && <li className="py-6 font-mono text-xs uppercase tracking-[0.18em] text-subtle">Loading</li>}
        {!loading && rows.length === 0 && (
          <li className="py-6 text-sm text-muted">No entries yet. Clear a sector or ride a wave, then sign in.</li>
        )}
        {!loading &&
          rows.map((row) => (
            <li key={`${row.userId}-${row.rank}`} className={cn("flex items-center gap-4 py-3", row.mine && "text-accent")}>
              <span className="w-8 font-mono text-xs tabular text-subtle">{String(row.rank).padStart(2, "0")}</span>
              <span className="min-w-0 flex-1 truncate font-medium">{row.name}</span>
              <span className="font-mono text-xs tabular text-muted">
                {tab === "campaign" ? formatTime(row.value) : `Wave ${row.value}`}
              </span>
            </li>
          ))}
      </ol>
    </section>
  );
}

function PlayHud({
  hud,
  overlay,
  muted,
  fragments,
  god,
  palette,
  onPause,
  onMute,
  onWeapon,
}: {
  hud: HudSnap;
  overlay: Overlay;
  muted: boolean;
  fragments: number;
  god: boolean;
  palette: LivePalette;
  onPause: () => void;
  onMute: () => void;
  onWeapon: (w: WeaponId) => void;
}) {
  const playing = overlay === "none";
  const pills: { key: string; label: string; icon: typeof Shield }[] = [];
  if (hud.aegisT > 0) pills.push({ key: "aegis", label: `Aegis ${Math.ceil(hud.aegisT)}s`, icon: Shield });
  if (hud.ward > 0) pills.push({ key: "ward", label: "Ward", icon: Shield });
  if (hud.overchargeT > 0) pills.push({ key: "oc", label: `Over ${Math.ceil(hud.overchargeT)}s`, icon: Zap });
  if (hud.fragMulT > 0) pills.push({ key: "x2", label: `2× ${Math.ceil(hud.fragMulT)}s`, icon: Sparkles });
  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-3 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-xs uppercase tracking-[0.22em] text-subtle">
            {hud.mode === "campaign" ? `Sector ${hud.levelId}` : hud.levelName}
          </p>
          <p className="mt-1 font-display text-xl font-medium tabular tracking-tight">{hud.score.toLocaleString()}</p>
          <p className="mt-1 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-subtle">
            {fragments.toLocaleString()} frag
            {hud.sessionFrags > 0 ? ` · +${hud.sessionFrags}` : ""}
          </p>
          <p className="mt-2 flex gap-1">
            {god ? (
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.16em] text-accent">God</span>
            ) : (
              Array.from({ length: Math.max(hud.lives, 0) }).map((_, i) => (
                <span key={i} className="block h-2 w-3 bg-accent" />
              ))
            )}
          </p>
        </div>
        <div className="text-center">
          <p className="font-display text-sm font-medium tracking-tight">
            {hud.mode === "infinite" ? "Infinite Drift" : hud.levelName}
          </p>
          {hud.briefingT > 0 && playing && hud.waveClearT <= 0 && (
            <p className="mt-1 max-w-[16rem] text-xs text-muted">{hud.briefing}</p>
          )}
          <p className="mt-2 font-mono text-xs uppercase tabular tracking-[0.18em] text-subtle">
            {hud.remaining} left
            {hud.combo > 1 ? ` · ×${hud.multiplier}` : ""}
            {hud.mode === "campaign" ? ` · ${formatTime(hud.playTime * 1000)}` : ""}
          </p>
          {pills.length > 0 && (
            <ul className="mt-2 flex flex-wrap justify-center gap-1.5">
              {pills.map((p) => (
                <li
                  key={p.key}
                  className="flex items-center gap-1 rounded-[var(--radius-sm)] border border-border bg-bg/70 px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-[0.12em]"
                >
                  <p.icon className="size-3" />
                  {p.label}
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="pointer-events-auto flex gap-1">
          <button
            type="button"
            onClick={onMute}
            className="flex size-11 items-center justify-center rounded-[var(--radius-sm)] text-muted hover:text-fg"
            aria-label={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
          </button>
          {playing && (
            <button
              type="button"
              onClick={onPause}
              className="flex size-11 items-center justify-center rounded-[var(--radius-sm)] text-muted hover:text-fg"
              aria-label="Pause"
            >
              <Pause className="size-5" />
            </button>
          )}
        </div>
      </div>
      {hud.waveClearT > 0 && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <p className="font-display text-2xl font-semibold tracking-[-0.03em] sm:text-3xl">Wave {hud.wave} cleared</p>
        </div>
      )}
      <div className="pointer-events-auto mx-auto flex w-full max-w-md gap-2">
        {WEAPON_ORDER.map((id) => {
          const Icon = WEAPON_ICON[id];
          const open = hud.unlocked.includes(id);
          const active = hud.weapon === id;
          return (
            <button
              key={id}
              type="button"
              disabled={!open}
              onClick={() => onWeapon(id)}
              className={cn(
                "flex min-h-11 flex-1 flex-col items-center justify-center gap-1 rounded-[var(--radius-md)] border px-1 py-1.5",
                active ? "border-accent bg-bg-elevated text-fg" : "border-border bg-bg/50 text-muted",
                !open && "opacity-30",
                hud.overchargeT > 0 && open && "border-accent",
              )}
              style={open ? { color: palette.weapon[id] } : undefined}
            >
              <Icon className="size-4" />
              <span className="font-mono text-[0.6rem] uppercase tracking-[0.14em]">{WEAPON_LABEL[id]}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function VolumeMixer({
  music,
  sfx,
  onMusic,
  onSfx,
}: {
  music: number;
  sfx: number;
  onMusic: (v: number) => void;
  onSfx: (v: number) => void;
}) {
  return (
    <div
      className="flex flex-col gap-2 rounded-[var(--radius-md)] border border-border bg-bg/70 px-3 py-2"
      onPointerDown={(e) => e.stopPropagation()}
    >
      <label className="flex items-center gap-3">
        <span className="w-14 shrink-0 font-mono text-xs uppercase tracking-[0.16em] text-subtle">Music</span>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(music * 100)}
          aria-label="Music volume"
          onChange={(e) => onMusic(Number(e.target.value) / 100)}
          className="vol"
        />
        <span className="w-8 text-right font-mono text-xs tabular text-muted">{Math.round(music * 100)}</span>
      </label>
      <label className="flex items-center gap-3">
        <span className="w-14 shrink-0 font-mono text-xs uppercase tracking-[0.16em] text-subtle">SFX</span>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(sfx * 100)}
          aria-label="SFX volume"
          onChange={(e) => onSfx(Number(e.target.value) / 100)}
          className="vol"
        />
        <span className="w-8 text-right font-mono text-xs tabular text-muted">{Math.round(sfx * 100)}</span>
      </label>
    </div>
  );
}

function CenterPanel({
  kicker,
  title,
  body,
  children,
}: {
  kicker: string;
  title: string;
  body: string;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-bg/70 px-5">
      <div
        role="dialog"
        aria-labelledby="panel-title"
        className="max-h-[min(40rem,90dvh)] w-full max-w-md overflow-auto rounded-[var(--radius-xl)] border border-border bg-bg-elevated p-6 sm:p-8"
      >
        <p className="font-mono text-xs uppercase tracking-[0.22em] text-subtle">{kicker}</p>
        <h2 id="panel-title" className="mt-3 font-display text-2xl font-semibold tracking-[-0.03em]">
          {title}
        </h2>
        <p className="mt-3 text-sm leading-relaxed text-muted">{body}</p>
        <div className="mt-6 flex flex-col gap-2">{children}</div>
      </div>
    </div>
  );
}
