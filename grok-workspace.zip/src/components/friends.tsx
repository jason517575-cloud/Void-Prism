import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import {
  claimUsername,
  getMyProfile,
  listFriends,
  listMessages,
  requestFriend,
  respondFriend,
  searchPilots,
  sendMessage,
  type ChatLine,
  type FriendRow,
} from "@/lib/community";

export function FriendsScreen({ signedIn, onBack }: { signedIn: boolean; onBack: () => void }) {
  const [username, setUsername] = useState("");
  const [draftName, setDraftName] = useState("");
  const [query, setQuery] = useState("");
  const [found, setFound] = useState<{ userId: string; username: string }[]>([]);
  const [friends, setFriends] = useState<FriendRow[]>([]);
  const [requests, setRequests] = useState<FriendRow[]>([]);
  const [chatWith, setChatWith] = useState<FriendRow | null>(null);
  const [lines, setLines] = useState<ChatLine[]>([]);
  const [text, setText] = useState("");
  const [note, setNote] = useState("");

  const refresh = async () => {
    const social = await listFriends();
    setFriends(social.friends);
    setRequests(social.requests);
  };

  useEffect(() => {
    if (!signedIn) return;
    void getMyProfile()
      .then((p) => {
        setUsername(p.username);
        setDraftName(p.username);
      })
      .catch(() => setNote("Sign in to use friends."));
    void refresh().catch(() => {});
  }, [signedIn]);

  useEffect(() => {
    if (!signedIn || !chatWith) return;
    let stop = false;
    const pull = () => {
      void listMessages({ data: { userId: chatWith.userId } })
        .then((rows) => {
          if (!stop) setLines(rows);
        })
        .catch(() => {});
    };
    pull();
    const timer = window.setInterval(pull, 4000);
    return () => {
      stop = true;
      window.clearInterval(timer);
    };
  }, [signedIn, chatWith]);

  if (!signedIn) {
    return (
      <section className="relative z-10 flex h-full flex-col px-4 pt-6">
        <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted">
          Back
        </button>
        <h2 className="mt-6 font-display text-2xl font-semibold">Friends</h2>
        <p className="mt-3 max-w-md text-sm text-muted">Sign in to claim a username, add friends, and chat.</p>
        <Button className="mt-6 w-fit" asChild>
          <Link to="/login">Sign in</Link>
        </Button>
      </section>
    );
  }

  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted">
        Back
      </button>
      <h2 className="mt-4 font-display text-2xl font-semibold tracking-tight">Friends</h2>
      <p className="mt-2 text-sm text-muted">
        {username ? `You are ${username}.` : "Claim a unique username first."} Usernames cannot be shared.
      </p>
      <form
        className="mt-4 flex max-w-md gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void claimUsername({ data: { username: draftName } }).then((res) => {
            if (!res.ok) setNote(res.error);
            else {
              setUsername(res.username);
              setNote("Username saved.");
            }
          });
        }}
      >
        <input
          value={draftName}
          onChange={(e) => setDraftName(e.target.value)}
          placeholder="username"
          className="min-w-0 flex-1 rounded-[var(--radius-sm)] border border-border bg-bg px-3 py-2 text-sm"
        />
        <Button type="submit" variant="outline">
          Save
        </Button>
      </form>

      <form
        className="mt-4 flex max-w-md gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          void searchPilots({ data: { q: query } })
            .then(setFound)
            .catch(() => setNote("Search failed."));
        }}
      >
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Find a username"
          className="min-w-0 flex-1 rounded-[var(--radius-sm)] border border-border bg-bg px-3 py-2 text-sm"
        />
        <Button type="submit" variant="outline">
          Find
        </Button>
      </form>
      {found.length > 0 && (
        <ul className="mt-3 max-w-md divide-y divide-border border-y border-border">
          {found.map((pilot) => (
            <li key={pilot.userId} className="flex items-center justify-between py-2">
              <span>{pilot.username}</span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  void requestFriend({ data: { userId: pilot.userId } }).then((res) => {
                    setNote(res.ok ? "Request sent." : res.error);
                  });
                }}
              >
                Add
              </Button>
            </li>
          ))}
        </ul>
      )}
      {note && <p className="mt-3 text-sm text-muted">{note}</p>}

      {requests.length > 0 && (
        <ul className="mt-6 max-w-md divide-y divide-border border-y border-border">
          {requests.map((row) => (
            <li key={row.userId} className="flex items-center justify-between gap-2 py-3">
              <span>{row.username}</span>
              <span className="flex gap-2">
                <Button
                  size="sm"
                  onClick={() => {
                    void respondFriend({ data: { userId: row.userId, accept: true } }).then(() => void refresh());
                  }}
                >
                  Accept
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    void respondFriend({ data: { userId: row.userId, accept: false } }).then(() => void refresh());
                  }}
                >
                  Decline
                </Button>
              </span>
            </li>
          ))}
        </ul>
      )}

      <ul className="mt-6 max-w-md divide-y divide-border border-y border-border">
        {friends.length === 0 && <li className="py-4 text-sm text-muted">No friends yet.</li>}
        {friends.map((row) => (
          <li key={row.userId}>
            <button
              type="button"
              className="flex w-full items-center justify-between py-3 text-left"
              onClick={() => setChatWith(row)}
            >
              <span className="font-medium">{row.username}</span>
              <span className="font-mono text-xs uppercase tracking-[0.16em] text-subtle">Chat</span>
            </button>
          </li>
        ))}
      </ul>

      {chatWith && (
        <div className="mt-4 max-w-md rounded-[var(--radius-lg)] border border-border bg-bg-elevated p-3">
          <div className="flex items-center justify-between">
            <p className="font-medium">{chatWith.username}</p>
            <Button size="sm" variant="ghost" onClick={() => setChatWith(null)}>
              Close
            </Button>
          </div>
          <ul className="mt-3 flex max-h-56 flex-col gap-2 overflow-auto">
            {lines.length === 0 && <li className="text-sm text-muted">No messages yet.</li>}
            {lines.map((line) => (
              <li key={line.id} className={line.mine ? "text-right text-sm" : "text-sm text-muted"}>
                {line.body}
              </li>
            ))}
          </ul>
          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              const body = text.trim();
              if (!body) return;
              setText("");
              void sendMessage({ data: { userId: chatWith.userId, body } }).then((res) => {
                if (!res.ok) setNote(res.error);
                else void listMessages({ data: { userId: chatWith.userId } }).then(setLines);
              });
            }}
          >
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              maxLength={400}
              className="min-w-0 flex-1 rounded-[var(--radius-sm)] border border-border bg-bg px-3 py-2 text-sm"
              placeholder="Message"
            />
            <Button type="submit">Send</Button>
          </form>
        </div>
      )}
    </section>
  );
}
