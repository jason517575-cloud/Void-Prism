import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { DROP_LABEL, KIND_LABEL } from "@/game/config";
import {
  AUDIO_FILE_MAX,
  BG_PRESETS,
  TRACK_CHOICES,
  blankLevel,
  deleteDraft,
  insideReach,
  loadDrafts,
  readDataUrl,
  sanitizeLevel,
  saveDraft,
  type CustomLevelDef,
  type DraftRow,
} from "@/game/custom-level";
import {
  deleteMyLevel,
  getCustomLevel,
  listLibrary,
  listMyLevels,
  publishLevel,
  type LevelCard,
} from "@/lib/community";
import type { AsteroidKind, DropId, SizeClass } from "@/game/types";

const KINDS: AsteroidKind[] = ["basalt", "rime", "quartz", "alloy"];
const SIZES: SizeClass[] = ["medium", "large", "small", "titan"];
const DROPS: DropId[] = ["aegis", "ward", "overcharge", "bomb", "frag2x"];

export function WorkshopScreen({
  signedIn,
  onBack,
  onPlay,
}: {
  signedIn: boolean;
  onBack: () => void;
  onPlay: (level: CustomLevelDef) => void;
}) {
  const [level, setLevel] = useState<CustomLevelDef>(blankLevel);
  const [kind, setKind] = useState<AsteroidKind>("basalt");
  const [size, setSize] = useState<SizeClass>("large");
  const [note, setNote] = useState("");
  const [drafts, setDrafts] = useState<DraftRow[]>([]);
  const [mine, setMine] = useState<LevelCard[]>([]);
  const [busy, setBusy] = useState(false);
  const [aspect, setAspect] = useState(1.6);

  useEffect(() => {
    const sync = () => setAspect(window.innerWidth / Math.max(1, window.innerHeight));
    sync();
    window.addEventListener("resize", sync);
    return () => window.removeEventListener("resize", sync);
  }, []);

  useEffect(() => {
    setDrafts(loadDrafts());
    if (!signedIn) return;
    void listMyLevels()
      .then(setMine)
      .catch(() => setMine([]));
  }, [signedIn]);

  const patch = (next: Partial<CustomLevelDef>) => setLevel((cur) => ({ ...cur, ...next }));

  const play = () => {
    const clean = sanitizeLevel(level);
    if (!clean.ok) {
      setNote(clean.error);
      return;
    }
    onPlay(clean.level);
  };

  const keep = () => {
    const clean = sanitizeLevel(level);
    if (!clean.ok) {
      setNote(clean.error);
      return;
    }
    const kept = saveDraft(clean.level);
    setDrafts(kept.drafts);
    setLevel(clean.level);
    setNote(
      kept.stripped
        ? "Draft saved without the big file. This browser can't store music that large — play or publish before you leave."
        : "Draft saved on this device.",
    );
  };

  const publish = async () => {
    const clean = sanitizeLevel(level);
    if (!clean.ok) {
      setNote(clean.error);
      return;
    }
    setBusy(true);
    try {
      const res = await publishLevel({ data: { level: clean.level } });
      if (!res.ok) setNote(res.error);
      else {
        setNote("Published. The name is now taken.");
        setMine(await listMyLevels());
      }
    } catch {
      setNote(signedIn ? "Could not publish. Music must be under 5 MB." : "Sign in to publish.");
    } finally {
      setBusy(false);
    }
  };

  const removePublished = async (id: string) => {
    setBusy(true);
    try {
      const res = await deleteMyLevel({ data: { id } });
      if (!res.ok) setNote(res.error);
      else setMine(await listMyLevels());
    } catch {
      setNote("Could not delete.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted">
        Back
      </button>
      <h2 className="mt-4 font-display text-2xl font-semibold tracking-tight">Workshop</h2>
      <p className="mt-2 max-w-lg text-sm text-muted">
        Name it, place the belt or let it spawn at random, pick lucky drops, then publish.
        Names have to be unique. Player-made belts pay no fragments. Music uploads can be up to 5 MB.
      </p>

      <div className="mt-5 grid w-full max-w-3xl gap-3">
        <label className="grid gap-1 text-xs uppercase tracking-[0.16em] text-subtle">
          Level name
          <input
            value={level.name}
            maxLength={32}
            onChange={(e) => patch({ name: e.target.value })}
            className="rounded-[var(--radius-sm)] border border-border bg-bg px-3 py-2 text-sm normal-case tracking-normal text-fg"
            placeholder="Unique name"
          />
        </label>
        <label className="grid gap-1 text-xs uppercase tracking-[0.16em] text-subtle">
          Drift speed {level.speed}
          <input
            type="range"
            min={28}
            max={78}
            value={level.speed}
            onChange={(e) => patch({ speed: Number(e.target.value) })}
          />
        </label>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant={level.spawn === "random" ? "primary" : "outline"} onClick={() => patch({ spawn: "random" })}>
            Random spawn
          </Button>
          <Button size="sm" variant={level.spawn === "placed" ? "primary" : "outline"} onClick={() => patch({ spawn: "placed" })}>
            Place rocks
          </Button>
        </div>

        {level.spawn === "random" ? (
          <div className="grid gap-2">
            <div className="flex flex-wrap gap-2">
              {KINDS.map((id) => {
                const on = level.kinds.includes(id);
                return (
                  <Button
                    key={id}
                    size="sm"
                    variant={on ? "primary" : "outline"}
                    onClick={() =>
                      patch({
                        kinds: on ? level.kinds.filter((k) => k !== id) : [...level.kinds, id],
                      })
                    }
                  >
                    {KIND_LABEL[id]}
                  </Button>
                );
              })}
            </div>
            <label className="grid gap-1 text-xs uppercase tracking-[0.16em] text-subtle">
              Count {level.count}
              <input
                type="range"
                min={3}
                max={14}
                value={level.count}
                onChange={(e) => patch({ count: Number(e.target.value) })}
              />
            </label>
          </div>
        ) : (
          <div className="grid gap-2">
            <div className="flex flex-wrap gap-2">
              {KINDS.map((id) => (
                <Button key={id} size="sm" variant={kind === id ? "primary" : "outline"} onClick={() => setKind(id)}>
                  {KIND_LABEL[id]}
                </Button>
              ))}
              {SIZES.map((id) => (
                <Button key={id} size="sm" variant={size === id ? "primary" : "outline"} onClick={() => setSize(id)}>
                  {id}
                </Button>
              ))}
            </div>
            <div
              className="relative mx-auto w-full max-w-xl overflow-hidden rounded-[var(--radius-md)] border border-border bg-bg-elevated"
              style={{ aspectRatio: String(aspect) }}
            >
              <button
                type="button"
                className="absolute inset-0"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const nx = (e.clientX - rect.left) / rect.width;
                  const ny = (e.clientY - rect.top) / rect.height;
                  if (insideReach(nx, ny, aspect)) {
                    setNote("Place rocks outside the range ring.");
                    return;
                  }
                  setNote("");
                  patch({ rocks: [...level.rocks, { kind, size, nx, ny }].slice(0, 18) });
                }}
              />
              <svg
                viewBox={`0 0 ${aspect} 1`}
                className="pointer-events-none absolute inset-0 h-full w-full text-subtle"
              >
                <circle
                  cx={aspect / 2}
                  cy={0.48}
                  r={0.52 * Math.min(aspect, 1)}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={0.004}
                  strokeDasharray="0.02 0.015"
                />
              </svg>
              <span className="pointer-events-none absolute left-3 top-2 font-mono text-[0.65rem] uppercase tracking-[0.16em] text-subtle">
                Outside the ring · {level.rocks.length}
              </span>
              {level.rocks.map((rock, i) => (
                <span
                  key={`${rock.nx}-${rock.ny}-${i}`}
                  className="pointer-events-none absolute size-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent"
                  style={{ left: `${rock.nx * 100}%`, top: `${rock.ny * 100}%` }}
                />
              ))}
            </div>
            {level.rocks.length > 0 && (
              <Button size="sm" variant="ghost" onClick={() => patch({ rocks: level.rocks.slice(0, -1) })}>
                Undo last rock
              </Button>
            )}
          </div>
        )}

        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant={level.lucky === "random" ? "primary" : "outline"} onClick={() => patch({ lucky: "random" })}>
            Random lucky
          </Button>
          <Button size="sm" variant={level.lucky === "fixed" ? "primary" : "outline"} onClick={() => patch({ lucky: "fixed" })}>
            Chosen drops
          </Button>
        </div>
        <label className="grid gap-1 text-xs uppercase tracking-[0.16em] text-subtle">
          Lucky rocks {level.luckyCount}
          <input
            type="range"
            min={0}
            max={5}
            value={level.luckyCount}
            onChange={(e) => patch({ luckyCount: Number(e.target.value) })}
          />
        </label>
        {level.lucky === "fixed" && (
          <div className="flex flex-wrap gap-2">
            {DROPS.map((id) => {
              const on = level.luckyDrops.includes(id);
              return (
                <Button
                  key={id}
                  size="sm"
                  variant={on ? "primary" : "outline"}
                  onClick={() =>
                    patch({
                      luckyDrops: on
                        ? level.luckyDrops.filter((d) => d !== id)
                        : [...level.luckyDrops, id],
                    })
                  }
                >
                  {DROP_LABEL[id]}
                </Button>
              );
            })}
          </div>
        )}

        <p className="font-mono text-xs uppercase tracking-[0.16em] text-subtle">Your background</p>
        <div className="flex flex-wrap items-center gap-2">
          {BG_PRESETS.map((id) => (
            <Button key={id} size="sm" variant={level.bg === id ? "primary" : "outline"} onClick={() => patch({ bg: id, bgData: "" })}>
              {id}
            </Button>
          ))}
          <Button size="sm" variant={level.bg === "custom" ? "primary" : "outline"} asChild>
            <label>
              Upload image
              <input
                type="file"
                accept="image/*"
                className="sr-only"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (!file) return;
                  void readDataUrl(file, 450_000, "image").then((res) => {
                    if (!res.ok) setNote(res.error);
                    else {
                      patch({ bg: "custom", bgData: res.url });
                      setNote("Background loaded.");
                    }
                  });
                }}
              />
            </label>
          </Button>
        </div>
        {level.bg === "custom" && level.bgData && (
          <img src={level.bgData} alt="" className="h-20 w-32 rounded-[var(--radius-sm)] object-cover" />
        )}

        <p className="font-mono text-xs uppercase tracking-[0.16em] text-subtle">Your music</p>
        <label className="grid gap-1 text-xs uppercase tracking-[0.16em] text-subtle">
          Game track
          <select
            value={level.gameMusicId}
            onChange={(e) => patch({ music: "game", gameMusicId: e.target.value, musicData: "" })}
            className="rounded-[var(--radius-sm)] border border-border bg-bg px-3 py-2 text-sm normal-case tracking-normal text-fg"
          >
            {TRACK_CHOICES.map((t) => (
              <option key={t.id} value={t.id}>
                {t.label}
              </option>
            ))}
          </select>
        </label>
        <Button size="sm" variant={level.music === "upload" ? "primary" : "outline"} className="w-fit" asChild>
          <label>
            Upload music
            <input
              type="file"
              accept="audio/*"
              className="sr-only"
              onChange={(e) => {
                const file = e.target.files?.[0];
                e.target.value = "";
                if (!file) return;
                setNote("Reading music…");
                void readDataUrl(file, AUDIO_FILE_MAX, "audio").then((res) => {
                  if (!res.ok) setNote(res.error);
                  else {
                    patch({ music: "upload", musicData: res.url });
                    setNote("Music loaded. Max 5 MB. It plays when you test or publish.");
                  }
                });
              }}
            />
          </label>
        </Button>
        {level.music === "upload" && <p className="text-xs text-muted">Using your uploaded track. 5 MB max.</p>}

        {note && <p className="text-sm text-muted">{note}</p>}
        <div className="flex flex-wrap gap-2">
          <Button onClick={play}>Play test</Button>
          <Button variant="outline" onClick={keep}>
            Save draft
          </Button>
          {signedIn ? (
            <Button variant="outline" disabled={busy} onClick={() => void publish()}>
              Publish
            </Button>
          ) : (
            <Button variant="outline" asChild>
              <Link to="/login">Sign in to publish</Link>
            </Button>
          )}
        </div>
      </div>

      {drafts.length > 0 && (
        <ul className="mt-8 w-full max-w-3xl divide-y divide-border border-y border-border">
          {drafts.map((d) => (
            <li key={d.id} className="flex items-center justify-between gap-3 py-3">
              <button type="button" className="text-left" onClick={() => setLevel(d.level)}>
                <span className="block font-medium">{d.level.name}</span>
                <span className="text-xs text-muted">Draft</span>
              </button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setDrafts(deleteDraft(d.id))}
              >
                Delete
              </Button>
            </li>
          ))}
        </ul>
      )}

      {mine.length > 0 && (
        <ul className="mt-6 w-full max-w-3xl divide-y divide-border border-y border-border">
          {mine.map((row) => (
            <li key={row.id} className="flex items-center justify-between gap-3 py-3">
              <div>
                <p className="font-medium">{row.name}</p>
                <p className="text-xs text-muted">{row.summary}</p>
              </div>
              <Button size="sm" variant="ghost" disabled={busy} onClick={() => void removePublished(row.id)}>
                Delete
              </Button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export function LibraryScreen({
  onBack,
  onPlay,
}: {
  onBack: () => void;
  onPlay: (level: CustomLevelDef) => void;
}) {
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<LevelCard[]>([]);
  const [note, setNote] = useState("");
  const [opening, setOpening] = useState<string | null>(null);

  const load = (query: string) => {
    void listLibrary({ data: { q: query } })
      .then(setRows)
      .catch(() => setNote("Library is unavailable."));
  };

  useEffect(() => {
    load("");
  }, []);

  return (
    <section className="relative z-10 flex h-full flex-col overflow-auto px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] sm:px-8">
      <button type="button" onClick={onBack} className="self-start font-mono text-xs uppercase tracking-[0.22em] text-muted">
        Back
      </button>
      <h2 className="mt-4 font-display text-2xl font-semibold tracking-tight">Library</h2>
      <p className="mt-2 max-w-lg text-sm text-muted">Published belts. They pay no fragments. Names stay unique.</p>
      <form
        className="mt-4 flex max-w-md gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          load(q);
        }}
      >
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search name"
          className="min-w-0 flex-1 rounded-[var(--radius-sm)] border border-border bg-bg px-3 py-2 text-sm"
        />
        <Button type="submit" variant="outline">
          Search
        </Button>
      </form>
      {note && <p className="mt-3 text-sm text-muted">{note}</p>}
      <ul className="mt-4 w-full max-w-3xl divide-y divide-border border-y border-border">
        {rows.length === 0 && <li className="py-6 text-sm text-muted">No published levels yet.</li>}
        {rows.map((row) => (
          <li key={row.id} className="flex items-center justify-between gap-3 py-3">
            <div className="min-w-0">
              <p className="truncate font-medium">{row.name}</p>
              <p className="text-xs text-muted">
                {row.author} · {row.summary}
              </p>
            </div>
            <Button
              size="sm"
              disabled={opening === row.id}
              onClick={() => {
                setOpening(row.id);
                setNote("");
                void getCustomLevel({ data: { id: row.id } })
                  .then((res) => {
                    if (!res.ok) setNote(res.error);
                    else onPlay(res.level);
                  })
                  .catch(() => setNote("That belt didn't open. Try again."))
                  .finally(() => setOpening((cur) => (cur === row.id ? null : cur)));
              }}
            >
              {opening === row.id ? "Opening" : "Play"}
            </Button>
          </li>
        ))}
      </ul>
    </section>
  );
}
