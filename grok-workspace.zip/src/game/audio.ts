import { MUSIC, infiniteBpm, infiniteMusicId } from "./config";
import type { MusicProfile, WeaponId } from "./types";

type Bus = {
  ctx: AudioContext;
  master: GainNode;
  music: GainNode;
  pad: GainNode;
  sfx: GainNode;
  delay: DelayNode;
  delayGain: GainNode;
  filter: BiquadFilterNode;
};

let bus: Bus | null = null;
let muted = false;
let musicVol = 0.72;
let sfxVol = 0.88;
let musicGen = 0;
let schedulerTimer: ReturnType<typeof setTimeout> | null = null;
let noiseBuf: AudioBuffer | null = null;
let currentProfile: MusicProfile | null = null;
let fileAudio: HTMLAudioElement | null = null;

function stopFile() {
  if (!fileAudio) return;
  fileAudio.pause();
  fileAudio.src = "";
  fileAudio = null;
}

function freq(root: number, semis: number) {
  return root * Math.pow(2, semis / 12);
}

function ensureBus(): Bus | null {
  if (bus) return bus;
  const AC =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext;
  if (!AC) return null;
  const ctx = new AC({ latencyHint: "interactive" });
  const master = ctx.createGain();
  const music = ctx.createGain();
  const pad = ctx.createGain();
  const sfx = ctx.createGain();
  const filter = ctx.createBiquadFilter();
  const delay = ctx.createDelay(1.4);
  const delayGain = ctx.createGain();
  const feedback = ctx.createGain();

  filter.type = "lowpass";
  filter.Q.value = 0.7;
  filter.frequency.value = 1400;
  delay.delayTime.value = 0.28;
  delayGain.gain.value = 0.16;
  feedback.gain.value = 0.32;
  music.gain.value = musicVol;
  pad.gain.value = musicVol;
  sfx.gain.value = sfxVol;
  master.gain.value = muted ? 0 : 0.88;

  music.connect(filter);
  pad.connect(filter);
  filter.connect(delay);
  delay.connect(delayGain);
  delay.connect(feedback);
  feedback.connect(delay);
  delayGain.connect(master);
  filter.connect(master);
  sfx.connect(master);
  master.connect(ctx.destination);

  const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  noiseBuf = buf;

  bus = { ctx, master, music, pad, sfx, delay, delayGain, filter };
  return bus;
}

export function unlockAudio() {
  const b = ensureBus();
  if (!b) return;
  if (b.ctx.state === "suspended") void b.ctx.resume();
}

export function setMuted(value: boolean) {
  muted = value;
  if (!bus) return;
  bus.master.gain.setTargetAtTime(value ? 0 : 0.88, bus.ctx.currentTime, 0.03);
  if (fileAudio) fileAudio.volume = value ? 0 : musicVol;
}

export function setMusicVolume(value: number) {
  musicVol = Math.max(0, Math.min(1, value));
  if (!bus) return;
  const t = bus.ctx.currentTime;
  bus.music.gain.setTargetAtTime(musicVol, t, 0.04);
  bus.pad.gain.setTargetAtTime(musicVol, t, 0.04);
  if (fileAudio) fileAudio.volume = musicVol;
}

export function setSfxVolume(value: number) {
  sfxVol = Math.max(0, Math.min(1, value));
  if (!bus) return;
  bus.sfx.gain.setTargetAtTime(sfxVol, bus.ctx.currentTime, 0.04);
}

export function applyMix(next: { muted?: boolean; musicVol?: number; sfxVol?: number }) {
  if (typeof next.musicVol === "number") setMusicVolume(next.musicVol);
  if (typeof next.sfxVol === "number") setSfxVolume(next.sfxVol);
  if (typeof next.muted === "boolean") setMuted(next.muted);
}

export function isMuted() {
  return muted;
}

export function resumeAudio() {
  if (bus && bus.ctx.state === "suspended") void bus.ctx.resume();
}

function envGain(
  ctx: AudioContext,
  start: number,
  peak: number,
  dur: number,
  attack = 0.01,
) {
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), start + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  return g;
}

function tone(
  dest: AudioNode,
  ctx: AudioContext,
  time: number,
  hz: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  attack = 0.012,
  detune = 0,
  pan = 0,
) {
  const o = ctx.createOscillator();
  const g = envGain(ctx, time, gain, dur, attack);
  o.type = type;
  o.frequency.setValueAtTime(hz, time);
  if (detune) o.detune.setValueAtTime(detune, time);
  o.connect(g);
  if (pan !== 0 && ctx.createStereoPanner) {
    const p = ctx.createStereoPanner();
    p.pan.setValueAtTime(Math.max(-1, Math.min(1, pan)), time);
    g.connect(p);
    p.connect(dest);
  } else {
    g.connect(dest);
  }
  o.start(time);
  o.stop(time + dur + 0.05);
}

function noiseBurst(
  dest: AudioNode,
  ctx: AudioContext,
  time: number,
  dur: number,
  gain: number,
  hp = 400,
) {
  if (!noiseBuf) return;
  const src = ctx.createBufferSource();
  src.buffer = noiseBuf;
  const f = ctx.createBiquadFilter();
  f.type = "highpass";
  f.frequency.value = hp;
  const g = envGain(ctx, time, gain, dur, 0.004);
  src.connect(f);
  f.connect(g);
  g.connect(dest);
  src.start(time);
  src.stop(time + dur + 0.02);
}

function kick(dest: AudioNode, ctx: AudioContext, time: number, gain: number) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = "sine";
  o.frequency.setValueAtTime(150, time);
  o.frequency.exponentialRampToValueAtTime(42, time + 0.14);
  g.gain.setValueAtTime(0.0001, time);
  g.gain.exponentialRampToValueAtTime(gain, time + 0.006);
  g.gain.exponentialRampToValueAtTime(0.0001, time + 0.22);
  o.connect(g);
  g.connect(dest);
  o.start(time);
  o.stop(time + 0.24);
  noiseBurst(dest, ctx, time, 0.03, gain * 0.25, 800);
}

function snare(dest: AudioNode, ctx: AudioContext, time: number, gain: number) {
  noiseBurst(dest, ctx, time, 0.12, gain, 1200);
  tone(dest, ctx, time, 190, 0.08, "triangle", gain * 0.45, 0.003);
}

function stopScheduler() {
  musicGen += 1;
  if (schedulerTimer) {
    clearTimeout(schedulerTimer);
    schedulerTimer = null;
  }
}

export function stopMusic() {
  stopScheduler();
  stopFile();
  currentProfile = null;
  if (!bus) return;
  bus.music.gain.setTargetAtTime(0.0001, bus.ctx.currentTime, 0.08);
  bus.pad.gain.setTargetAtTime(0.0001, bus.ctx.currentTime, 0.08);
}

const GROOVES: Record<string, { k: string; s: string; h: string }> = {
  title: { k: "----------------", s: "----------------", h: "--x---x---x---x-" },
  shale: { k: "x---x---x---x--x", s: "----x-------x---", h: "x-x-x-x-x-x-x-xx" },
  rime: { k: "x-------x-------", s: "--------x-------", h: "x-xxx-x-x-xxx-x-" },
  twin: { k: "x---x---x---x---", s: "----x-------x---", h: "--x---x---x---x-" },
  quartz: { k: "x-----x-x-------", s: "----x-------x---", h: "x-x-xxx-x-x-xxx-" },
  alloy: { k: "x-x-----x-x--x--", s: "----x-------x---", h: "xxxxxxxxxxxxxxxx" },
  fourfold: { k: "x---x--xx---x---", s: "----x-------x---", h: "x-x-x-x-x-x-x-x-" },
  splinter: { k: "x-x---x---x--x--", s: "--x---x---x---x-", h: "xx-xxx-xxx-xxx-x" },
  halo: { k: "x--------x------", s: "----x-----------", h: "x--x--x--x--x--x" },
  titan: { k: "x---------------", s: "--------x-------", h: "----------------" },
  gauntlet: { k: "x-x-x---x-x-x---", s: "----x-------x---", h: "x-xxx-x-x-xxx-x-" },
  drift0: { k: "x---x---x---x---", s: "----x-------x---", h: "x-x-x-x-x-x-x-x-" },
  drift1: { k: "x-------x---x---", s: "--------x-------", h: "--x---x---x---x-" },
  drift2: { k: "x--------x------", s: "------x---------", h: "x--x--x--x--x--x" },
};

function hits(src: string, steps: number): boolean[] {
  const s = src.padEnd(steps, "-").slice(0, steps);
  return [...s].map((c) => c === "x" || c === "X");
}

function grooveFor(profile: MusicProfile) {
  const g = GROOVES[profile.id];
  const n = profile.steps;
  const defK = profile.kick ? "x---x---x---x---" : "----------------";
  const defS = profile.snare ? "----x-------x---" : "----------------";
  const defH = profile.hats ? "x-x-x-x-x-x-x-x-" : "----------------";
  return {
    k: hits(profile.kickG ?? g?.k ?? defK, n),
    s: hits(profile.snareG ?? g?.s ?? defS, n),
    h: hits(profile.hatG ?? g?.h ?? defH, n),
  };
}

function scheduleProfile(profile: MusicProfile, gen: number) {
  const b = bus;
  if (!b) return;
  const { ctx } = b;
  const groove = grooveFor(profile);
  b.filter.frequency.setTargetAtTime(profile.filterHz, ctx.currentTime, 0.08);
  b.delay.delayTime.setTargetAtTime(
    Math.max(0.08, profile.delay),
    ctx.currentTime,
    0.05,
  );
  b.delayGain.gain.setTargetAtTime(
    profile.delay > 0.2 ? 0.26 : 0.12,
    ctx.currentTime,
    0.05,
  );
  b.music.gain.cancelScheduledValues(ctx.currentTime);
  b.pad.gain.cancelScheduledValues(ctx.currentTime);
  b.music.gain.setTargetAtTime(1, ctx.currentTime, 0.12);
  b.pad.gain.setTargetAtTime(1, ctx.currentTime, 0.12);

  let step = 0;
  const stepDur = 60 / profile.bpm / 2;
  let next = ctx.currentTime + 0.06;

  const tick = () => {
    if (gen !== musicGen) return;
    if (typeof document !== "undefined" && document.hidden) {
      next = ctx.currentTime + 0.05;
      schedulerTimer = setTimeout(tick, 240);
      return;
    }
    if (ctx.currentTime > next + 0.2) next = ctx.currentTime + 0.05;
    let guard = 0;
    try {
    while (next < ctx.currentTime + 0.16 && guard < 6) {
      const i = step % profile.steps;
      const swing = i % 2 === 1 ? stepDur * profile.swing : 0;
      const t = next + swing;
      const leadIdx = profile.lead[i] ?? -1;
      const bassIdx = profile.bass[i] ?? -1;
      const arpIdx = profile.arp[i] ?? -1;
      const dur = stepDur * profile.noteFrac;
      const cycle = Math.sin((step / profile.steps) * Math.PI * 2);
      b.filter.frequency.setTargetAtTime(
        profile.filterHz * (0.82 + 0.28 * cycle),
        t,
        0.08,
      );

      if (bassIdx >= 0) {
        const semis = profile.scale[bassIdx] ?? 0;
        const hz = freq(profile.rootHz, semis);
        tone(b.music, ctx, t, hz, dur * 1.35, profile.bassWave, profile.bassGain, 0.02);
        tone(b.music, ctx, t, hz * 0.5, dur * 1.4, "sine", profile.bassGain * 0.7, 0.03);
      }
      if (leadIdx >= 0) {
        const semis = profile.scale[leadIdx] ?? 0;
        const hz = freq(profile.rootHz * 2, semis);
        tone(
          b.music,
          ctx,
          t,
          hz,
          dur,
          profile.leadWave,
          profile.leadGain,
          0.012,
          0,
          0.12,
        );
        tone(
          b.music,
          ctx,
          t,
          hz,
          dur * 1.05,
          profile.leadWave,
          profile.leadGain * 0.4,
          0.016,
          8,
          -0.18,
        );
        const fifth = freq(profile.rootHz * 2, semis + 7);
        tone(
          b.music,
          ctx,
          t,
          fifth,
          dur * 0.85,
          "sine",
          profile.leadGain * 0.28,
          0.02,
          0,
          0.22,
        );
      }
      if (arpIdx >= 0 && profile.arpGain > 0) {
        const semis = profile.scale[arpIdx] ?? 0;
        const pan = i % 2 === 0 ? -0.45 : 0.45;
        tone(
          b.music,
          ctx,
          t,
          freq(profile.rootHz * 2, semis + 12),
          stepDur * 0.48,
          "sine",
          profile.arpGain * 1.15,
          0.006,
          0,
          pan,
        );
      }

      const chordEvery = Math.max(4, Math.floor(profile.steps / 4));
      const bar = Math.floor(step / chordEvery) % profile.chords.length;
      const chord = profile.chords[bar] ?? profile.chords[0];
      if (chord && i % chordEvery === 0) {
        const hold = stepDur * chordEvery * 0.94;
        for (const idx of chord) {
          const semis = profile.scale[idx] ?? 0;
          const hz = freq(profile.rootHz, semis + 12);
          tone(b.pad, ctx, t, hz, hold, "sine", profile.padGain, 0.1);
          tone(b.pad, ctx, t, hz, hold, "sine", profile.padGain * 0.55, 0.12, -8);
          tone(b.pad, ctx, t, hz, hold, "triangle", profile.padGain * 0.32, 0.14, 11);
        }
      }

      if (groove.k[i]) {
        kick(b.music, ctx, t, 0.2);
        b.pad.gain.setValueAtTime(0.55, t);
        b.pad.gain.setTargetAtTime(1, t + 0.1, 0.08);
      }
      if (groove.s[i]) {
        snare(b.music, ctx, t, 0.11);
      }
      if (groove.h[i]) {
        const open = i % 4 === 3;
        noiseBurst(b.music, ctx, t, open ? 0.08 : 0.03, open ? 0.028 : 0.018, 6500);
      }

      next += stepDur;
      step += 1;
      guard += 1;
    }
    } catch {
      next = ctx.currentTime + 0.05;
    }
    schedulerTimer = setTimeout(tick, 20);
  };
  tick();
}

export function playMusic(id: string, bpmOverride?: number) {
  stopFile();
  const base = MUSIC[id];
  if (!base) return;
  const profile: MusicProfile =
    bpmOverride && bpmOverride !== base.bpm
      ? { ...base, bpm: bpmOverride }
      : base;
  if (currentProfile?.id === profile.id && currentProfile.bpm === profile.bpm) {
    return;
  }
  unlockAudio();
  stopScheduler();
  currentProfile = profile;
  const gen = musicGen;
  scheduleProfile(profile, gen);
}

export function playFileMusic(url: string) {
  unlockAudio();
  stopScheduler();
  currentProfile = null;
  stopFile();
  const audio = new Audio();
  audio.loop = true;
  audio.preload = "auto";
  audio.volume = muted ? 0 : musicVol;
  fileAudio = audio;
  const start = () => {
    if (fileAudio !== audio) return;
    audio.src = url;
    void audio.play().catch(() => {});
  };
  setTimeout(start, 48);
}

export function playLevelMusic(levelMusicId: string) {
  playMusic(levelMusicId);
}

export function playInfiniteMusic(wave: number) {
  const id = infiniteMusicId(wave);
  const base = MUSIC[id];
  playMusic(id, infiniteBpm(wave, base?.bpm ?? 104));
}

export function playTitleMusic() {
  playMusic("title");
}

export function sfxShoot(weapon: WeaponId) {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  const map: Record<WeaponId, number> = {
    kinetic: 920,
    cryo: 640,
    resonant: 780,
    thermal: 430,
  };
  tone(b.sfx, b.ctx, t, map[weapon], 0.1, "square", 0.055, 0.003);
  tone(b.sfx, b.ctx, t, map[weapon] * 0.5, 0.08, "sine", 0.04, 0.004);
}

export function sfxHit() {
  const b = ensureBus();
  if (!b) return;
  noiseBurst(b.sfx, b.ctx, b.ctx.currentTime, 0.12, 0.08, 800);
  tone(b.sfx, b.ctx, b.ctx.currentTime, 180, 0.1, "sine", 0.06, 0.003);
}

export function sfxResist() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  tone(b.sfx, b.ctx, t, 240, 0.08, "square", 0.045, 0.002);
  tone(b.sfx, b.ctx, t + 0.04, 180, 0.1, "square", 0.03, 0.002);
}

export function sfxExplode(big: boolean) {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  noiseBurst(b.sfx, b.ctx, t, big ? 0.32 : 0.18, big ? 0.14 : 0.08, 200);
  tone(b.sfx, b.ctx, t, big ? 70 : 110, big ? 0.28 : 0.16, "sine", 0.1, 0.004);
}

export function sfxDead() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  tone(b.sfx, b.ctx, t, 220, 0.4, "sawtooth", 0.07, 0.01);
  tone(b.sfx, b.ctx, t + 0.05, 110, 0.5, "sine", 0.08, 0.01);
  noiseBurst(b.sfx, b.ctx, t, 0.4, 0.1, 300);
}

export function sfxSwitch() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  tone(b.sfx, b.ctx, t, 520, 0.06, "sine", 0.04, 0.004);
  tone(b.sfx, b.ctx, t + 0.05, 780, 0.07, "sine", 0.035, 0.004);
}

export function sfxUi() {
  const b = ensureBus();
  if (!b) return;
  tone(b.sfx, b.ctx, b.ctx.currentTime, 660, 0.05, "sine", 0.03, 0.004);
}

export function sfxClear() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  [0, 4, 7, 12].forEach((s, i) => {
    tone(b.sfx, b.ctx, t + i * 0.08, freq(220, s), 0.2, "sine", 0.055, 0.01);
  });
}

export function sfxExtra() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  [7, 12, 16].forEach((s, i) => {
    tone(b.sfx, b.ctx, t + i * 0.07, freq(330, s), 0.16, "triangle", 0.05, 0.008);
  });
}

export function sfxLucky() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  [0, 4, 7, 11].forEach((s, i) => {
    tone(b.sfx, b.ctx, t + i * 0.05, freq(392, s), 0.14, "triangle", 0.055, 0.006);
  });
}

export function sfxPower() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  tone(b.sfx, b.ctx, t, 520, 0.12, "sine", 0.06, 0.006);
  tone(b.sfx, b.ctx, t + 0.06, 780, 0.16, "triangle", 0.05, 0.008);
}

export function sfxBomb() {
  const b = ensureBus();
  if (!b) return;
  const t = b.ctx.currentTime;
  noiseBurst(b.sfx, b.ctx, t, 0.28, 0.16, 180);
  tone(b.sfx, b.ctx, t, 90, 0.26, "sine", 0.12, 0.004);
}

export function setThrust(_on: boolean) {
  /* no ship */
}
