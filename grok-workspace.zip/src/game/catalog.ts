import type {
  AsteroidKind,
  LevelDef,
  MusicProfile,
  SkinId,
  WeaponId,
} from "./types";

export type SkinDef = {
  id: SkinId;
  name: string;
  cost: number;
  blurb: string;
  core: string;
  beam: string;
};

const R = -1;

function hslHex(h: number, s: number, l: number): string {
  const sat = s / 100;
  const lig = l / 100;
  const a = sat * Math.min(lig, 1 - lig);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = lig - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * c)
      .toString(16)
      .padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

const HAND_SKINS: SkinDef[] = [
  { id: "prism", name: "Prism", cost: 0, blurb: "Stock well.", core: "#c5cdd8", beam: "#ecece8" },
  { id: "aurora", name: "Aurora", cost: 50, blurb: "Cold drift.", core: "#7ec8d4", beam: "#9ee8f0" },
  { id: "ember", name: "Ember", cost: 50, blurb: "Thermal husk.", core: "#c4845a", beam: "#e8a070" },
  { id: "ion", name: "Ion", cost: 80, blurb: "Resonant veil.", core: "#8fbfa5", beam: "#b6e0c8" },
  { id: "gold", name: "Gilded", cost: 140, blurb: "Lucky belt.", core: "#e6c35c", beam: "#f3de8a" },
  { id: "obsidian", name: "Obsidian", cost: 110, blurb: "Dark glass.", core: "#6a6a74", beam: "#ecece8" },
];

const EXTRA_SKINS: { id: string; name: string; blurb: string }[] = [
  { id: "violet", name: "Violet", blurb: "Ion dusk." },
  { id: "rust", name: "Rust", blurb: "Old hull." },
  { id: "frost", name: "Frost", blurb: "Thin ice." },
  { id: "jade", name: "Jade", blurb: "Quiet vein." },
  { id: "copper", name: "Copper", blurb: "Warm ore." },
  { id: "cobalt", name: "Cobalt", blurb: "Deep pulse." },
  { id: "pearl", name: "Pearl", blurb: "Soft core." },
  { id: "magma", name: "Magma", blurb: "Open kiln." },
  { id: "moss", name: "Moss", blurb: "Belt growth." },
  { id: "noir", name: "Noir", blurb: "Low light." },
  { id: "rose", name: "Rose", blurb: "Dust bloom." },
  { id: "citrus", name: "Citrus", blurb: "Sharp rind." },
  { id: "dusk", name: "Dusk", blurb: "Late orbit." },
  { id: "lime", name: "Lime", blurb: "Acid wash." },
  { id: "wine", name: "Wine", blurb: "Dark fruit." },
  { id: "steel", name: "Steel", blurb: "Cold plate." },
  { id: "sand", name: "Sand", blurb: "Dry halo." },
  { id: "bloom", name: "Bloom", blurb: "Open petal." },
  { id: "ice", name: "Ice", blurb: "Hard rime." },
  { id: "nectar", name: "Nectar", blurb: "Sweet burn." },
  { id: "slate", name: "Slate", blurb: "Cut stone." },
  { id: "flare", name: "Flare", blurb: "Signal fire." },
  { id: "mint", name: "Mint", blurb: "Cool leaf." },
  { id: "emberglass", name: "Emberglass", blurb: "Fired silica." },
  { id: "tidal", name: "Tidal", blurb: "Pull and push." },
  { id: "umber", name: "Umber", blurb: "Earth crust." },
  { id: "quartzite", name: "Quartzite", blurb: "Pressed crystal." },
  { id: "plasma", name: "Plasma", blurb: "Hot field." },
  { id: "fog", name: "Fog", blurb: "Soft veil." },
  { id: "coral", name: "Coral", blurb: "Reef light." },
  { id: "onyx", name: "Onyx", blurb: "Black cut." },
  { id: "chartreuse", name: "Chartreuse", blurb: "Acid silk." },
  { id: "indigo", name: "Indigo", blurb: "Night dye." },
  { id: "brass", name: "Brass", blurb: "Horn metal." },
  { id: "glacier", name: "Glacier", blurb: "Slow blue." },
  { id: "pyro", name: "Pyro", blurb: "Short fuse." },
  { id: "kelp", name: "Kelp", blurb: "Deep green." },
  { id: "ivory", name: "Ivory", blurb: "Bone well." },
  { id: "mercury", name: "Mercury", blurb: "Live metal." },
  { id: "amethyst", name: "Amethyst", blurb: "Royal shard." },
  { id: "cinder", name: "Cinder", blurb: "After burn." },
  { id: "opal", name: "Opal", blurb: "Shift fire." },
  { id: "saturn", name: "Saturn", blurb: "Ring light." },
  { id: "voidlight", name: "Voidlight", blurb: "Last gleam." },
];

function extraCost(i: number): number {
  if (i < 8) return 60 + i * 12;
  if (i < 20) return 180 + (i - 8) * 18;
  if (i < 32) return 420 + (i - 20) * 28;
  return 820 + (i - 32) * 70;
}

export const SKINS: SkinDef[] = [
  ...HAND_SKINS,
  ...EXTRA_SKINS.map((s, i) => {
    const h = (i * 137.508 + 18) % 360;
    const core = hslHex(h, 42 + (i % 5) * 6, 52 + (i % 3) * 4);
    const beam = hslHex(h, 38, 78);
    return {
      id: s.id,
      name: s.name,
      blurb: s.blurb,
      cost: extraCost(i),
      core,
      beam,
    };
  }),
];

export function skinById(id: SkinId): SkinDef {
  return SKINS.find((s) => s.id === id) ?? SKINS[0]!;
}

const LEVEL_META: { name: string; briefing: string }[] = [
  { name: "Shale Drift", briefing: "Click basalt with kinetic." },
  { name: "Rime Wake", briefing: "Ice yields only to cryo. Switch, then click." },
  { name: "Twin Belt", briefing: "Two materials. Switch between beams." },
  { name: "Quartz Vein", briefing: "Resonant pulse for crystal. Click each shard." },
  { name: "Alloy Rain", briefing: "Thermal lance for metal. Guard the well." },
  { name: "Fourfold", briefing: "Every spectrum at once." },
  { name: "Splinter Field", briefing: "They come apart fast. Stay on the match." },
  { name: "Dense Halo", briefing: "No room to miss." },
  { name: "Titan Core", briefing: "Giants of every kind. Click the hulls." },
  { name: "Prism Gauntlet", briefing: "Hold the spectrum. Protect the well." },
  { name: "Veil Rift", briefing: "The belt thins. Keep the match clean." },
  { name: "Ash Orbit", briefing: "Hot stone, faster pull." },
  { name: "Cyan Wreck", briefing: "Cryo wreckage. Do not freeze up." },
  { name: "Glass Tide", briefing: "Quartz floods the well." },
  { name: "Ember Stack", briefing: "Alloy stacks. Thermal only." },
  { name: "Polar Fold", briefing: "Cold and stone together." },
  { name: "Rust Choir", briefing: "Metal sings. Switch or die." },
  { name: "Night Quarry", briefing: "Four kinds in the dark." },
  { name: "Ion Shelf", briefing: "Resonant shelf. Stay precise." },
  { name: "Hollow Sun", briefing: "Bright, fast, unforgiving." },
  { name: "Pale Current", briefing: "A slow pull, then a snap." },
  { name: "Red Caldera", briefing: "Thermal country. Watch the well." },
  { name: "Soft Static", briefing: "Quartz chatter. Match the pulse." },
  { name: "Brine Crown", briefing: "Rime royalty. Cryo ready." },
  { name: "Silent Kiln", briefing: "Heat without warning." },
  { name: "Volt Garden", briefing: "Every laser, every second." },
  { name: "Dust Cathedral", briefing: "High count. Keep switching." },
  { name: "Cold Forge", briefing: "Ice and metal. Two docks." },
  { name: "Prism Fault", briefing: "The spectrum splits again." },
  { name: "Black Harvest", briefing: "Titans in the dark." },
  { name: "Silver Wake", briefing: "Faster belt. No late clicks." },
  { name: "Thorn Belt", briefing: "Sharp count, sharp pull." },
  { name: "Mirage Dock", briefing: "Kinds rotate. Trust the color." },
  { name: "Deep Assay", briefing: "Dense field. Stay in range." },
  { name: "White Noise", briefing: "All four, all at once." },
  { name: "Copper Hymn", briefing: "Alloy hymn. Thermal choir." },
  { name: "Void Orchard", briefing: "They split like fruit." },
  { name: "Shatter Line", briefing: "One miss feeds the well." },
  { name: "Last Meridian", briefing: "Titans plus swarm." },
  { name: "Iron Bloom", briefing: "Heavy metal rain." },
  { name: "Ghost Lattice", briefing: "Pale rocks, hard match." },
  { name: "Solar Ruin", briefing: "Heat and speed." },
  { name: "Frozen Choir", briefing: "Cryo wall. Do not stall." },
  { name: "Apex Drift", briefing: "The belt peaks." },
  { name: "Null Harbor", briefing: "Quiet, then too many." },
  { name: "Burning Vale", briefing: "Thermal storm." },
  { name: "Quiet Titan", briefing: "One giant, then the swarm." },
  { name: "Far Spectrum", briefing: "All colors, no mercy." },
  { name: "Broken Halo", briefing: "Range is tight. Count is not." },
  { name: "Absolute Belt", briefing: "Last sector. Clear it fast." },
];

const ALL_KINDS: AsteroidKind[] = ["basalt", "rime", "quartz", "alloy"];

function kindsFor(id: number): AsteroidKind[] {
  if (id === 1) return ["basalt"];
  if (id === 2) return ["rime"];
  if (id === 3) return ["basalt", "rime"];
  if (id === 4) return ["quartz"];
  if (id === 5) return ["alloy"];
  if (id <= 8) return ALL_KINDS;
  if (id % 11 === 0) return ["quartz", "alloy"];
  if (id % 7 === 0) return ["basalt", "alloy"];
  if (id % 5 === 0) return ["rime", "quartz"];
  if (id % 4 === 0) return ["basalt", "rime", "quartz"];
  return ALL_KINDS;
}

function musicIdFor(id: number): string {
  const named = [
    "shale",
    "rime",
    "twin",
    "quartz",
    "alloy",
    "fourfold",
    "splinter",
    "halo",
    "titan",
    "gauntlet",
  ];
  return named[id - 1] ?? `sec-${id}`;
}

export const LEVELS: LevelDef[] = LEVEL_META.map((meta, i) => {
  const id = i + 1;
  const large = Math.min(14, 3 + Math.ceil(id / 4));
  const speed = Math.round(32 + Math.min(46, id * 0.7 + Math.max(0, id - 16) * 0.22));
  return {
    id,
    name: meta.name,
    briefing: meta.briefing,
    kinds: kindsFor(id),
    large,
    speed,
    titan: id === 9 || id === 50 || (id >= 18 && id % 9 === 0),
    music: musicIdFor(id),
  };
});

const SCALES: number[][] = [
  [0, 2, 3, 5, 7, 9, 10, 12],
  [0, 1, 3, 5, 7, 8, 10, 12],
  [0, 2, 4, 7, 9, 11, 12, 14],
  [0, 3, 5, 7, 10, 12, 15],
  [0, 2, 5, 7, 9, 12, 14],
  [0, 1, 3, 6, 7, 9, 12, 13],
  [0, 4, 7, 11, 12, 16, 19],
  [0, 3, 7, 10, 12, 15, 19, 22],
];

const ROOTS = [36.71, 41.2, 49, 55, 61.74, 65.41, 73.42, 82.41, 87.31, 92.5, 98, 110];
const WAVES: OscillatorType[] = ["sine", "triangle", "square", "sawtooth"];

function lcg(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function drumPat(rand: () => number, steps: number, density: number): string {
  let out = "";
  for (let i = 0; i < steps; i++) {
    const onBeat = i % 4 === 0;
    const chance = onBeat ? density + 0.35 : density;
    out += rand() < chance ? "x" : "-";
  }
  return out;
}

function seq(rand: () => number, steps: number, density: number, maxIdx: number): number[] {
  const out: number[] = [];
  for (let i = 0; i < steps; i++) {
    out.push(rand() < density ? Math.floor(rand() * maxIdx) : R);
  }
  return out;
}

function makeMusic(id: string, seed: number, title: string, bpmBias = 0): MusicProfile {
  const rand = lcg(seed || 1);
  const steps = seed % 7 === 0 ? 12 : 16;
  const scale = SCALES[seed % SCALES.length]!;
  const bpm = Math.max(58, Math.min(164, 68 + (seed * 11) % 92 + bpmBias));
  const leadWave = WAVES[seed % WAVES.length]!;
  const bassWave = WAVES[(seed + 2) % WAVES.length]!;
  const maxIdx = Math.min(7, scale.length);
  const kick = seed % 9 !== 2;
  const snare = seed % 5 !== 0;
  const hats = seed % 8 !== 3;
  return {
    id,
    title,
    bpm,
    steps,
    rootHz: ROOTS[seed % ROOTS.length]!,
    scale,
    chords: [
      [0, 2, 4],
      [1, 3, 5],
      [0, 2, 3],
      [2, 4, 6].map((n) => n % maxIdx),
    ],
    bass: seq(rand, steps, 0.42, Math.min(5, maxIdx)),
    lead: seq(rand, steps, 0.5, maxIdx),
    arp: seq(rand, steps, 0.72, maxIdx),
    leadWave,
    bassWave,
    leadGain: 0.028 + (seed % 5) * 0.006,
    bassGain: 0.05 + (seed % 4) * 0.012,
    arpGain: 0.016 + (seed % 3) * 0.004,
    padGain: 0.024 + (seed % 4) * 0.006,
    noteFrac: 0.28 + (seed % 6) * 0.12,
    filterHz: 700 + (seed % 9) * 180,
    delay: 0.1 + (seed % 8) * 0.05,
    swing: (seed % 6) * 0.025,
    kick,
    snare,
    hats,
    kickG: drumPat(rand, steps, kick ? 0.22 : 0),
    snareG: drumPat(rand, steps, snare ? 0.14 : 0),
    hatG: drumPat(rand, steps, hats ? 0.45 : 0),
  };
}

function handMusic(): Record<string, MusicProfile> {
  const shale: MusicProfile = {
    id: "shale",
    title: "Shale Drift",
    bpm: 86,
    steps: 16,
    rootHz: 73.42,
    scale: [0, 2, 3, 5, 7, 9, 10, 12],
    chords: [[0, 2, 4], [3, 5, 7], [0, 2, 4], [2, 4, 6]],
    bass: [0, R, R, 0, R, R, 3, R, 0, R, 0, R, 4, R, 3, R],
    lead: [4, R, 5, 4, R, 2, R, 0, 4, R, 7, 5, R, 4, 2, R],
    arp: [0, 2, 4, 0, 2, 4, 7, 4, 0, 2, 4, 0, 3, 5, 4, 2],
    leadWave: "triangle",
    bassWave: "sine",
    leadGain: 0.055,
    bassGain: 0.08,
    arpGain: 0.022,
    padGain: 0.04,
    noteFrac: 0.72,
    filterHz: 1100,
    delay: 0.22,
    swing: 0.08,
    kick: true,
    snare: true,
    hats: true,
  };
  return {
    title: {
      id: "title",
      title: "Idle Field",
      bpm: 52,
      steps: 16,
      rootHz: 55,
      scale: [0, 3, 7, 10, 12, 15, 19],
      chords: [[0, 2, 4], [0, 2, 3], [1, 2, 4], [0, 2, 4]],
      bass: [0, R, R, R, R, R, R, R, 3, R, R, R, R, R, R, R],
      lead: [4, R, R, R, 6, R, R, R, 5, R, R, R, 4, R, 2, R],
      arp: [0, 2, 4, 2, 0, 2, 4, 6, 0, 2, 4, 2, 3, 2, 0, 2],
      leadWave: "sine",
      bassWave: "sine",
      leadGain: 0.04,
      bassGain: 0.07,
      arpGain: 0.018,
      padGain: 0.045,
      noteFrac: 2.2,
      filterHz: 900,
      delay: 0.46,
      swing: 0,
      kick: false,
      snare: false,
      hats: false,
    },
    shale,
    rime: makeMusic("rime", 2, "Rime Wake", 10),
    twin: makeMusic("twin", 3, "Twin Belt", 16),
    quartz: makeMusic("quartz", 4, "Quartz Vein", 28),
    alloy: makeMusic("alloy", 5, "Alloy Rain", 8),
    fourfold: makeMusic("fourfold", 6, "Fourfold", 22),
    splinter: makeMusic("splinter", 7, "Splinter Field", 44),
    halo: makeMusic("halo", 8, "Dense Halo", -8),
    titan: makeMusic("titan", 9, "Titan Core", -28),
    gauntlet: makeMusic("gauntlet", 10, "Prism Gauntlet", 48),
    drift0: makeMusic("drift0", 101, "Open Drift", 12),
    drift1: makeMusic("drift1", 102, "Deep Drift", 26),
    drift2: makeMusic("drift2", 103, "Far Drift", -12),
  };
}

export const MUSIC: Record<string, MusicProfile> = {
  ...handMusic(),
};

for (const lvl of LEVELS) {
  if (!MUSIC[lvl.music]) {
    MUSIC[lvl.music] = makeMusic(lvl.music, lvl.id * 17 + 4, lvl.name, (lvl.id % 9) * 3);
  }
}

export const INFINITE_MUSIC = [
  "drift0",
  "drift1",
  "drift2",
  "fourfold",
  "splinter",
  "gauntlet",
  "sec-22",
  "sec-36",
  "sec-44",
] as const;

export const WEAPON_INTRO: Record<WeaponId, number> = {
  kinetic: 1,
  cryo: 2,
  resonant: 4,
  thermal: 5,
};

export function unlockedWeapons(campaignReached: number): WeaponId[] {
  const order: WeaponId[] = ["kinetic", "cryo", "resonant", "thermal"];
  return order.filter((w) => campaignReached >= WEAPON_INTRO[w]);
}

export function infiniteMusicId(wave: number): string {
  return INFINITE_MUSIC[(wave - 1) % INFINITE_MUSIC.length] ?? "drift0";
}

export function infiniteBpm(wave: number, base: number): number {
  return Math.min(168, base + Math.max(0, wave - 1) * 3);
}

export function formatTime(ms: number): string {
  const clamped = Math.max(0, Math.floor(ms));
  const m = Math.floor(clamped / 60000);
  const s = Math.floor((clamped % 60000) / 1000);
  const cs = Math.floor((clamped % 1000) / 10);
  if (m > 0) return `${m}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
  return `${s}.${String(cs).padStart(2, "0")}s`;
}
