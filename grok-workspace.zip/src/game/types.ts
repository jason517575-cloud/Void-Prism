export type WeaponId = "kinetic" | "cryo" | "resonant" | "thermal";
export type AsteroidKind = "basalt" | "rime" | "quartz" | "alloy";
export type PlayMode = "campaign" | "infinite" | "attract" | "custom";
export type SizeClass = "titan" | "large" | "medium" | "small";

export type Asteroid = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  spin: number;
  angle: number;
  r: number;
  kind: AsteroidKind;
  size: SizeClass;
  verts: number[];
  seed: number;
  hitFlash: number;
  lucky: boolean;
  drop?: DropId;
};

export type Beam = {
  alive: boolean;
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  life: number;
  max: number;
  weapon: WeaponId;
  matched: boolean;
  tint: string;
};

export type Particle = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  size: number;
  color: string;
  glow: boolean;
};

export type Floater = {
  alive: boolean;
  x: number;
  y: number;
  vy: number;
  life: number;
  max: number;
  text: string;
  color: string;
};

export type MusicProfile = {
  id: string;
  title: string;
  bpm: number;
  steps: number;
  rootHz: number;
  scale: number[];
  chords: number[][];
  bass: number[];
  lead: number[];
  arp: number[];
  leadWave: OscillatorType;
  bassWave: OscillatorType;
  leadGain: number;
  bassGain: number;
  arpGain: number;
  padGain: number;
  noteFrac: number;
  filterHz: number;
  delay: number;
  swing: number;
  kick: boolean;
  snare: boolean;
  hats: boolean;
  kickG?: string;
  snareG?: string;
  hatG?: string;
};

export type DropId = "aegis" | "ward" | "overcharge" | "bomb" | "frag2x";
export type SkinId = string;

export type HudSnap = {
  score: number;
  lives: number;
  combo: number;
  multiplier: number;
  weapon: WeaponId;
  unlocked: WeaponId[];
  levelName: string;
  levelId: number;
  remaining: number;
  wave: number;
  mode: PlayMode;
  briefing: string;
  briefingT: number;
  shake: boolean;
  muted: boolean;
  sessionFrags: number;
  aegisT: number;
  ward: number;
  overchargeT: number;
  fragMulT: number;
  waveClearT: number;
  reach: number;
  playTime: number;
};

export type LevelDef = {
  id: number;
  name: string;
  briefing: string;
  kinds: AsteroidKind[];
  large: number;
  speed: number;
  titan?: boolean;
  music: string;
};
