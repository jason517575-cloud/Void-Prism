import { LUCKY_COLOR } from "./config";
import type { BeamStyle, RockCut } from "./cosmetics";
import type {
  Asteroid,
  AsteroidKind,
  Beam,
  Floater,
  Particle,
  WeaponId,
} from "./types";

export type DrawWorld = {
  w: number;
  h: number;
  coreX: number;
  coreY: number;
  coreR: number;
  coreInvuln: number;
  asteroids: Asteroid[];
  beams: Beam[];
  particles: Particle[];
  floaters: Floater[];
  weapon: WeaponId;
  hover: Asteroid | null;
  pointer: { x: number; y: number } | null;
  shakeX: number;
  shakeY: number;
  shakeRot: number;
  flash: number;
  stars: { x: number; y: number; z: number; s: number }[];
  showCore: boolean;
  reach: number;
  aegisT: number;
  ward: number;
  overchargeT: number;
  skinCore: string;
  skinBeam: string;
  kindColors: Record<AsteroidKind, string>;
  weaponColors: Record<WeaponId, string>;
  beamStyle: BeamStyle;
  beamWidth: number;
  beamGlow: number;
  rockFill: number;
  rockCut: RockCut;
  backdrop?: string;
  bgImage?: CanvasImageSource | null;
};

function wrapDraw(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  x: number,
  y: number,
  r: number,
  fn: (x: number, y: number) => void,
) {
  const pads: [number, number][] = [[0, 0]];
  if (x < r) pads.push([w, 0]);
  if (x > w - r) pads.push([-w, 0]);
  if (y < r) pads.push([0, h]);
  if (y > h - r) pads.push([0, -h]);
  if (x < r && y < r) pads.push([w, h]);
  if (x > w - r && y < r) pads.push([-w, h]);
  if (x < r && y > h - r) pads.push([w, -h]);
  if (x > w - r && y > h - r) pads.push([-w, -h]);
  for (const [ox, oy] of pads) fn(x + ox, y + oy);
}

function asteroidPath(
  ctx: CanvasRenderingContext2D,
  a: Asteroid,
  x: number,
  y: number,
) {
  const n = a.verts.length;
  ctx.beginPath();
  for (let i = 0; i < n; i++) {
    const ang = a.angle + (i / n) * Math.PI * 2;
    const rr = a.r * (a.verts[i] ?? 1);
    const px = x + Math.cos(ang) * rr;
    const py = y + Math.sin(ang) * rr;
    if (i === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.closePath();
}

function drawAsteroid(
  ctx: CanvasRenderingContext2D,
  a: Asteroid,
  x: number,
  y: number,
  col: string,
  fill: number,
  cut: RockCut,
) {
  const flash = a.hitFlash > 0 ? Math.min(1, a.hitFlash * 8) : 0;
  ctx.save();
  ctx.strokeStyle = flash ? "#f4f4f0" : col;
  ctx.lineWidth = a.size === "titan" ? 2.4 : cut === "plate" ? 2.2 : 1.6;
  ctx.globalAlpha = 0.95;
  asteroidPath(ctx, a, x, y);
  ctx.stroke();
  ctx.globalAlpha = fill + flash * 0.2;
  ctx.fillStyle = col;
  ctx.fill();

  if (a.lucky) {
    ctx.globalAlpha = 0.8;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const ang = a.angle + (i / 5) * Math.PI * 2 - Math.PI / 2;
      const rr = i % 2 === 0 ? a.r * 0.42 : a.r * 0.18;
      const px = x + Math.cos(ang) * rr;
      const py = y + Math.sin(ang) * rr;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
    return;
  }

  if (cut === "ice" || a.kind === "rime") {
    ctx.globalAlpha = 0.55;
    ctx.beginPath();
    ctx.arc(x, y, a.r * 0.38, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x - a.r * 0.45, y);
    ctx.lineTo(x + a.r * 0.45, y);
    ctx.moveTo(x, y - a.r * 0.45);
    ctx.lineTo(x, y + a.r * 0.45);
    ctx.stroke();
  } else if (cut === "crystal" || a.kind === "quartz") {
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    const inner = a.r * 0.42;
    for (let i = 0; i < 3; i++) {
      const ang = a.angle + (i / 3) * Math.PI * 2;
      const px = x + Math.cos(ang) * inner;
      const py = y + Math.sin(ang) * inner;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.stroke();
  } else if (cut === "plate" || a.kind === "alloy") {
    ctx.globalAlpha = 0.5;
    ctx.strokeRect(x - a.r * 0.28, y - a.r * 0.28, a.r * 0.56, a.r * 0.56);
  } else if (cut === "ember") {
    ctx.globalAlpha = 0.28;
    ctx.beginPath();
    ctx.arc(x, y, a.r * 0.32, 0, Math.PI * 2);
    ctx.fill();
  } else {
    ctx.globalAlpha = 0.35;
    ctx.beginPath();
    ctx.arc(x + a.r * 0.15, y - a.r * 0.1, a.r * 0.22, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

function drawCore(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  tint: string,
  invuln: number,
  aegisT: number,
  ward: number,
) {
  const col = tint;
  const hide = invuln > 0 && Math.floor(invuln * 16) % 2 === 0 && aegisT <= 0;
  if (hide) return;
  if (aegisT > 0) {
    ctx.save();
    ctx.strokeStyle = LUCKY_COLOR;
    ctx.globalAlpha = 0.35 + 0.25 * Math.sin(aegisT * 8);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y, r + 16, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 0.12;
    ctx.fillStyle = LUCKY_COLOR;
    ctx.fill();
    ctx.restore();
  } else if (ward > 0) {
    ctx.save();
    ctx.strokeStyle = "#c5cdd8";
    ctx.globalAlpha = 0.55;
    ctx.lineWidth = 1.6;
    ctx.setLineDash([5, 4]);
    ctx.beginPath();
    ctx.arc(x, y, r + 14, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }
  ctx.save();
  ctx.shadowColor = col;
  ctx.shadowBlur = 18;
  ctx.strokeStyle = "#ecece8";
  ctx.fillStyle = col;
  ctx.lineWidth = 1.8;
  ctx.beginPath();
  ctx.moveTo(x, y - r);
  ctx.lineTo(x + r * 0.78, y);
  ctx.lineTo(x, y + r * 0.72);
  ctx.lineTo(x - r * 0.78, y);
  ctx.closePath();
  ctx.globalAlpha = 0.18;
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x, y - r * 0.42);
  ctx.lineTo(x + r * 0.32, y);
  ctx.lineTo(x, y + r * 0.28);
  ctx.lineTo(x - r * 0.32, y);
  ctx.closePath();
  ctx.strokeStyle = col;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x, y, 2.4, 0, Math.PI * 2);
  ctx.fillStyle = col;
  ctx.fill();
  ctx.restore();
}

function drawBeam(
  ctx: CanvasRenderingContext2D,
  beam: Beam,
  col: string,
  style: BeamStyle,
  width: number,
  glow: number,
) {
  const a = beam.life / beam.max;
  const w = (beam.matched ? width : width * 0.55) * (0.7 + a * 0.3);
  ctx.save();
  ctx.strokeStyle = col;
  ctx.shadowColor = col;
  ctx.shadowBlur = Math.min(6, glow);
  ctx.lineCap = "round";
  if (style === "dash") ctx.setLineDash([8, 7]);
  ctx.globalAlpha = 0.28 + a * 0.72;
  ctx.lineWidth = w;
  ctx.beginPath();
  ctx.moveTo(beam.x0, beam.y0);
  ctx.lineTo(beam.x1, beam.y1);
  ctx.stroke();
  if (style === "double") {
    ctx.globalAlpha = a * 0.45;
    ctx.lineWidth = w * 2.4;
    ctx.stroke();
    ctx.globalAlpha = 0.9;
    ctx.lineWidth = Math.max(1, w * 0.45);
    ctx.stroke();
  } else if (style === "ribbon") {
    ctx.globalAlpha = a * 0.35;
    ctx.lineWidth = w * 3.2;
    ctx.stroke();
  } else if (style === "pulse") {
    ctx.globalAlpha = a * (0.35 + 0.25 * Math.sin(a * 18));
    ctx.lineWidth = w * 2.8;
    ctx.stroke();
  } else if (style === "spark") {
    ctx.globalAlpha = a * 0.9;
    const mx = (beam.x0 + beam.x1) / 2;
    const my = (beam.y0 + beam.y1) / 2;
    const dx = beam.x1 - beam.x0;
    const dy = beam.y1 - beam.y0;
    const len = Math.hypot(dx, dy) || 1;
    const nx = -dy / len;
    const ny = dx / len;
    ctx.beginPath();
    ctx.moveTo(mx + nx * 7, my + ny * 7);
    ctx.lineTo(mx - nx * 7, my - ny * 7);
    ctx.lineWidth = 1.4;
    ctx.stroke();
  }
  ctx.globalAlpha = a * 0.45;
  ctx.lineWidth = beam.matched ? w * 2.6 : w * 1.8;
  ctx.stroke();
  ctx.restore();
}

export function renderWorld(ctx: CanvasRenderingContext2D, world: DrawWorld) {
  const { w, h } = world;
  ctx.save();
  ctx.translate(world.shakeX, world.shakeY);
  ctx.rotate(world.shakeRot);

  ctx.fillStyle = "#08080a";
  ctx.fillRect(-20, -20, w + 40, h + 40);

  if (world.bgImage) {
    const img = world.bgImage as CanvasImageSource & { width?: number; height?: number };
    const iw = img.width || w;
    const ih = img.height || h;
    const scale = Math.max(w / iw, h / ih);
    const dw = iw * scale;
    const dh = ih * scale;
    ctx.globalAlpha = 0.55;
    ctx.drawImage(world.bgImage, (w - dw) / 2, (h - dh) / 2, dw, dh);
    ctx.globalAlpha = 1;
  } else {
    const preset = world.backdrop ?? "void";
    const tint =
      preset === "nebula"
        ? "rgba(70, 40, 110, 0.55)"
        : preset === "dusk"
          ? "rgba(120, 60, 30, 0.45)"
          : preset === "ice"
            ? "rgba(30, 90, 110, 0.45)"
            : preset === "ember"
              ? "rgba(140, 40, 20, 0.4)"
              : "rgba(18, 22, 28, 0.55)";
    const g = ctx.createRadialGradient(w * 0.5, h * 0.42, 20, w * 0.5, h * 0.5, h * 0.78);
    g.addColorStop(0, tint);
    g.addColorStop(1, "rgba(8, 8, 10, 0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
  }

  for (const s of world.stars) {
    ctx.globalAlpha = 0.25 + s.z * 0.7;
    ctx.fillStyle = s.z > 0.7 ? "#ecece8" : "#8a8a92";
    ctx.fillRect(s.x, s.y, s.s, s.s);
  }
  ctx.globalAlpha = 1;

  for (const p of world.particles) {
    if (!p.alive) continue;
    const a = p.life / p.max;
    ctx.globalAlpha = a;
    ctx.fillStyle = p.color;
    ctx.fillRect(p.x, p.y, p.size, p.size);
  }
  ctx.globalAlpha = 1;

  for (const beam of world.beams) {
    if (!beam.alive) continue;
    const col =
      world.overchargeT > 0 ? LUCKY_COLOR : beam.tint || world.weaponColors[beam.weapon];
    drawBeam(ctx, beam, col, world.beamStyle, world.beamWidth, world.beamGlow);
  }

  if (world.showCore && world.reach > 0) {
    ctx.save();
    ctx.strokeStyle = world.skinCore;
    ctx.globalAlpha = 0.18;
    ctx.lineWidth = 1.2;
    ctx.setLineDash([6, 10]);
    ctx.beginPath();
    ctx.arc(world.coreX, world.coreY, world.reach, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  for (const a of world.asteroids) {
    wrapDraw(ctx, w, h, a.x, a.y, a.r + 8, (x, y) =>
      drawAsteroid(
        ctx,
        a,
        x,
        y,
        a.lucky ? LUCKY_COLOR : world.kindColors[a.kind],
        world.rockFill,
        world.rockCut,
      ),
    );
  }

  if (world.hover) {
    const a = world.hover;
    const dx = a.x - world.coreX;
    const dy = a.y - world.coreY;
    const inR = Math.hypot(dx, dy) <= world.reach + 6;
    const col =
      a.lucky || world.overchargeT > 0 ? LUCKY_COLOR : world.kindColors[a.kind];
    ctx.save();
    ctx.strokeStyle = inR ? col : "#c45c4a";
    ctx.globalAlpha = 0.7;
    ctx.lineWidth = 1.4;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.arc(a.x, a.y, a.r + 8, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  if (world.showCore) {
    drawCore(
      ctx,
      world.coreX,
      world.coreY,
      world.coreR,
      world.skinCore,
      world.coreInvuln,
      world.aegisT,
      world.ward,
    );
  }

  if (world.pointer && world.showCore) {
    const col = world.overchargeT > 0 ? LUCKY_COLOR : world.weaponColors[world.weapon];
    ctx.save();
    ctx.strokeStyle = col;
    ctx.globalAlpha = 0.7;
    ctx.lineWidth = 1.2;
    ctx.beginPath();
    ctx.arc(world.pointer.x, world.pointer.y, 9, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(world.pointer.x - 13, world.pointer.y);
    ctx.lineTo(world.pointer.x - 4, world.pointer.y);
    ctx.moveTo(world.pointer.x + 4, world.pointer.y);
    ctx.lineTo(world.pointer.x + 13, world.pointer.y);
    ctx.moveTo(world.pointer.x, world.pointer.y - 13);
    ctx.lineTo(world.pointer.x, world.pointer.y - 4);
    ctx.moveTo(world.pointer.x, world.pointer.y + 4);
    ctx.lineTo(world.pointer.x, world.pointer.y + 13);
    ctx.stroke();
    ctx.restore();
  }

  ctx.font = "600 13px 'IBM Plex Sans', sans-serif";
  ctx.textAlign = "center";
  for (const f of world.floaters) {
    if (!f.alive) continue;
    ctx.globalAlpha = Math.min(1, f.life / (f.max * 0.4));
    ctx.fillStyle = f.color;
    ctx.fillText(f.text, f.x, f.y);
  }
  ctx.globalAlpha = 1;

  if (world.flash > 0) {
    ctx.fillStyle = `rgba(236, 236, 232, ${world.flash * 0.18})`;
    ctx.fillRect(0, 0, w, h);
  }
  ctx.restore();
}
