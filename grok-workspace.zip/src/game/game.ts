import {
  AEGIS_T,
  BOMB_R,
  CLICK_PAD,
  CORE_INVULN,
  campaignPayout,
  CORE_R,
  DROP_LABEL,
  DROPS,
  FIRE_COOLDOWN,
  FIXED,
  FRAG2X_T,
  GAME_KEYS,
  LEVELS,
  LUCKY_CHANCE,
  LUCKY_COLOR,
  LUCKY_MAX,
  MATCH,
  OVERCHARGE_T,
  REACH_FRAC,
  SIZE_FRAG,
  SIZE_R,
  SIZE_SCORE,
  START_LIVES,
  WEAPON_ORDER,
  livePalette,
  skinById,
  unlockedWeapons,
  type LivePalette,
  type SkinDef,
} from "./config";
import {
  playFileMusic,
  playInfiniteMusic,
  playLevelMusic,
  playTitleMusic,
  resumeAudio,
  sfxBomb,
  sfxClear,
  sfxDead,
  sfxExplode,
  sfxHit,
  sfxLucky,
  sfxPower,
  sfxResist,
  sfxShoot,
  sfxSwitch,
} from "./audio";
import type { CustomLevelDef } from "./custom-level";
import { renderWorld } from "./render";
import type {
  Asteroid,
  AsteroidKind,
  Beam,
  DropId,
  Floater,
  HudSnap,
  Particle,
  PlayMode,
  SizeClass,
  SkinId,
  WeaponId,
} from "./types";

export type GameHandle = {
  start: () => void;
  destroy: () => void;
  pause: () => void;
  resume: () => void;
  setWeapon: (w: WeaponId) => void;
  cycleWeapon: (dir: number) => void;
  setTimeScale: (n: number) => void;
  getHud: () => HudSnap;
  subscribe: (fn: () => void) => () => void;
};

type Opts = {
  mode: PlayMode;
  levelIndex: number;
  campaignReached: number;
  shakeEnabled: boolean;
  muted: boolean;
  skinId: SkinId;
  laserId: string;
  packId: string;
  timeScale?: number;
  custom?: CustomLevelDef | null;
  customEarn?: boolean;
  godMode?: boolean;
  onHud: (h: HudSnap) => void;
  onLevelClear: (score: number, timeMs: number) => void;
  onCustomClear?: (score: number, timeMs: number) => void;
  onGameOver: (score: number, wave: number) => void;
  onVictory: (score: number, timeMs: number) => void;
  onWave: (wave: number) => void;
  onFragments: (delta: number) => void;
  onPause?: () => void;
};

function rand(a: number, b: number) {
  return a + Math.random() * (b - a);
}

function wrap(v: number, max: number) {
  if (v < 0) return v + max;
  if (v >= max) return v - max;
  return v;
}

function wrapDelta(a: number, b: number, size: number) {
  let d = a - b;
  if (d > size * 0.5) d -= size;
  if (d < -size * 0.5) d += size;
  return d;
}

function makeVerts(kind: AsteroidKind, n: number, cut: LivePalette["pack"]["cut"]) {
  const verts: number[] = [];
  for (let i = 0; i < n; i++) {
    let jag: number;
    if (cut === "plate") jag = rand(0.9, 1.04);
    else if (cut === "cut") jag = rand(0.82, 1.08);
    else if (cut === "crystal") jag = i % 2 === 0 ? rand(1.02, 1.2) : rand(0.62, 0.82);
    else if (cut === "ice") jag = rand(0.86, 1.06);
    else if (cut === "ember") jag = rand(0.74, 1.16);
    else
      jag =
        kind === "alloy"
          ? rand(0.88, 1.05)
          : kind === "quartz"
            ? rand(0.72, 1.18)
            : kind === "rime"
              ? rand(0.84, 1.08)
              : rand(0.7, 1.2);
    verts.push(jag);
  }
  return verts;
}

function nextSize(s: SizeClass): SizeClass | null {
  if (s === "titan" || s === "large") return "medium";
  if (s === "medium") return "small";
  return null;
}

export function createGame(canvas: HTMLCanvasElement, opts: Opts): GameHandle {
  const maybeCtx = canvas.getContext("2d", { alpha: false }) ?? canvas.getContext("2d");
  if (!maybeCtx) {
    throw new Error("Canvas 2D is not available");
  }
  const ctx: CanvasRenderingContext2D = maybeCtx;

  let w = 800;
  let h = 600;
  let coreX = 400;
  let coreY = 540;
  let running = false;
  let disposed = false;
  let paused = false;
  let raf = 0;
  let acc = 0;
  let last = 0;
  let fireCd = 0;
  let score = 0;
  let lives = START_LIVES;
  let combo = 0;
  let remaining = 0;
  let wave = 1;
  let trauma = 0;
  let flash = 0;
  let freeze = 0;
  let briefingT = 2.6;
  let ended = false;
  let coreInvuln = 0;
  let sessionFrags = 0;
  let luckySpawned = 0;
  let aegisT = 0;
  let ward = 0;
  let overchargeT = 0;
  let fragMulT = 0;
  let waveClearT = 0;
  let pendingNextWave = false;
  let playTime = 0;
  const skin: SkinDef = skinById(opts.skinId);
  const pal = livePalette(opts.laserId, opts.packId);
  const customBelt = opts.mode === "custom" ? opts.custom : null;
  let bgImg: CanvasImageSource | null = null;
  if (customBelt?.bg === "custom" && customBelt.bgData && typeof Image !== "undefined") {
    const img = new Image();
    img.onload = () => {
      if (disposed) return;
      const iw = img.naturalWidth || img.width || 1;
      const ih = img.naturalHeight || img.height || 1;
      const max = 960;
      if (iw <= max && ih <= max) {
        bgImg = img;
        return;
      }
      const scale = max / Math.max(iw, ih);
      const c = document.createElement("canvas");
      c.width = Math.max(1, Math.round(iw * scale));
      c.height = Math.max(1, Math.round(ih * scale));
      const g = c.getContext("2d");
      if (!g) {
        bgImg = img;
        return;
      }
      g.drawImage(img, 0, 0, c.width, c.height);
      bgImg = c;
    };
    img.src = customBelt.bgData;
  }
  let timeScale = opts.timeScale === 2 ? 2 : 1;
  let weapon: WeaponId = "kinetic";
  const unlocked: WeaponId[] =
    opts.mode === "infinite" || opts.mode === "custom"
      ? [...WEAPON_ORDER]
      : unlockedWeapons(opts.campaignReached);
  if (!unlocked.includes(weapon)) weapon = unlocked[0] ?? "kinetic";

  const keys = new Set<string>();
  let listenersOn = false;
  let padPrev = { bumpL: false, bumpR: false, start: false };
  let pointer: { x: number; y: number } | null = null;
  let hover: Asteroid | null = null;

  const asteroids: Asteroid[] = [];
  const beams: Beam[] = Array.from({ length: 24 }, () => ({
    alive: false,
    x0: 0,
    y0: 0,
    x1: 0,
    y1: 0,
    life: 0,
    max: 0.12,
    weapon: "kinetic" as WeaponId,
    matched: false,
    tint: "#ecece8",
  }));
  const particles: Particle[] = Array.from({ length: 72 }, () => ({
    alive: false,
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    life: 0,
    max: 1,
    size: 1,
    color: "#ecece8",
    glow: false,
  }));
  const floaters: Floater[] = Array.from({ length: 40 }, () => ({
    alive: false,
    x: 0,
    y: 0,
    vy: 0,
    life: 0,
    max: 1,
    text: "",
    color: "#ecece8",
  }));
  let stars: { x: number; y: number; z: number; s: number }[] = [];
  let starW = 0;
  let starH = 0;
  let hudClock = 0;
  let resizeObserver: ResizeObserver | null = null;

  const level = LEVELS[Math.max(0, opts.levelIndex)] ?? LEVELS[0];
  const hudListeners = new Set<() => void>();

  function emitHud() {
    opts.onHud(getHud());
    hudListeners.forEach((fn) => fn());
  }

  function getHud(): HudSnap {
    return {
      score,
      lives,
      combo,
      multiplier: 1 + Math.min(4, Math.floor(combo / 4)),
      weapon,
      unlocked,
      levelName:
        opts.mode === "infinite"
          ? `Wave ${wave}`
          : opts.mode === "custom"
            ? (opts.custom?.name ?? "Custom")
            : opts.mode === "attract"
              ? "VOID PRISM"
              : (level?.name ?? ""),
      levelId: opts.mode === "custom" ? 0 : (level?.id ?? 0),
      remaining,
      wave,
      mode: opts.mode,
      briefing:
        opts.mode === "campaign"
          ? (level?.briefing ?? "")
          : opts.mode === "custom"
            ? (opts.custom?.briefing ?? "")
            : "Click in range. Lucky rocks drop gear.",
      briefingT,
      shake: opts.shakeEnabled,
      muted: opts.muted,
      sessionFrags,
      aegisT,
      ward,
      overchargeT,
      fragMulT,
      waveClearT,
      reach: reachR(),
      playTime,
    };
  }

  function reachR() {
    return Math.min(w, h) * REACH_FRAC;
  }

  function resize() {
    const prevW = w;
    const prevH = h;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.25);
    const rect = canvas.getBoundingClientRect();
    w = Math.max(1, Math.floor(rect.width));
    h = Math.max(1, Math.floor(rect.height));
    const nextW = Math.max(1, Math.floor(w * dpr));
    const nextH = Math.max(1, Math.floor(h * dpr));
    if (canvas.width !== nextW || canvas.height !== nextH) {
      canvas.width = nextW;
      canvas.height = nextH;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    coreX = w * 0.5;
    coreY = h * 0.48;
    if (asteroids.length && prevW > 8 && prevH > 8 && (prevW !== w || prevH !== h)) {
      const sx = w / prevW;
      const sy = h / prevH;
      for (const a of asteroids) {
        a.x *= sx;
        a.y *= sy;
      }
    }
    if (Math.abs(starW - w) > 8 || Math.abs(starH - h) > 8) {
      starW = w;
      starH = h;
      stars = Array.from({ length: 42 }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        z: Math.random(),
        s: Math.random() < 0.2 ? 2 : 1,
      }));
    }
  }

  function spawnParticle(
    x: number,
    y: number,
    color: string,
    n: number,
    speed: number,
    glow: boolean,
  ) {
    let left = n;
    for (const p of particles) {
      if (left <= 0) break;
      if (p.alive) continue;
      const ang = Math.random() * Math.PI * 2;
      const sp = rand(speed * 0.2, speed);
      p.alive = true;
      p.x = x;
      p.y = y;
      p.vx = Math.cos(ang) * sp;
      p.vy = Math.sin(ang) * sp;
      p.max = rand(0.25, 0.7);
      p.life = p.max;
      p.size = rand(0.8, 2.4);
      p.color = color;
      p.glow = glow;
      left -= 1;
    }
  }

  function spawnFloater(x: number, y: number, text: string, color: string) {
    const f = floaters.find((it) => !it.alive);
    if (!f) return;
    f.alive = true;
    f.x = x;
    f.y = y;
    f.vy = -28;
    f.max = 0.85;
    f.life = f.max;
    f.text = text;
    f.color = color;
  }

  function spawnBeam(x1: number, y1: number, matched: boolean, tint?: string) {
    const slot = beams.find((b) => !b.alive);
    if (!slot) return;
    slot.alive = true;
    slot.x0 = coreX;
    slot.y0 = coreY;
    slot.x1 = x1;
    slot.y1 = y1;
    slot.max = matched ? 0.14 : 0.1;
    slot.life = slot.max;
    slot.weapon = weapon;
    slot.matched = matched;
    slot.tint = tint ?? pal.weapon[weapon];
  }

  function edgePoint(): { x: number; y: number } {
    const e = Math.floor(Math.random() * 3);
    if (e === 0) return { x: rand(40, w - 40), y: -16 };
    if (e === 1) return { x: -16, y: rand(20, h * 0.55) };
    return { x: w + 16, y: rand(20, h * 0.55) };
  }

  function spawnAsteroid(
    kind: AsteroidKind,
    size: SizeClass,
    x?: number,
    y?: number,
    vx?: number,
    vy?: number,
  ) {
    const pos = x === undefined || y === undefined ? edgePoint() : { x, y };
    if (opts.mode !== "attract") {
      const dx = pos.x - coreX;
      const dy = pos.y - coreY;
      if (Math.hypot(dx, dy) < 160) {
        const p2 = edgePoint();
        pos.x = p2.x;
        pos.y = p2.y;
      }
    }
    const speedMul = size === "small" ? 1.4 : size === "medium" ? 1.12 : 1;
    const spec = opts.mode === "infinite" ? infiniteSpec() : null;
    const base =
      opts.mode === "infinite"
        ? (spec?.speed ?? 22)
        : opts.mode === "custom"
          ? (opts.custom?.speed ?? 40)
          : opts.mode === "attract"
            ? 28
            : (level?.speed ?? 48);
    const spd = base * speedMul * rand(0.75, 1.15);
    const ang = Math.random() * Math.PI * 2;
    asteroids.push({
      x: pos.x,
      y: pos.y,
      vx: vx ?? Math.cos(ang) * spd,
      vy: vy ?? Math.sin(ang) * spd * 0.65 + spd * 0.25,
      spin: rand(-1.2, 1.2),
      angle: Math.random() * Math.PI * 2,
      r: SIZE_R[size],
      kind,
      size,
      verts: makeVerts(
        kind,
        size === "titan" ? 12 : kind === "alloy" ? 8 : kind === "quartz" ? 6 : 9,
        pal.pack.cut,
      ),
      seed: Math.random(),
      hitFlash: 0,
      lucky: false,
    });
  }

  function spawnLucky() {
    if (luckySpawned >= LUCKY_MAX) return;
    luckySpawned += 1;
    const pos = edgePoint();
    const spd = 26 + wave * 2;
    const ang = Math.random() * Math.PI * 2;
    asteroids.push({
      x: pos.x,
      y: pos.y,
      vx: Math.cos(ang) * spd,
      vy: Math.sin(ang) * spd * 0.5 + 18,
      spin: rand(-1.6, 1.6),
      angle: Math.random() * Math.PI * 2,
      r: 20,
      kind: "basalt",
      size: "medium",
      verts: makeVerts("quartz", 7, pal.pack.cut),
      seed: Math.random(),
      hitFlash: 0,
      lucky: true,
    });
  }

  function maybeLucky() {
    if (opts.mode === "attract") return;
    if (luckySpawned >= LUCKY_MAX) return;
    if (Math.random() > LUCKY_CHANCE) return;
    spawnLucky();
  }

  function infiniteSpec() {
    const kinds: AsteroidKind[] =
      wave <= 1
        ? ["basalt"]
        : wave === 2
          ? ["basalt", "rime"]
          : wave <= 4
            ? ["basalt", "rime", "quartz"]
            : ["basalt", "rime", "quartz", "alloy"];
    const count = Math.min(14, 3 + Math.floor(wave * 0.7));
    const speed = Math.min(78, 24 + wave * 1.15);
    const pull = Math.min(11, 3.2 + wave * 0.28);
    const titan = wave >= 6 && wave % 3 === 0;
    return { kinds, count, speed, pull, titan };
  }

  function seedField() {
    asteroids.length = 0;
    luckySpawned = 0;
    pendingNextWave = false;
    waveClearT = 0;
    if (opts.mode === "attract") {
      const kinds: AsteroidKind[] = ["basalt", "rime", "quartz", "alloy"];
      for (let i = 0; i < 8; i++) {
        spawnAsteroid(kinds[i % 4] as AsteroidKind, i % 3 === 0 ? "large" : "medium");
      }
      remaining = asteroids.length;
      return;
    }
    if (opts.mode === "infinite") {
      const spec = infiniteSpec();
      for (let i = 0; i < spec.count; i++) {
        const size: SizeClass = spec.titan && i < 2 ? "titan" : wave <= 2 ? "medium" : "large";
        spawnAsteroid(spec.kinds[i % spec.kinds.length] as AsteroidKind, size);
        maybeLucky();
      }
      remaining = asteroids.length;
      opts.onWave(wave);
      cueMusic(() => playInfiniteMusic(wave));
      briefingT = 1.8;
      return;
    }
    if (opts.mode === "custom" && opts.custom) {
      seedCustom(opts.custom);
      remaining = asteroids.length;
      briefingT = 1.6;
      const track = opts.custom;
      cueMusic(() => {
        if (track.music === "upload" && track.musicData) playFileMusic(track.musicData);
        else playLevelMusic(track.gameMusicId || "shale");
      });
      return;
    }
    const kinds = level?.kinds ?? ["basalt"];
    const n = level?.large ?? 4;
    for (let i = 0; i < n; i++) {
      const kind = kinds[i % kinds.length] as AsteroidKind;
      spawnAsteroid(kind, level?.titan ? "titan" : "large");
      maybeLucky();
    }
    remaining = asteroids.length;
    cueMusic(() => playLevelMusic(level?.music ?? "shale"));
  }

  function cueMusic(fn: () => void) {
    setTimeout(() => {
      if (!running || disposed) return;
      try {
        fn();
      } catch {
        /* audio must not block the belt */
      }
    }, 0);
  }

  function seedCustom(c: CustomLevelDef) {
    if (c.spawn === "placed") {
      for (const rock of c.rocks) {
        const x0 = rock.nx * w;
        const y0 = rock.ny * h;
        const dx = x0 - coreX;
        const dy = y0 - coreY;
        const dist = Math.hypot(dx, dy) || 1;
        const min = reachR() + 28;
        const x = dist < min ? coreX + (dx / dist) * min : x0;
        const y = dist < min ? coreY + (dy / dist) * min : y0;
        const ang = Math.atan2(coreY - y, coreX - x);
        const spd = c.speed;
        spawnAsteroid(
          rock.kind,
          rock.size,
          x,
          y,
          Math.cos(ang) * spd,
          Math.sin(ang) * spd,
        );
      }
    } else {
      const kinds = c.kinds.length ? c.kinds : (["basalt"] as AsteroidKind[]);
      for (let i = 0; i < c.count; i++) {
        const size = i % 6 === 0 ? "large" : "medium";
        spawnAsteroid(kinds[i % kinds.length]!, size);
      }
    }
    for (let i = 0; i < c.luckyCount; i++) {
      spawnLucky();
      const last = asteroids[asteroids.length - 1];
      if (last && c.lucky === "fixed" && c.luckyDrops.length) {
        last.drop = c.luckyDrops[i % c.luckyDrops.length];
      }
    }
  }

  function addScore(n: number, x: number, y: number) {
    const mul = 1 + Math.min(4, Math.floor(combo / 4));
    const got = n * mul;
    score += got;
    spawnFloater(x, y - 8, mul > 1 ? `${got} ×${mul}` : `${got}`, "#ecece8");
  }

  function addFrags(n: number, x: number, y: number) {
    if (opts.mode === "custom" || opts.customEarn === false) return;
    const got = Math.max(0, Math.round(n * (fragMulT > 0 ? 2 : 1)));
    if (got <= 0) return;
    sessionFrags += got;
    opts.onFragments(got);
    spawnFloater(x, y + 10, `+${got} FRAG`, LUCKY_COLOR);
  }

  function splitAsteroid(a: Asteroid) {
    const next = nextSize(a.size);
    const idx = asteroids.indexOf(a);
    if (idx >= 0) asteroids.splice(idx, 1);
    remaining = asteroids.length;
    if (!next) return;
    const kick = 70;
    const ang = Math.atan2(a.vy, a.vx);
    spawnAsteroid(
      a.kind,
      next,
      a.x,
      a.y,
      a.vx + Math.cos(ang + 0.9) * kick,
      a.vy + Math.sin(ang + 0.9) * kick,
    );
    spawnAsteroid(
      a.kind,
      next,
      a.x,
      a.y,
      a.vx + Math.cos(ang - 0.9) * kick,
      a.vy + Math.sin(ang - 0.9) * kick,
    );
    remaining = asteroids.length;
  }

  function grantDrop(id: DropId, x: number, y: number) {
    if (id === "aegis") {
      aegisT = AEGIS_T;
      spawnFloater(x, y - 18, DROP_LABEL[id], LUCKY_COLOR);
    } else if (id === "ward") {
      ward = 1;
      spawnFloater(x, y - 18, DROP_LABEL[id], "#c5cdd8");
    } else if (id === "overcharge") {
      overchargeT = OVERCHARGE_T;
      spawnFloater(x, y - 18, DROP_LABEL[id], "#e8a070");
    } else if (id === "frag2x") {
      fragMulT = FRAG2X_T;
      spawnFloater(x, y - 18, DROP_LABEL[id], LUCKY_COLOR);
    } else if (id === "bomb") {
      spawnFloater(x, y - 18, DROP_LABEL[id], "#c45c4a");
      detonate(x, y);
    }
    if (id !== "bomb") sfxPower();
    emitHud();
  }

  function detonate(x: number, y: number) {
    sfxBomb();
    spawnParticle(x, y, "#c45c4a", 12, 220, false);
    trauma = Math.min(1, trauma + 0.55);
    flash = 0.5;
    const hit = asteroids.filter((a) => {
      const dx = wrapDelta(x, a.x, w);
      const dy = wrapDelta(y, a.y, h);
      return Math.hypot(dx, dy) <= BOMB_R;
    });
    for (const a of hit) smash(a, true);
  }

  function smash(a: Asteroid, fromBomb: boolean) {
    if (!asteroids.includes(a)) return;
    if (a.lucky) {
      const idx = asteroids.indexOf(a);
      if (idx >= 0) asteroids.splice(idx, 1);
      remaining = asteroids.length;
      combo += 1;
      addScore(80, a.x, a.y);
      addFrags(2, a.x, a.y);
      spawnParticle(a.x, a.y, LUCKY_COLOR, 10, 160, false);
      sfxLucky();
      if (!fromBomb) {
        const drop =
          a.drop ?? DROPS[Math.floor(Math.random() * DROPS.length)] ?? "ward";
        grantDrop(drop, a.x, a.y);
      }
      return;
    }
    destroyAsteroid(a);
  }

  function destroyAsteroid(a: Asteroid) {
    combo += 1;
    addScore(SIZE_SCORE[a.size], a.x, a.y);
    addFrags(SIZE_FRAG[a.size], a.x, a.y);
    spawnParticle(a.x, a.y, pal.kind[a.kind], a.size === "titan" ? 12 : 8, 140, false);
    sfxExplode(a.size === "titan" || a.size === "large");
    trauma = Math.min(1, trauma + (a.size === "titan" ? 0.5 : a.size === "large" ? 0.28 : 0.16));
    freeze = a.size === "titan" ? 0.06 : 0.03;
    flash = 0.28;
    splitAsteroid(a);
  }

  function pickAsteroid(x: number, y: number): Asteroid | null {
    let best: Asteroid | null = null;
    let bestD = 1e9;
    for (const a of asteroids) {
      const dx = wrapDelta(x, a.x, w);
      const dy = wrapDelta(y, a.y, h);
      const d = Math.hypot(dx, dy);
      if (d < a.r + CLICK_PAD && d < bestD) {
        best = a;
        bestD = d;
      }
    }
    return best;
  }

  function inReach(x: number, y: number) {
    const dx = wrapDelta(x, coreX, w);
    const dy = wrapDelta(y, coreY, h);
    return Math.hypot(dx, dy) <= reachR() + 6;
  }

  function fireAt(x: number, y: number) {
    if (opts.mode === "attract" || ended || paused || pendingNextWave) return;
    if (fireCd > 0) return;
    fireCd = FIRE_COOLDOWN;
    const a = pickAsteroid(x, y);
    if (!a) {
      spawnBeam(x, y, false, pal.weapon[weapon]);
      sfxShoot(weapon);
      return;
    }
    if (!inReach(a.x, a.y)) {
      spawnBeam(a.x, a.y, false, pal.kind[a.kind]);
      spawnFloater(a.x, a.y - a.r, "OUT OF RANGE", "#c45c4a");
      sfxResist();
      emitHud();
      return;
    }
    const matched = a.lucky || overchargeT > 0 || MATCH[a.kind] === weapon;
    const tint = a.lucky ? LUCKY_COLOR : pal.kind[a.kind];
    spawnBeam(a.x, a.y, matched, tint);
    sfxShoot(weapon);
    if (matched) {
      sfxHit();
      smash(a, false);
    } else {
      combo = 0;
      a.hitFlash = 0.18;
      spawnParticle(a.x, a.y, pal.kind[a.kind], 4, 70, false);
      spawnFloater(a.x, a.y - a.r, "RESIST", pal.kind[a.kind]);
      sfxResist();
      trauma = Math.min(1, trauma + 0.08);
    }
    emitHud();
  }

  function coreHit(a: Asteroid) {
    if (ended || opts.mode === "attract") return;
    const idx = asteroids.indexOf(a);
    if (idx >= 0) asteroids.splice(idx, 1);
    remaining = asteroids.length;
    spawnParticle(a.x, a.y, a.lucky ? LUCKY_COLOR : pal.kind[a.kind], 8, 160, false);
    if (opts.godMode) {
      spawnFloater(coreX, coreY - 40, "GOD", LUCKY_COLOR);
      emitHud();
      return;
    }
    if (aegisT > 0) {
      spawnFloater(coreX, coreY - 40, "AEGIS", LUCKY_COLOR);
      trauma = 0.25;
      emitHud();
      return;
    }
    if (ward > 0) {
      ward = 0;
      coreInvuln = CORE_INVULN;
      spawnFloater(coreX, coreY - 40, "WARD", "#c5cdd8");
      sfxPower();
      trauma = 0.4;
      emitHud();
      return;
    }
    if (coreInvuln > 0) return;
    lives -= 1;
    combo = 0;
    coreInvuln = CORE_INVULN;
    sfxDead();
    spawnParticle(coreX, coreY, skin.core, 10, 150, false);
    trauma = 0.85;
    flash = 0.65;
    freeze = 0.1;
    if (lives <= 0) {
      ended = true;
      opts.onGameOver(score, wave);
      emitHud();
      return;
    }
    emitHud();
  }

  function cycleWeapon(dir: number) {
    if (unlocked.length === 0) return;
    const i = unlocked.indexOf(weapon);
    const next = unlocked[(i + dir + unlocked.length) % unlocked.length];
    if (next && next !== weapon) {
      weapon = next;
      sfxSwitch();
      emitHud();
    }
  }

  function setWeapon(w: WeaponId) {
    if (!unlocked.includes(w) || w === weapon) return;
    weapon = w;
    sfxSwitch();
    emitHud();
  }

  function eventToWorld(e: PointerEvent) {
    const rect = canvas.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }

  function gravity() {
    if (opts.mode === "infinite") return infiniteSpec().pull;
    if (opts.mode === "custom") return Math.min(12, (opts.custom?.speed ?? 40) * 0.14);
    if (opts.mode === "campaign") return Math.min(16, 5.5 + (level?.id ?? 1) * 0.2);
    return 0;
  }

  function step(dt: number) {
    if (ended) return;
    if (freeze > 0) {
      freeze -= dt;
      return;
    }
    resumeAudio();
    briefingT = Math.max(0, briefingT - dt);
    if (briefingT === 0 && !pendingNextWave) playTime += dt;
    fireCd = Math.max(0, fireCd - dt);
    coreInvuln = Math.max(0, coreInvuln - dt);
    aegisT = Math.max(0, aegisT - dt);
    overchargeT = Math.max(0, overchargeT - dt);
    fragMulT = Math.max(0, fragMulT - dt);
    trauma = Math.max(0, trauma - dt * 1.8);
    flash = Math.max(0, flash - dt * 2.2);

    if (pendingNextWave) {
      waveClearT = Math.max(0, waveClearT - dt);
      for (const p of particles) {
        if (!p.alive) continue;
        p.life -= dt;
        if (p.life <= 0) p.alive = false;
        else {
          p.x += p.vx * dt;
          p.y += p.vy * dt;
        }
      }
      for (const f of floaters) {
        if (!f.alive) continue;
        f.life -= dt;
        if (f.life <= 0) f.alive = false;
        else f.y += f.vy * dt;
      }
      for (const b of beams) {
        if (!b.alive) continue;
        b.life -= dt;
        if (b.life <= 0) b.alive = false;
      }
      if (waveClearT <= 0) {
        pendingNextWave = false;
        wave += 1;
        seedField();
        emitHud();
      }
      return;
    }

    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (!pad) continue;
      const bumpL = pad.buttons[4]?.pressed ?? false;
      const bumpR = pad.buttons[5]?.pressed ?? false;
      const start = pad.buttons[9]?.pressed ?? false;
      if (bumpL && !padPrev.bumpL) cycleWeapon(-1);
      if (bumpR && !padPrev.bumpR) cycleWeapon(1);
      if (start && !padPrev.start) opts.onPause?.();
      padPrev = { bumpL, bumpR, start };
    }

    const pull = gravity();
    for (const a of asteroids) {
      if (pull > 0) {
        const dx = wrapDelta(coreX, a.x, w);
        const dy = wrapDelta(coreY, a.y, h);
        const d = Math.hypot(dx, dy) || 1;
        a.vx += (dx / d) * pull * dt;
        a.vy += (dy / d) * pull * dt;
      }
      a.x = wrap(a.x + a.vx * dt, w);
      a.y = wrap(a.y + a.vy * dt, h);
      a.angle += a.spin * dt;
      a.hitFlash = Math.max(0, a.hitFlash - dt);
    }

    for (const b of beams) {
      if (!b.alive) continue;
      b.life -= dt;
      if (b.life <= 0) b.alive = false;
    }
    for (const p of particles) {
      if (!p.alive) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.alive = false;
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    for (const f of floaters) {
      if (!f.alive) continue;
      f.life -= dt;
      if (f.life <= 0) {
        f.alive = false;
        continue;
      }
      f.y += f.vy * dt;
    }

    hover = pointer ? pickAsteroid(pointer.x, pointer.y) : null;

    if (opts.mode === "attract") return;

    if (aegisT > 0 || coreInvuln <= 0) {
      for (const a of asteroids) {
        const dx = wrapDelta(coreX, a.x, w);
        const dy = wrapDelta(coreY, a.y, h);
        if (dx * dx + dy * dy < (a.r + CORE_R) * (a.r + CORE_R)) {
          coreHit(a);
          break;
        }
      }
    }

    remaining = asteroids.length;
    if (remaining === 0 && !ended) {
      if (opts.mode === "campaign") {
        ended = true;
        sfxClear();
        addFrags(campaignPayout(level?.id ?? 1), coreX, coreY);
        const timeMs = Math.max(400, Math.round(playTime * 1000));
        if ((level?.id ?? 1) >= LEVELS.length) opts.onVictory(score, timeMs);
        else opts.onLevelClear(score, timeMs);
      } else if (opts.mode === "infinite") {
        pendingNextWave = true;
        waveClearT = 2.4;
        sfxClear();
        addFrags(2 + Math.round(wave * 0.7), coreX, coreY);
        spawnFloater(coreX, coreY - 48, `WAVE ${wave} CLEARED`, LUCKY_COLOR);
        emitHud();
      } else if (opts.mode === "custom") {
        ended = true;
        sfxClear();
        const rocks =
          opts.custom?.spawn === "placed"
            ? opts.custom.rocks.length || 1
            : (opts.custom?.count ?? 4);
        addFrags(6 + rocks * 2, coreX, coreY);
        const timeMs = Math.max(400, Math.round(playTime * 1000));
        opts.onCustomClear?.(score, timeMs);
      }
    }
    hudClock += dt;
    if (hudClock >= 0.25 && (aegisT > 0 || overchargeT > 0 || fragMulT > 0)) {
      hudClock = 0;
      emitHud();
    }
  }

  function noise(t: number) {
    return Math.sin(t * 17.2) * 0.5 + Math.sin(t * 9.1 + 1.7) * 0.5;
  }

  function draw(now: number) {
    const shake = opts.shakeEnabled ? trauma * trauma : 0;
    renderWorld(ctx, {
      w,
      h,
      coreX,
      coreY,
      coreR: CORE_R,
      coreInvuln,
      asteroids,
      beams,
      particles,
      floaters,
      weapon,
      hover: opts.mode === "attract" ? null : hover,
      pointer: opts.mode === "attract" ? null : pointer,
      shakeX: shake * 10 * noise(now * 0.01),
      shakeY: shake * 10 * noise(now * 0.013 + 20),
      shakeRot: shake * 0.02 * noise(now * 0.008 + 4),
      flash,
      stars,
      showCore: opts.mode !== "attract",
      reach: opts.mode === "attract" ? 0 : reachR(),
      aegisT,
      ward,
      overchargeT,
      skinCore: skin.core,
      skinBeam: skin.beam,
      kindColors: pal.kind,
      weaponColors: pal.weapon,
      beamStyle: pal.laser.style,
      beamWidth: pal.laser.width,
      beamGlow: pal.laser.glow,
      rockFill: pal.pack.fill,
      rockCut: pal.pack.cut,
      backdrop: customBelt && customBelt.bg !== "custom" ? customBelt.bg : "void",
      bgImage: customBelt ? bgImg : null,
    });
  }

  function frame(now: number) {
    if (!running) return;
    if (typeof document !== "undefined" && document.hidden) {
      last = now;
      acc = 0;
      raf = requestAnimationFrame(frame);
      return;
    }
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (!paused && !ended) {
      acc += dt * timeScale;
      let steps = 0;
      while (acc >= FIXED && steps < 4) {
        step(FIXED);
        acc -= FIXED;
        steps += 1;
      }
      if (steps === 4) acc = 0;
    } else if (paused) {
      const pads = navigator.getGamepads?.() ?? [];
      for (const pad of pads) {
        if (!pad) continue;
        const start = pad.buttons[9]?.pressed ?? false;
        if (start && !padPrev.start) opts.onPause?.();
        padPrev = { ...padPrev, start };
      }
    }
    try {
      draw(now);
    } catch {
      /* keep the loop alive if a frame fails */
    }
    raf = requestAnimationFrame(frame);
  }

  function onKeyDown(e: KeyboardEvent) {
    if (GAME_KEYS.has(e.code)) e.preventDefault();
    keys.add(e.code);
    if (e.repeat) return;
    if (e.code === "KeyQ") cycleWeapon(-1);
    if (e.code === "KeyE") cycleWeapon(1);
    if (e.code === "Digit1") setWeapon("kinetic");
    if (e.code === "Digit2") setWeapon("cryo");
    if (e.code === "Digit3") setWeapon("resonant");
    if (e.code === "Digit4") setWeapon("thermal");
    if (e.code === "KeyP" || e.code === "Escape") {
      if (opts.mode === "attract" || ended) return;
      opts.onPause?.();
    }
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
  }
  function onBlur() {
    keys.clear();
  }
  function onWheel(e: WheelEvent) {
    if (opts.mode === "attract") return;
    e.preventDefault();
    cycleWeapon(e.deltaY > 0 ? 1 : -1);
  }
  function onPointerMove(e: PointerEvent) {
    pointer = eventToWorld(e);
  }
  function onPointerDown(e: PointerEvent) {
    if (e.button !== undefined && e.button !== 0) return;
    const p = eventToWorld(e);
    pointer = p;
    fireAt(p.x, p.y);
  }
  function onPointerLeave() {
    pointer = null;
    hover = null;
  }

  function bind() {
    if (listenersOn) return;
    listenersOn = true;
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    document.addEventListener("visibilitychange", onBlur);
    canvas.addEventListener("wheel", onWheel, { passive: false });
    canvas.addEventListener("pointermove", onPointerMove);
    canvas.addEventListener("pointerdown", onPointerDown);
    canvas.addEventListener("pointerleave", onPointerLeave);
    window.addEventListener("resize", resize);
    if (typeof ResizeObserver !== "undefined") {
      resizeObserver = new ResizeObserver(() => {
        if (running) resize();
      });
      resizeObserver.observe(canvas);
    }
    canvas.style.cursor =
      opts.mode === "attract" || window.matchMedia("(pointer: coarse)").matches
        ? "crosshair"
        : "none";
  }
  function unbind() {
    if (!listenersOn) return;
    listenersOn = false;
    window.removeEventListener("keydown", onKeyDown);
    window.removeEventListener("keyup", onKeyUp);
    window.removeEventListener("blur", onBlur);
    document.removeEventListener("visibilitychange", onBlur);
    canvas.removeEventListener("wheel", onWheel);
    canvas.removeEventListener("pointermove", onPointerMove);
    canvas.removeEventListener("pointerdown", onPointerDown);
    canvas.removeEventListener("pointerleave", onPointerLeave);
    window.removeEventListener("resize", resize);
    resizeObserver?.disconnect();
    resizeObserver = null;
    canvas.style.cursor = "default";
  }

  function pause() {
    paused = true;
    emitHud();
  }
  function resume() {
    paused = false;
    last = performance.now();
    emitHud();
  }

  function setTimeScale(n: number) {
    timeScale = n === 2 ? 2 : 1;
  }

  function start() {
    running = true;
    paused = false;
    ended = false;
    let tries = 0;
    const kick = () => {
      if (!running || disposed) return;
      resize();
      if ((w < 8 || h < 8) && tries < 24) {
        tries += 1;
        raf = requestAnimationFrame(kick);
        return;
      }
      seedField();
      bind();
      last = performance.now();
      emitHud();
      if (opts.mode === "attract") cueMusic(() => playTitleMusic());
      raf = requestAnimationFrame(frame);
    };
    kick();
  }

  function destroy() {
    disposed = true;
    running = false;
    cancelAnimationFrame(raf);
    unbind();
    bgImg = null;
    try {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = "#08080a";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    } catch {
      /* canvas already gone */
    }
  }

  return {
    start,
    destroy,
    pause,
    resume,
    setWeapon,
    cycleWeapon,
    setTimeScale,
    getHud,
    subscribe: (fn) => {
      hudListeners.add(fn);
      return () => hudListeners.delete(fn);
    },
  };
}
