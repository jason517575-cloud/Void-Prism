import type { SkinId } from "./types";
import { LEVELS, SKINS } from "./catalog";
import {
  DEFAULT_LASER_ID,
  DEFAULT_PACK_ID,
  isLaserId,
  isPackId,
} from "./cosmetics";

const KEY = "void-prism-save-v4";
const SAVE_VERSION = 4;

function clamp01(n: unknown, fallback: number) {
  const v = Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.max(0, Math.min(1, v));
}

export type SaveData = {
  version: number;
  campaignReached: number;
  campaignBest: number;
  infiniteBest: number;
  infiniteBestWave: number;
  muted: boolean;
  shake: boolean;
  musicVol: number;
  sfxVol: number;
  timeScale: 1 | 2;
  fragments: number;
  ownedSkins: SkinId[];
  equippedSkin: SkinId;
  ownedLasers: string[];
  equippedLaser: string;
  ownedPacks: string[];
  equippedPack: string;
  campaignTimes: Record<number, number>;
  godMode: boolean;
  season: number;
};

const DEFAULTS: SaveData = {
  version: SAVE_VERSION,
  campaignReached: 1,
  campaignBest: 0,
  infiniteBest: 0,
  infiniteBestWave: 0,
  muted: false,
  shake: true,
  musicVol: 0.72,
  sfxVol: 0.88,
  timeScale: 1,
  fragments: 0,
  ownedSkins: ["prism"],
  equippedSkin: "prism",
  ownedLasers: [DEFAULT_LASER_ID],
  equippedLaser: DEFAULT_LASER_ID,
  ownedPacks: [DEFAULT_PACK_ID],
  equippedPack: DEFAULT_PACK_ID,
  campaignTimes: {},
  godMode: false,
  season: 1,
};

function isSkin(id: string): id is SkinId {
  return SKINS.some((s) => s.id === id);
}

function parseTimes(raw: unknown): Record<number, number> {
  if (!raw || typeof raw !== "object") return {};
  const out: Record<number, number> = {};
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    const id = Number(k);
    const ms = Number(v);
    if (id >= 1 && id <= LEVELS.length && Number.isFinite(ms) && ms > 0) {
      out[id] = Math.floor(ms);
    }
  }
  return out;
}

function uniqKeep<T extends string>(ids: T[], fallback: T): T[] {
  const out: T[] = [];
  for (const id of ids) {
    if (!out.includes(id)) out.push(id);
  }
  if (!out.includes(fallback)) out.unshift(fallback);
  return out;
}

function migrate(raw: Partial<SaveData> & { version?: number }): SaveData {
  const ownedRaw = Array.isArray(raw.ownedSkins) ? raw.ownedSkins : ["prism"];
  const owned: SkinId[] = ownedRaw.filter(isSkin);
  if (!owned.includes("prism")) owned.unshift("prism");
  const equipped =
    raw.equippedSkin && owned.includes(raw.equippedSkin) ? raw.equippedSkin : "prism";
  const lasers = uniqKeep(
    (Array.isArray(raw.ownedLasers) ? raw.ownedLasers : [DEFAULT_LASER_ID]).filter(isLaserId),
    DEFAULT_LASER_ID,
  );
  const packs = uniqKeep(
    (Array.isArray(raw.ownedPacks) ? raw.ownedPacks : [DEFAULT_PACK_ID]).filter(isPackId),
    DEFAULT_PACK_ID,
  );
  const equippedLaser =
    raw.equippedLaser && lasers.includes(raw.equippedLaser)
      ? raw.equippedLaser
      : DEFAULT_LASER_ID;
  const equippedPack =
    raw.equippedPack && packs.includes(raw.equippedPack)
      ? raw.equippedPack
      : DEFAULT_PACK_ID;
  return {
    ...DEFAULTS,
    ...raw,
    ownedSkins: owned,
    equippedSkin: equipped,
    ownedLasers: lasers,
    equippedLaser,
    ownedPacks: packs,
    equippedPack,
    musicVol: clamp01(raw.musicVol, DEFAULTS.musicVol),
    sfxVol: clamp01(raw.sfxVol, DEFAULTS.sfxVol),
    timeScale: raw.timeScale === 2 ? 2 : 1,
    fragments: Math.max(0, Math.floor(raw.fragments ?? 0)),
    campaignReached: Math.max(1, Math.floor(raw.campaignReached ?? 1)),
    infiniteBestWave: Math.max(0, Math.floor(raw.infiniteBestWave ?? 0)),
    campaignTimes: parseTimes(raw.campaignTimes),
    godMode: raw.godMode === true,
    season: Math.max(1, Math.floor(Number(raw.season) || 1)),
    version: SAVE_VERSION,
  };
}

export function loadSave(): SaveData {
  try {
    const raw =
      localStorage.getItem(KEY) ??
      localStorage.getItem("void-prism-save-v3") ??
      localStorage.getItem("void-prism-save-v2") ??
      localStorage.getItem("void-prism-save-v1");
    if (!raw) return { ...DEFAULTS, ownedSkins: ["prism"] };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return migrate(parsed);
  } catch {
    return { ...DEFAULTS, ownedSkins: ["prism"] };
  }
}

export function writeSave(patch: Partial<SaveData>): SaveData {
  const next = migrate({ ...loadSave(), ...patch });
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode / quota */
  }
  return next;
}

export function mergeSaves(local: SaveData, remote: SaveData): SaveData {
  const owned = Array.from(new Set([...local.ownedSkins, ...remote.ownedSkins]));
  if (!owned.includes("prism")) owned.unshift("prism");
  const lasers = uniqKeep(
    [...local.ownedLasers, ...remote.ownedLasers].filter(isLaserId),
    DEFAULT_LASER_ID,
  );
  const packs = uniqKeep(
    [...local.ownedPacks, ...remote.ownedPacks].filter(isPackId),
    DEFAULT_PACK_ID,
  );
  const times = { ...remote.campaignTimes };
  for (const [k, v] of Object.entries(local.campaignTimes)) {
    const id = Number(k);
    const prev = times[id];
    times[id] = prev ? Math.min(prev, v) : v;
  }
  const equipped = owned.includes(local.equippedSkin)
    ? local.equippedSkin
    : remote.equippedSkin;
  const equippedLaser = lasers.includes(local.equippedLaser)
    ? local.equippedLaser
    : remote.equippedLaser;
  const equippedPack = packs.includes(local.equippedPack)
    ? local.equippedPack
    : remote.equippedPack;
  return migrate({
    ...local,
    campaignReached: Math.max(local.campaignReached, remote.campaignReached),
    campaignBest: Math.max(local.campaignBest, remote.campaignBest),
    infiniteBest: Math.max(local.infiniteBest, remote.infiniteBest),
    infiniteBestWave: Math.max(local.infiniteBestWave, remote.infiniteBestWave),
    fragments: Math.max(local.fragments, remote.fragments),
    ownedSkins: owned,
    equippedSkin: equipped,
    ownedLasers: lasers,
    equippedLaser,
    ownedPacks: packs,
    equippedPack,
    campaignTimes: times,
  });
}
