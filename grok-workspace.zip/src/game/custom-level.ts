import { LEVELS } from "./catalog";
import { REACH_FRAC } from "./config";
import type { AsteroidKind, DropId, SizeClass } from "./types";

export const BG_PRESETS = ["void", "nebula", "dusk", "ice", "ember"] as const;
export type BgPreset = (typeof BG_PRESETS)[number] | "custom";

export type CustomRock = {
  kind: AsteroidKind;
  size: SizeClass;
  nx: number;
  ny: number;
};

export type CustomLevelDef = {
  name: string;
  briefing: string;
  spawn: "random" | "placed";
  kinds: AsteroidKind[];
  count: number;
  rocks: CustomRock[];
  speed: number;
  lucky: "random" | "fixed";
  luckyCount: number;
  luckyDrops: DropId[];
  bg: BgPreset;
  bgData: string;
  music: "game" | "upload";
  gameMusicId: string;
  musicData: string;
};

const KINDS: AsteroidKind[] = ["basalt", "rime", "quartz", "alloy"];
const SIZES: SizeClass[] = ["large", "medium", "small", "titan"];
const DROPS: DropId[] = ["aegis", "ward", "overcharge", "bomb", "frag2x"];
const NAME_MAX = 32;
export const AUDIO_FILE_MAX = 5 * 1024 * 1024;
const AUDIO_MAX = 7_400_000;
const IMAGE_MAX = 620_000;

const OFFICIAL = new Set(LEVELS.map((l) => l.name.trim().toLowerCase()));

export const TRACK_CHOICES: { id: string; label: string }[] = [
  { id: "title", label: "Hangar" },
  ...LEVELS.map((l) => ({ id: l.music, label: `${l.id}. ${l.name}` })),
];

export function blankLevel(): CustomLevelDef {
  return {
    name: "",
    briefing: "A belt you built.",
    spawn: "random",
    kinds: ["basalt", "rime"],
    count: 6,
    rocks: [],
    speed: 40,
    lucky: "random",
    luckyCount: 1,
    luckyDrops: ["ward"],
    bg: "void",
    bgData: "",
    music: "game",
    gameMusicId: "shale",
    musicData: "",
  };
}

function clamp(n: number, min: number, max: number) {
  if (!Number.isFinite(n)) return min;
  return Math.max(min, Math.min(max, n));
}

export function normalizeName(name: string) {
  return name.trim().replace(/\s+/g, " ").slice(0, NAME_MAX);
}

export function officialNameTaken(name: string) {
  return OFFICIAL.has(normalizeName(name).toLowerCase());
}

export function insideReach(nx: number, ny: number, aspect: number) {
  const dx = (nx - 0.5) * aspect;
  const dy = ny - 0.48;
  const reach = REACH_FRAC * Math.min(aspect, 1);
  return Math.hypot(dx, dy) <= reach;
}

export function sanitizeLevel(raw: unknown): { ok: true; level: CustomLevelDef } | { ok: false; error: string } {
  if (!raw || typeof raw !== "object") return { ok: false, error: "Level is empty." };
  const src = raw as Partial<CustomLevelDef>;
  const name = normalizeName(String(src.name ?? ""));
  if (name.length < 2) return { ok: false, error: "Name needs at least 2 characters." };
  if (officialNameTaken(name)) return { ok: false, error: "That name is already a campaign sector." };

  const kinds = Array.isArray(src.kinds)
    ? src.kinds.filter((k): k is AsteroidKind => KINDS.includes(k as AsteroidKind))
    : [];
  const rocks = Array.isArray(src.rocks)
    ? src.rocks
        .filter((r) => r && typeof r === "object")
        .slice(0, 18)
        .map((r) => {
          const rock = r as Partial<CustomRock>;
          const kind = KINDS.includes(rock.kind as AsteroidKind) ? (rock.kind as AsteroidKind) : "basalt";
          const size = SIZES.includes(rock.size as SizeClass) ? (rock.size as SizeClass) : "large";
          return {
            kind,
            size,
            nx: clamp(Number(rock.nx), 0.08, 0.92),
            ny: clamp(Number(rock.ny), 0.08, 0.78),
          };
        })
    : [];

  const spawn = src.spawn === "placed" ? "placed" : "random";
  if (spawn === "random" && kinds.length === 0) {
    return { ok: false, error: "Pick at least one rock type." };
  }
  if (spawn === "placed" && rocks.length === 0) {
    return { ok: false, error: "Place at least one rock." };
  }

  const drops = Array.isArray(src.luckyDrops)
    ? src.luckyDrops.filter((d): d is DropId => DROPS.includes(d as DropId))
    : [];
  const lucky = src.lucky === "fixed" ? "fixed" : "random";
  if (lucky === "fixed" && drops.length === 0) {
    return { ok: false, error: "Pick at least one lucky drop, or set lucky to random." };
  }

  const bgData = typeof src.bgData === "string" ? src.bgData : "";
  const musicData = typeof src.musicData === "string" ? src.musicData : "";
  const bg = src.bg === "custom" || BG_PRESETS.includes(src.bg as (typeof BG_PRESETS)[number])
    ? (src.bg as BgPreset)
    : "void";
  if (bg === "custom") {
    if (!bgData.startsWith("data:image/")) return { ok: false, error: "Background must be an image." };
    if (bgData.length > IMAGE_MAX) return { ok: false, error: "Background is too large." };
  }
  const music = src.music === "upload" ? "upload" : "game";
  if (music === "upload") {
    const audioOk =
      musicData.startsWith("data:audio/") ||
      musicData.startsWith("data:video/") ||
      musicData.startsWith("data:application/octet-stream");
    if (!audioOk) return { ok: false, error: "Music must be an audio file." };
    if (musicData.length > AUDIO_MAX || dataUrlBytes(musicData) > AUDIO_FILE_MAX) {
      return { ok: false, error: "Music must be under 5 MB." };
    }
  }
  const gameMusicId =
    TRACK_CHOICES.some((t) => t.id === src.gameMusicId) ? String(src.gameMusicId) : "shale";

  return {
    ok: true,
    level: {
      name,
      briefing: String(src.briefing ?? "A belt you built.").trim().slice(0, 80) || "A belt you built.",
      spawn,
      kinds: kinds.length ? kinds : ["basalt"],
      count: Math.round(clamp(Number(src.count), 3, 14)),
      rocks,
      speed: Math.round(clamp(Number(src.speed), 28, 78)),
      lucky,
      luckyCount: Math.round(clamp(Number(src.luckyCount), 0, 5)),
      luckyDrops: drops.length ? drops : ["ward"],
      bg,
      bgData: bg === "custom" ? bgData : "",
      music,
      gameMusicId,
      musicData: music === "upload" ? musicData : "",
    },
  };
}

const DRAFT_KEY = "void-prism-drafts-v1";

export type DraftRow = { id: string; level: CustomLevelDef };

export function loadDrafts(): DraftRow[] {
  try {
    const raw = JSON.parse(localStorage.getItem(DRAFT_KEY) || "[]") as unknown;
    if (!Array.isArray(raw)) return [];
    const out: DraftRow[] = [];
    for (const row of raw) {
      if (!row || typeof row !== "object") continue;
      const id = String((row as { id?: string }).id ?? "");
      const parsed = sanitizeLevel((row as { level?: unknown }).level);
      if (!id || !parsed.ok) continue;
      out.push({ id, level: parsed.level });
    }
    return out.slice(0, 12);
  } catch {
    return [];
  }
}

export function saveDraft(level: CustomLevelDef, id?: string): { drafts: DraftRow[]; stripped: boolean } {
  const rowOf = (lvl: CustomLevelDef) => ({ id: id || crypto.randomUUID(), level: lvl });
  const write = (lvl: CustomLevelDef) => {
    const drafts = loadDrafts().filter((d) => d.level.name.toLowerCase() !== lvl.name.toLowerCase());
    const next = [rowOf(lvl), ...drafts].slice(0, 12);
    localStorage.setItem(DRAFT_KEY, JSON.stringify(next));
    return next;
  };
  try {
    return { drafts: write(level), stripped: false };
  } catch {
    const light: CustomLevelDef = {
      ...level,
      music: "game",
      musicData: "",
      bg: level.bg === "custom" ? "void" : level.bg,
      bgData: "",
    };
    return { drafts: write(light), stripped: true };
  }
}

export function deleteDraft(id: string): DraftRow[] {
  const next = loadDrafts().filter((d) => d.id !== id);
  localStorage.setItem(DRAFT_KEY, JSON.stringify(next));
  return next;
}

function dataUrlBytes(url: string) {
  const i = url.indexOf(",");
  if (i < 0) return url.length;
  return Math.floor((url.length - i - 1) * 0.75);
}

export async function readDataUrl(file: File, maxBytes: number, kind: "audio" | "image") {
  if (file.size > maxBytes) {
    const limit =
      kind === "audio"
        ? `${Math.max(1, Math.round(maxBytes / (1024 * 1024)))} MB`
        : `${Math.max(1, Math.round(maxBytes / 1024))} KB`;
    return { ok: false as const, error: kind === "audio" ? `Music must be under ${limit}.` : `Image must be under ${limit}.` };
  }
  const url = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("read"));
    reader.readAsDataURL(file);
  });
  if (kind === "image" && !url.startsWith("data:image/")) {
    return { ok: false as const, error: "That file is not an image." };
  }
  if (kind === "audio") {
    const audioOk =
      url.startsWith("data:audio/") ||
      url.startsWith("data:video/") ||
      url.startsWith("data:application/octet-stream");
    if (!audioOk) return { ok: false as const, error: "That file is not audio." };
    if (dataUrlBytes(url) > maxBytes) {
      return { ok: false as const, error: "Music must be under 5 MB." };
    }
  }
  return { ok: true as const, url };
}
