import type { AsteroidKind, DropId, WeaponId } from "./types";

export {
  INFINITE_MUSIC,
  LEVELS,
  MUSIC,
  SKINS,
  WEAPON_INTRO,
  formatTime,
  infiniteBpm,
  infiniteMusicId,
  skinById,
  unlockedWeapons,
  type SkinDef,
} from "./catalog";

export {
  DEFAULT_LASER_ID,
  DEFAULT_PACK_ID,
  LASER_SKINS,
  ROCK_PACKS,
  isLaserId,
  isPackId,
  laserById,
  livePalette,
  packById,
  rollGacha,
  GACHA_COST,
  GACHA_DUP_REFUND,
  type BeamStyle,
  type GachaPrize,
  type LaserDef,
  type LivePalette,
  type RockCut,
  type RockPackDef,
} from "./cosmetics";

export const FIXED = 1 / 60;
export const FIRE_COOLDOWN = 0.1;
export const START_LIVES = 3;
export const CORE_R = 22;
export const CLICK_PAD = 34;
export const CORE_INVULN = 1.15;
export const REACH_FRAC = 0.52;
export const LUCKY_CHANCE = 0.05;
export const LUCKY_MAX = 5;
export const BOMB_R = 150;
export const AEGIS_T = 30;
export const OVERCHARGE_T = 5;
export const FRAG2X_T = 10;

export const MATCH: Record<AsteroidKind, WeaponId> = {
  basalt: "kinetic",
  rime: "cryo",
  quartz: "resonant",
  alloy: "thermal",
};

export const KIND_LABEL: Record<AsteroidKind, string> = {
  basalt: "Basalt",
  rime: "Rime",
  quartz: "Quartz",
  alloy: "Alloy",
};

export const WEAPON_LABEL: Record<WeaponId, string> = {
  kinetic: "Kinetic",
  cryo: "Cryo",
  resonant: "Resonant",
  thermal: "Thermal",
};

export const WEAPON_ORDER: WeaponId[] = [
  "kinetic",
  "cryo",
  "resonant",
  "thermal",
];

export const KIND_ORDER: AsteroidKind[] = [
  "basalt",
  "rime",
  "quartz",
  "alloy",
];

export const WEAPON_COLOR: Record<WeaponId, string> = {
  kinetic: "#d4c4a8",
  cryo: "#7ec8d4",
  resonant: "#8fbfa5",
  thermal: "#c4845a",
};

export const KIND_COLOR: Record<AsteroidKind, string> = {
  basalt: "#b8a48a",
  rime: "#8ed0da",
  quartz: "#9fc9b0",
  alloy: "#c98b62",
};

export const SIZE_R: Record<"titan" | "large" | "medium" | "small", number> = {
  titan: 78,
  large: 42,
  medium: 24,
  small: 13,
};

export const SIZE_SCORE: Record<"titan" | "large" | "medium" | "small", number> = {
  titan: 40,
  large: 20,
  medium: 50,
  small: 100,
};

export const SIZE_FRAG: Record<"titan" | "large" | "medium" | "small", number> = {
  titan: 2,
  large: 1,
  medium: 1,
  small: 0,
};

export function campaignPayout(id: number) {
  const late = Math.max(0, id - 8);
  return Math.round(4 + id * 0.65 + late * 1.55);
}

export const LUCKY_COLOR = "#e6c35c";

export const DROPS: DropId[] = ["aegis", "ward", "overcharge", "bomb", "frag2x"];

export const DROP_LABEL: Record<DropId, string> = {
  aegis: "Aegis 30s",
  ward: "Ward",
  overcharge: "Overcharge 5s",
  bomb: "Blast",
  frag2x: "2× Frag 10s",
};

export const GAME_KEYS = new Set([
  "KeyQ",
  "KeyE",
  "Digit1",
  "Digit2",
  "Digit3",
  "Digit4",
  "KeyP",
  "Escape",
]);
