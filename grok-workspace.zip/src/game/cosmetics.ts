import type { AsteroidKind, WeaponId } from "./types";
import { SKINS } from "./catalog";

export type BeamStyle = "line" | "double" | "spark" | "ribbon" | "pulse" | "dash";
export type RockCut = "rough" | "cut" | "ice" | "crystal" | "plate" | "ember";

export type LaserDef = {
  id: string;
  name: string;
  cost: number;
  blurb: string;
  style: BeamStyle;
  width: number;
  glow: number;
  sat: number;
  light: number;
};

export type RockPackDef = {
  id: string;
  name: string;
  cost: number;
  blurb: string;
  colors: Record<AsteroidKind, string>;
  fill: number;
  cut: RockCut;
};

export type LivePalette = {
  kind: Record<AsteroidKind, string>;
  weapon: Record<WeaponId, string>;
  laser: LaserDef;
  pack: RockPackDef;
};

const BEAM_STYLES: BeamStyle[] = ["line", "double", "spark", "ribbon", "pulse", "dash"];
const ROCK_CUTS: RockCut[] = ["rough", "cut", "ice", "crystal", "plate", "ember"];

function hslHex(h: number, s: number, l: number): string {
  const sat = Math.max(0, Math.min(100, s)) / 100;
  const lig = Math.max(0, Math.min(100, l)) / 100;
  const a = sat * Math.min(lig, 1 - lig);
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const c = lig - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * c)
      .toString(16)
      .padStart(2, "0");
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

function hexToRgb(hex: string) {
  const n = Number.parseInt(hex.replace("#", "").slice(0, 6), 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToHsl(r: number, g: number, b: number) {
  const rr = r / 255;
  const gg = g / 255;
  const bb = b / 255;
  const max = Math.max(rr, gg, bb);
  const min = Math.min(rr, gg, bb);
  const l = (max + min) / 2;
  if (max === min) return { h: 0, s: 0, l: l * 100 };
  const d = max - min;
  const s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
  let h = 0;
  if (max === rr) h = (gg - bb) / d + (gg < bb ? 6 : 0);
  else if (max === gg) h = (bb - rr) / d + 2;
  else h = (rr - gg) / d + 4;
  return { h: h * 60, s: s * 100, l: l * 100 };
}

export function treatHex(hex: string, satMul: number, lightAdd: number): string {
  const { r, g, b } = hexToRgb(hex);
  const hsl = rgbToHsl(r, g, b);
  return hslHex(hsl.h, hsl.s * satMul, hsl.l + lightAdd);
}

function packColors(rot: number, sat: number, light: number): Record<AsteroidKind, string> {
  return {
    basalt: hslHex((32 + rot) % 360, 28 + sat, 62 + light),
    rime: hslHex((188 + rot) % 360, 42 + sat, 68 + light),
    quartz: hslHex((148 + rot) % 360, 32 + sat, 64 + light),
    alloy: hslHex((22 + rot) % 360, 46 + sat, 56 + light),
  };
}

function extraCost(i: number): number {
  if (i <= 0) return 0;
  if (i < 10) return 40 + i * 10;
  if (i < 24) return 160 + (i - 10) * 16;
  if (i < 38) return 420 + (i - 24) * 24;
  return 820 + (i - 38) * 55;
}

const LASER_META: { name: string; blurb: string }[] = [
  { name: "Stock", blurb: "Factory lance." },
  { name: "Needle", blurb: "Thin pierce." },
  { name: "Twinline", blurb: "Paired rails." },
  { name: "Ribbon", blurb: "Soft sheet." },
  { name: "Nova", blurb: "Wide bloom." },
  { name: "Comet", blurb: "Tailed spark." },
  { name: "Pulse", blurb: "Breathing edge." },
  { name: "Emberbeam", blurb: "Hot core." },
  { name: "Frostbit", blurb: "Ice stitch." },
  { name: "Quartzarc", blurb: "Crystal cut." },
  { name: "Alloyedge", blurb: "Hard line." },
  { name: "Veil", blurb: "Soft veil." },
  { name: "Thorn", blurb: "Barbed tip." },
  { name: "Halo", blurb: "Ringed glow." },
  { name: "Drift", blurb: "Slow wash." },
  { name: "Ionspike", blurb: "Sharp ion." },
  { name: "Glasscut", blurb: "Clear slice." },
  { name: "Magma", blurb: "Molten bead." },
  { name: "Tide", blurb: "Pull and flash." },
  { name: "Umber", blurb: "Earthy lance." },
  { name: "Opaline", blurb: "Shift fire." },
  { name: "Cinder", blurb: "After burn." },
  { name: "Saturn", blurb: "Ring light." },
  { name: "Voidgleam", blurb: "Last gleam." },
  { name: "Brassarc", blurb: "Horn metal." },
  { name: "Kelp", blurb: "Deep green." },
  { name: "Glacier", blurb: "Slow blue." },
  { name: "Pyre", blurb: "Short fuse." },
  { name: "Indigo", blurb: "Night dye." },
  { name: "Coral", blurb: "Reef light." },
  { name: "Fogline", blurb: "Soft veil." },
  { name: "Plasma", blurb: "Hot field." },
  { name: "Chartreuse", blurb: "Acid silk." },
  { name: "Mercury", blurb: "Live metal." },
  { name: "Amethyst", blurb: "Royal shard." },
  { name: "Flare", blurb: "Signal fire." },
  { name: "Mint", blurb: "Cool leaf." },
  { name: "Nectar", blurb: "Sweet burn." },
  { name: "Slate", blurb: "Cut stone." },
  { name: "Bloom", blurb: "Open petal." },
  { name: "Sand", blurb: "Dry halo." },
  { name: "Steel", blurb: "Cold plate." },
  { name: "Wine", blurb: "Dark fruit." },
  { name: "Lime", blurb: "Acid wash." },
  { name: "Dusk", blurb: "Late orbit." },
  { name: "Citrus", blurb: "Sharp rind." },
  { name: "Rose", blurb: "Dust bloom." },
  { name: "Noir", blurb: "Low light." },
  { name: "Moss", blurb: "Belt growth." },
  { name: "Pearl", blurb: "Soft core." },
];

const PACK_META: { name: string; blurb: string }[] = [
  { name: "Shale", blurb: "Belt default." },
  { name: "Rimefield", blurb: "Cold crust." },
  { name: "Quartzbed", blurb: "Crystal floor." },
  { name: "Alloyset", blurb: "Worked metal." },
  { name: "Aurora", blurb: "Polar wash." },
  { name: "Emberfall", blurb: "Hot rain." },
  { name: "Ionvein", blurb: "Charged seam." },
  { name: "Gilded", blurb: "Lucky ore." },
  { name: "Obsidian", blurb: "Dark glass." },
  { name: "Violetore", blurb: "Dusk mineral." },
  { name: "Rustbelt", blurb: "Old hull." },
  { name: "Frostpack", blurb: "Thin ice." },
  { name: "Jadevein", blurb: "Quiet green." },
  { name: "Copper", blurb: "Warm ore." },
  { name: "Cobalt", blurb: "Deep pulse." },
  { name: "Pearldust", blurb: "Soft grit." },
  { name: "Magmarock", blurb: "Open kiln." },
  { name: "Mosscrust", blurb: "Living stone." },
  { name: "Noirstone", blurb: "Low light." },
  { name: "Rosequartz", blurb: "Dust bloom." },
  { name: "Citrussplit", blurb: "Sharp rind." },
  { name: "Duskore", blurb: "Late orbit." },
  { name: "Limewash", blurb: "Acid coat." },
  { name: "Wineslate", blurb: "Dark fruit." },
  { name: "Steelcut", blurb: "Cold plate." },
  { name: "Sandstone", blurb: "Dry halo." },
  { name: "Bloomrock", blurb: "Open petal." },
  { name: "Icepack", blurb: "Hard rime." },
  { name: "Nectarbelt", blurb: "Sweet burn." },
  { name: "Slatebed", blurb: "Cut floor." },
  { name: "Flarestone", blurb: "Signal fire." },
  { name: "Mintcrust", blurb: "Cool leaf." },
  { name: "Emberglass", blurb: "Fired silica." },
  { name: "Tidalrock", blurb: "Pull and push." },
  { name: "Umberpack", blurb: "Earth crust." },
  { name: "Quartzite", blurb: "Pressed crystal." },
  { name: "Plasmarock", blurb: "Hot field." },
  { name: "Fogstone", blurb: "Soft veil." },
  { name: "Coralreef", blurb: "Reef light." },
  { name: "Onyxcut", blurb: "Black cut." },
  { name: "Chartpack", blurb: "Acid silk." },
  { name: "Indigovein", blurb: "Night dye." },
  { name: "Brassore", blurb: "Horn metal." },
  { name: "Glacierpack", blurb: "Slow blue." },
  { name: "Pyroclast", blurb: "Short fuse." },
  { name: "Kelpbed", blurb: "Deep green." },
  { name: "Ivory", blurb: "Bone well." },
  { name: "Mercurylith", blurb: "Live metal." },
  { name: "Amethystpack", blurb: "Royal shard." },
  { name: "Cinderbelt", blurb: "After burn." },
];

function slug(prefix: string, name: string) {
  return `${prefix}-${name.toLowerCase().replace(/[^a-z0-9]+/g, "")}`;
}

export const LASER_SKINS: LaserDef[] = LASER_META.map((m, i) => ({
  id: slug("beam", m.name),
  name: m.name,
  blurb: m.blurb,
  cost: extraCost(i),
  style: i === 0 ? "line" : BEAM_STYLES[i % BEAM_STYLES.length]!,
  width: i === 0 ? 2.6 : 1.5 + (i % 5) * 0.5,
  glow: i === 0 ? 16 : 8 + (i % 7) * 3,
  sat: i === 0 ? 1 : 0.82 + (i % 5) * 0.08,
  light: i === 0 ? 10 : 4 + (i % 6) * 3,
}));

export const ROCK_PACKS: RockPackDef[] = PACK_META.map((m, i) => ({
  id: slug("pack", m.name),
  name: m.name,
  blurb: m.blurb,
  cost: extraCost(i),
  colors:
    i === 0
      ? {
          basalt: "#b8a48a",
          rime: "#8ed0da",
          quartz: "#9fc9b0",
          alloy: "#c98b62",
        }
      : packColors((i * 17) % 360, (i % 5) * 4, (i % 3) * 3 - 2),
  fill: 0.1 + (i % 5) * 0.03,
  cut: i === 0 ? "rough" : ROCK_CUTS[i % ROCK_CUTS.length]!,
}));

export const DEFAULT_LASER_ID = LASER_SKINS[0]!.id;
export const DEFAULT_PACK_ID = ROCK_PACKS[0]!.id;

export function laserById(id: string): LaserDef {
  return LASER_SKINS.find((s) => s.id === id) ?? LASER_SKINS[0]!;
}

export function packById(id: string): RockPackDef {
  return ROCK_PACKS.find((s) => s.id === id) ?? ROCK_PACKS[0]!;
}

export function isLaserId(id: string): boolean {
  return LASER_SKINS.some((s) => s.id === id);
}

export function isPackId(id: string): boolean {
  return ROCK_PACKS.some((s) => s.id === id);
}

export function livePalette(laserId: string, packId: string): LivePalette {
  const laser = laserById(laserId);
  const pack = packById(packId);
  const kind = pack.colors;
  const weapon: Record<WeaponId, string> = {
    kinetic: kind.basalt,
    cryo: kind.rime,
    resonant: kind.quartz,
    thermal: kind.alloy,
  };
  return { kind, weapon, laser, pack };
}

export const GACHA_COST = 500;
export const GACHA_DUP_REFUND = 100;

export type GachaKind = "well" | "laser" | "pack";

export type GachaPrize = {
  kind: GachaKind;
  id: string;
  name: string;
  cost: number;
  duplicate: boolean;
};

type GachaOwned = {
  wells: string[];
  lasers: string[];
  packs: string[];
};

function gachaPool(): Omit<GachaPrize, "duplicate">[] {
  return [
    ...SKINS.filter((s) => s.cost > 0).map((s) => ({
      kind: "well" as const,
      id: s.id,
      name: s.name,
      cost: s.cost,
    })),
    ...LASER_SKINS.filter((s) => s.cost > 0).map((s) => ({
      kind: "laser" as const,
      id: s.id,
      name: s.name,
      cost: s.cost,
    })),
    ...ROCK_PACKS.filter((s) => s.cost > 0).map((s) => ({
      kind: "pack" as const,
      id: s.id,
      name: s.name,
      cost: s.cost,
    })),
  ];
}

export function rollGacha(owned: GachaOwned): GachaPrize {
  const pool = gachaPool();
  const weights = pool.map((p) => 1 / Math.pow(p.cost + 28, 1.55));
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  let pick = pool[0]!;
  for (let i = 0; i < pool.length; i++) {
    r -= weights[i]!;
    if (r <= 0) {
      pick = pool[i]!;
      break;
    }
  }
  const list =
    pick.kind === "well" ? owned.wells : pick.kind === "laser" ? owned.lasers : owned.packs;
  return { ...pick, duplicate: list.includes(pick.id) };
}
